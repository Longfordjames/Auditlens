# MIT License — see LICENSE file
"""Tests for manifest-driven audit profile helpers."""

from __future__ import annotations

import pytest


def test_config_from_manifest_complete(tmp_path, monkeypatch):
    yaml = pytest.importorskip("yaml")
    import config.audit_profile as ap

    mpath = tmp_path / "manifest.yaml"
    mpath.write_text(
        yaml.dump(
            {
                "defaults": {
                    "audit_years": [2015, 2021, 2024],
                    "iod_endpoints": {"resource_and_scope3": [2015, 2024]},
                    "scalar_years": {
                        "esg": 2024,
                        "transition_capex": 2024,
                        "jurisdictional_arbitrage": 2024,
                    },
                },
                "companies": {
                    "newco": {
                        "display_name": "NewCo Public Ltd",
                        "output_metrics": {
                            "Upstream_Fuel_Consumption": "Fuel Row",
                            "Scope_3_Emissions": "S3 Row",
                            "ESG_Disclosure_Score": "ESG Row",
                            "Transition_Capex": "Capex Row",
                            "Jurisdictional_Arbitrage": "Arb Row",
                        },
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setattr(ap, "_MANIFEST_PATH", mpath)

    rec = [{"metric": "Arb Row", "value": "1", "year": "2021"}]
    cfg = ap.config_from_manifest("newco", rec)
    assert cfg is not None
    assert cfg["fuel_metric"] == "Fuel Row"
    assert cfg["scope3_metric"] == "S3 Row"
    assert cfg["display_name"] == "NewCo Public Ltd"
    assert cfg["arb_year"] == 2021
    assert cfg["fuel_years"] == (2015, 2024)


def test_try_dynamic_fuel_years_when_enabled(tmp_path, monkeypatch):
    pytest.importorskip("yaml")
    import config.audit_profile as ap

    mpath = tmp_path / "manifest.yaml"
    mpath.write_text(
        "defaults:\n  dynamic_iod_years: true\n  iod_endpoints:\n    resource_and_scope3: [2015, 2024]\n"
        "companies:\n  acme: {}\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(ap, "_MANIFEST_PATH", mpath)
    rec = [
        {"metric": "Fuel", "year": "2020", "value": "1"},
        {"metric": "Fuel", "year": "2024", "value": "2"},
        {"metric": "narrative_sentiment", "year": "2015", "value": "0.1"},
    ]
    pair = ap.try_dynamic_fuel_years("acme", rec)
    assert pair == (2020, 2024)


def test_try_dynamic_fuel_years_disabled_by_default(tmp_path, monkeypatch):
    pytest.importorskip("yaml")
    import config.audit_profile as ap

    mpath = tmp_path / "manifest.yaml"
    mpath.write_text(
        "defaults:\n  dynamic_iod_years: false\ncompanies:\n  acme: {}\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(ap, "_MANIFEST_PATH", mpath)
    rec = [
        {"metric": "Fuel", "year": "2020", "value": "1"},
        {"metric": "Fuel", "year": "2024", "value": "2"},
    ]
    assert ap.try_dynamic_fuel_years("acme", rec) is None


def test_config_from_manifest_none_without_output_metrics(tmp_path, monkeypatch):
    pytest.importorskip("yaml")
    import config.audit_profile as ap

    mpath = tmp_path / "manifest.yaml"
    mpath.write_text("companies:\n  x: {}\n", encoding="utf-8")
    monkeypatch.setattr(ap, "_MANIFEST_PATH", mpath)
    assert ap.config_from_manifest("x", []) is None
