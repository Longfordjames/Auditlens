# MIT License — see LICENSE file
"""Shared Excel helpers for Data_Input sync and bootstrap_manifest."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Tuple


def find_header_row(
    rows: List[Tuple[Any, ...]],
    max_scan: int,
) -> Tuple[int, Dict[int, int]]:
    """Return (header_row_index, year_int -> column_index)."""
    best_row = 0
    best_map: Dict[int, int] = {}
    for ri in range(min(max_scan, len(rows))):
        row = rows[ri]
        cmap: Dict[int, int] = {}
        for ci, cell in enumerate(row):
            if isinstance(cell, int) and 1990 <= cell <= 2040:
                cmap[cell] = ci
        if len(cmap) > len(best_map):
            best_map = cmap
            best_row = ri
    return best_row, best_map


def read_excel_grid(path: Path, sheet_name: str) -> List[Tuple[Any, ...]]:
    from openpyxl import load_workbook

    wb = load_workbook(path, read_only=True, data_only=True)
    if sheet_name not in wb.sheetnames:
        wb.close()
        raise ValueError(
            f"Sheet {sheet_name!r} not in {path.name}; available: {wb.sheetnames}"
        )
    ws = wb[sheet_name]
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    return rows


def list_sheet_names(path: Path) -> List[str]:
    from openpyxl import load_workbook

    wb = load_workbook(path, read_only=True, data_only=True)
    names = list(wb.sheetnames)
    wb.close()
    return names
