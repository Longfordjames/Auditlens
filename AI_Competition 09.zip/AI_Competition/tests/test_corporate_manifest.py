# MIT License — see LICENSE file
"""Manifest-driven CorporateAgent narrative registration."""

from __future__ import annotations

import pytest


def test_register_manifest_narratives_acme(tmp_path, monkeypatch):
    yaml = pytest.importorskip("yaml")
    import config.audit_profile as ap
    from agents import corporate_agent as ca

    nd = tmp_path / "narratives"
    nd.mkdir()
    (nd / "acme_excerpts.yaml").write_text(
        "excerpts_2015: |\n  [SOURCE: T]\n  baseline\n"
        "excerpts_2021: |\n  [SOURCE: T]\n  mid\n"
        "excerpts_2024: |\n  [SOURCE: T]\n  current\n",
        encoding="utf-8",
    )
    mpath = tmp_path / "manifest.yaml"
    mpath.write_text(
        yaml.dump(
            {
                "defaults": {
                    "event_study": {
                        "baseline_year": 2015,
                        "mid_year": 2021,
                        "current_year": 2024,
                    }
                },
                "companies": {
                    "acme": {
                        "display_name": "Acme Co",
                        "default_source_url": "https://example.com/reports",
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setattr(ap, "_MANIFEST_PATH", mpath)

    ca.COMPANY_NARRATIVES.pop("acme", None)
    try:
        ca._register_manifest_narratives(nd)
        assert "acme" in ca.COMPANY_NARRATIVES
        assert ca.COMPANY_NARRATIVES["acme"]["display_name"] == "Acme Co"
        assert "baseline" in ca.COMPANY_NARRATIVES["acme"]["excerpts_2015"]
    finally:
        ca.COMPANY_NARRATIVES.pop("acme", None)


def test_rekey_corporate_cache_dry_run_no_crash():
    import subprocess
    import sys
    from pathlib import Path

    repo = Path(__file__).resolve().parents[1]
    r = subprocess.run(
        [sys.executable, str(repo / "scripts" / "rekey_corporate_cache.py"), "--dry-run"],
        cwd=str(repo),
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0
