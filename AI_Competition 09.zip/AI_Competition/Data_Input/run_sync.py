#!/usr/bin/env python3
# MIT License — see LICENSE file
"""
PM one-step sync: rebuild audit CSVs from Data_Input/manifest.yaml and copy to data/energy_sector/.

Run from anywhere:
  python3 Data_Input/run_sync.py

Or from Data_Input/:
  python3 run_sync.py

Equivalent before a full run (from repo root):
  python3 run_auditlens.py --ingest-data-input --company all --sector-scan --use-cached
  # single company: --ingest-data-input --company shell (no --sector-scan)
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SYNC_SCRIPT = REPO_ROOT / "Data_Input" / "sync_audit_from_folder.py"


def main() -> int:
    if not SYNC_SCRIPT.is_file():
        print(f"Missing sync script: {SYNC_SCRIPT}", file=sys.stderr)
        return 1
    cmd = [
        sys.executable,
        str(SYNC_SCRIPT),
        "--company",
        "all",
        "--write-sector",
    ]
    print(f"Running: {' '.join(cmd)} (cwd={REPO_ROOT})\n")
    rc = subprocess.call(cmd, cwd=str(REPO_ROOT))
    if rc != 0:
        return rc
    print(
        "\n--- Next steps ---\n"
        "  Single company (cached LLM):\n"
        "    python3 run_auditlens.py --company shell --use-cached\n"
        "  Sector leaderboard:\n"
        "    python3 run_auditlens.py --sector-scan --use-cached\n"
        "  Live API (refreshes data/api_cache.json):\n"
        "    python3 run_auditlens.py --company shell\n"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
