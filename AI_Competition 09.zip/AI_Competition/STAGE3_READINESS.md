# Round 3 presentation readiness (10 min + 5 min Q&A)

*Optional internal prep: use this document if the team advances to Round 3. It does not affect Stage 2 judging.*

## Storyboard (suggested timing)

| Minutes | Content |
|--------|---------|
| 0:00–1:00 | **Hook:** Disclosure-rich names can still diverge from operational and legal footprint; fiduciaries need evidence-linked scepticism, not opaque ESG scores. |
| 1:00–3:00 | **What AuditLens does:** MAD layers — cited public metrics → deterministic \(I_d\) + cross-checks; dual-model `min` sentiment; cached LLM (Rule 4.4). |
| 3:00–5:30 | **Live or recorded demo:** `python3 run_auditlens.py --use-cached --sector-scan` → open `data/Investment_Committee_Memo.md` + `data/portfolio_tearsheet.html` + one `*_auditlens_dashboard.html`. |
| 5:30–7:30 | **Why allocators care:** Decision-support and diligence compression — strict-RAG PM assistant, provenance ledger; **illustrative** WACC/weights only, not optimal alpha or advice. |
| 7:30–9:30 | **Trust / humility:** `--use-cached`, public data only, boundaries (WIP validation, no backtest claim). |
| 9:30–10:00 | **Close:** Team + repo link: https://github.com/Longfordjames/Auditlens |

Copyright and sole implementation authorship: **Zongchen Nan** — see repository `NOTICE`. Competition team name on materials: **Alpha 1**, Durham University.

## One-line allocator punchline (memorise)

> “We turn public filings into an auditable narrative-vs-operations tension score with citations—so you spend less time reading, and more time on judgment calls.”

## Backup if live demo fails

- Static **screenshots** or PDF prints of: sector leaderboard (terminal), IC memo **Sector Integrity Ranking** table, Shell **HTML tear sheet** (hero + disclaimer strip).
- Slide with **Judge Quickstart** commands from `README.md`.

## Likely Q&A (rehearse short answers)

- **Reproducibility:** `data/api_cache.json` + `--use-cached`; `temperature=0.0`; no API key for judges.
- **Data:** 100% public filings; no Bloomberg/proprietary vendors.
- **AI role:** Development (Cursor, etc.) vs runtime (OpenAI + Anthropic for bounded sentiment/verbatim phrases); symbolic core is Python.
- **What you do not claim:** No optimal portfolio, no live investment advice, illustrative DCF/portfolio only.
