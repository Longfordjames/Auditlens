# MIT License — see LICENSE file
"""
pytest configuration and shared fixtures for the AuditLens test suite.

Adds the project root to sys.path so all tests can import project modules
without requiring an installed package. All fixtures that are used across
multiple test modules are defined here.
"""

import sys
from pathlib import Path

import pytest

# ── Ensure project root is importable ────────────────────────────────────────
PROJECT_ROOT = Path(__file__).parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


@pytest.fixture(autouse=True)
def _reset_data_loader_input_dir():
    """Avoid leaking :func:`data_loader.set_audit_input_dir` across tests."""
    import data_loader as dl

    dl.set_audit_input_dir(None)
    yield
    dl.set_audit_input_dir(None)
