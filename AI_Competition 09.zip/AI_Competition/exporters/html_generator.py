# MIT License — see LICENSE file
"""
AuditLens HTML Tear Sheet Generator
=====================================
Produces a self-contained, static HTML "Institutional Tear Sheet" from the
full MAD Protocol report JSON.  Zero internet required — the output is a single
``.html`` file judges can double-click to open in any browser.

Features:
  • Institutional dark-mode terminal aesthetic (self-contained CSS)
  • Glance KPI strip + in-page nav (anchor links; static HTML)
  • WACC × Integrity 5×5 sensitivity matrix (haircut % via valuation_engine)
  • Narrative vs. operations divergence strip (documented normalization)
  • Simplified sceptic logic-path highlights (JSON-driven)
  • Integrity Discount hero block with semantic WACC badge
  • Pure CSS/HTML bar-chart sparklines (2015 → 2021 → 2024)
  • Glass-Box Lexical Audit split-pane (hedging vs. transition phrases)
  • Symbolic cross-check status grid
  • Illustrative WACC / DCF impact section (integrity-adjusted sensitivity)
  • CFA Rule 4.6-compliant data provenance table with hyperlinked URLs
  • Responsive two-column layout using CSS Grid; print-friendly rules

No external CDNs, no Flask server, no JavaScript required.
All CSS is embedded in the ``<style>`` block.
"""

import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from jinja2 import Environment, select_autoescape

# Ensure project root on path for data_loader import
sys.path.insert(0, str(Path(__file__).parent.parent))


# ── Helpers ───────────────────────────────────────────────────────────────────

def _pct(value: Any, max_val: Any, floor: float = 4.0) -> float:
    """Normalise value to [floor, 100] percentage for bar-chart width."""
    try:
        v, m = float(value), float(max_val)
        if m == 0:
            return floor
        return max(floor, min(100.0, round(abs(v) / abs(m) * 100, 1)))
    except (TypeError, ValueError, ZeroDivisionError):
        return floor


def _fmt(value: Any, decimals: int = 4, prefix: str = "", suffix: str = "") -> str:
    """Format a numeric value with optional prefix/suffix; returns '—' on error."""
    try:
        v = float(value)
        s = f"{v:+.{decimals}f}" if prefix == "+" else f"{v:.{decimals}f}"
        return f"{prefix}{s}{suffix}"
    except (TypeError, ValueError):
        return "—"


def _fmt_M(value: Any) -> str:
    """Format a value in millions (e.g. 12030000 → '12.03M')."""
    try:
        v = float(value)
        if abs(v) >= 1_000_000:
            return f"{v / 1_000_000:.2f}M"
        if abs(v) >= 1_000:
            return f"{v / 1_000:.1f}K"
        return f"{v:.0f}"
    except (TypeError, ValueError):
        return "—"


def _safe(value: Any, default: str = "—") -> str:
    """Return string value or default if None/empty."""
    if value is None or value == "":
        return default
    return str(value)


# Must match agents.sceptic_agent.OBFUSCATION_THRESHOLD (HTML path highlight only).
_ID_OBF_THRESHOLD_HTML = 0.10


def build_wacc_integrity_sensitivity_matrix(
    company_key: str,
    current_integrity_score: Optional[float] = None,
    current_base_wacc_dec: Optional[float] = None,
) -> Optional[Dict[str, Any]]:
    """
    5×5 grid of valuation haircut % from calculate_adjusted_value only.

    Axes: integrity score 0.2–1.0; base WACC 6%–10%. Colours are normalized
    per-page (min–max of the 25 cells). Does not alter pipeline outputs.
    """
    try:
        from valuation_engine import ILLUSTRATIVE_FCF_DATA, calculate_adjusted_value
    except ImportError:
        return None

    seed = ILLUSTRATIVE_FCF_DATA.get(
        (company_key or "shell").lower(),
        ILLUSTRATIVE_FCF_DATA["shell"],
    )
    fcf = seed["fcf_array"]
    tv = float(seed["terminal_value"])
    n_y = int(seed["n_years"])
    integ_levels = [0.2, 0.4, 0.6, 0.8, 1.0]
    wacc_levels = [0.06, 0.07, 0.08, 0.09, 0.10]

    grid: list = []
    all_hc: list = []
    for ig in integ_levels:
        row = []
        for w in wacc_levels:
            d = calculate_adjusted_value(fcf, float(w), float(ig), tv, n_y)
            hc = float(d["haircut_pct"])
            all_hc.append(hc)
            is_cur = False
            if current_integrity_score is not None and current_base_wacc_dec is not None:
                if abs(ig - float(current_integrity_score)) < 1e-5 and abs(
                    w - float(current_base_wacc_dec)
                ) < 1e-5:
                    is_cur = True
            row.append({"haircut_pct": hc, "is_current": is_cur})
        grid.append(row)

    mn, mx = min(all_hc), max(all_hc)
    if mx <= mn:
        mx = mn + 1e-9
    for row in grid:
        for cell in row:
            t = (cell["haircut_pct"] - mn) / (mx - mn)
            cell["heat_idx"] = min(4, max(0, int(round(t * 4))))

    return {
        "rows": grid,
        "integrity_labels": [f"{x:.1f}" for x in integ_levels],
        "wacc_labels":    [f"{int(w * 100)}%" for w in wacc_levels],
        "min_haircut":    mn,
        "max_haircut":    mx,
        "seed_note":      _safe(seed.get("note")),
        "currency":       _safe(seed.get("currency")),
    }


# ── Embedded Jinja2 HTML Template ────────────────────────────────────────────

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AuditLens Tear Sheet — {{ company_display }}</title>
<style>
/* ═══════════════════════════════════════════════════════════════════════════
   AuditLens Institutional Tear Sheet — Dark Terminal Theme
   Self-contained; no external CDN dependencies.
   ═══════════════════════════════════════════════════════════════════════════ */
:root {
  --bg:        #07101e;
  --bg-card:   #0b1828;
  --bg-panel:  #0e1f32;
  --bg-row:    #0d1a2b;
  --border:    #1a2e47;
  --border-hi: #1e3a5f;
  --accent:    #1e56d0;
  --txt:       #dde5f0;
  --txt-mid:   #7a90aa;
  --txt-dim:   #3d5168;
  --red:       #f43f5e;
  --red-bg:    rgba(244,63,94,.09);
  --red-br:    rgba(244,63,94,.35);
  --green:     #10b981;
  --green-bg:  rgba(16,185,129,.09);
  --green-br:  rgba(16,185,129,.35);
  --yellow:    #f59e0b;
  --yel-bg:    rgba(245,158,11,.09);
  --yel-br:    rgba(245,158,11,.35);
  --cyan:      #06b6d4;
  --cyan-bg:   rgba(6,182,212,.09);
  --magenta:   #a855f7;
  --mag-bg:    rgba(168,85,247,.09);
  --mono: 'SF Mono','Fira Code','Consolas','Courier New',monospace;
  --sans: -apple-system,'Segoe UI','Helvetica Neue',sans-serif;
  --r: 6px;
}
*, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
html { font-size:13px; }
body {
  background:var(--bg); color:var(--txt);
  font-family:var(--mono); line-height:1.55;
  padding:20px 24px 40px;
  min-width:900px;
}
a { color:var(--cyan); text-decoration:none; }
a:hover { text-decoration:underline; }

/* ── Layout ─────────────────────────────────────────────────────────────── */
.page { max-width:1280px; margin:0 auto; }
.grid-2 { display:grid; grid-template-columns:1fr 420px; gap:16px; }
.grid-3 { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; }
.grid-4 { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; }
.grid-2-col { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.col-main  { display:flex; flex-direction:column; gap:16px; }
.col-side  { display:flex; flex-direction:column; gap:16px; }
.mt { margin-top:16px; }
.mb { margin-bottom:16px; }

/* ── Cards & Panels ─────────────────────────────────────────────────────── */
.card {
  background:var(--bg-card);
  border:1px solid var(--border);
  border-radius:var(--r);
  padding:16px;
}
.card-title {
  font-size:10px; font-weight:700; letter-spacing:.12em;
  text-transform:uppercase; color:var(--txt-mid);
  margin-bottom:12px; padding-bottom:8px;
  border-bottom:1px solid var(--border);
}
.accent-left-red    { border-left:3px solid var(--red);     padding-left:12px; }
.accent-left-green  { border-left:3px solid var(--green);   padding-left:12px; }
.accent-left-yellow { border-left:3px solid var(--yellow);  padding-left:12px; }
.accent-left-cyan   { border-left:3px solid var(--cyan);    padding-left:12px; }
.accent-left-accent { border-left:3px solid var(--accent);  padding-left:12px; }

/* ── Header ─────────────────────────────────────────────────────────────── */
.header {
  display:flex; align-items:flex-start; justify-content:space-between;
  padding:16px 20px;
  background:var(--bg-panel);
  border:1px solid var(--border-hi);
  border-radius:var(--r);
  margin-bottom:16px;
}
.header-left { display:flex; flex-direction:column; gap:4px; }
.header-logo { font-size:22px; font-weight:900; letter-spacing:-.02em; color:var(--txt); }
.header-logo span { color:var(--accent); }
.header-sub  { font-size:11px; color:var(--txt-mid); }
.header-right { display:flex; flex-direction:column; align-items:flex-end; gap:6px; }
.badge {
  display:inline-flex; align-items:center; gap:5px;
  font-size:10px; font-weight:700; letter-spacing:.08em;
  padding:3px 9px; border-radius:99px;
  border:1px solid; text-transform:uppercase;
}
.badge-green { color:var(--green); border-color:var(--green-br); background:var(--green-bg); }
.badge-red   { color:var(--red);   border-color:var(--red-br);   background:var(--red-bg);   }
.badge-cyan  { color:var(--cyan);  border-color:rgba(6,182,212,.3); background:var(--cyan-bg); }
.badge-yellow{ color:var(--yellow);border-color:var(--yel-br);   background:var(--yel-bg);   }
.timestamp { font-size:10px; color:var(--txt-dim); font-family:var(--sans); }

/* ── Hero Block ─────────────────────────────────────────────────────────── */
.hero {
  background:var(--bg-panel);
  border:1px solid var(--border-hi);
  border-radius:var(--r);
  padding:24px;
}
.hero-grid { display:grid; grid-template-columns:auto 1fr; gap:24px; align-items:start; }
.hero-left { display:flex; flex-direction:column; gap:10px; }
.id-label { font-size:10px; font-weight:700; letter-spacing:.12em; text-transform:uppercase; color:var(--txt-mid); }
.id-value {
  font-size:68px; font-weight:900; line-height:1;
  font-family:var(--mono); letter-spacing:-.04em;
}
.id-value.risk-high   { color:var(--red); }
.id-value.risk-medium { color:var(--yellow); }
.id-value.risk-low    { color:var(--green); }
.risk-flag {
  display:inline-flex; align-items:center; gap:6px;
  font-size:11px; font-weight:800; letter-spacing:.04em;
  padding:5px 12px; border-radius:4px; text-transform:uppercase;
}
.risk-flag.high   { background:var(--red-bg);   color:var(--red);   border:1px solid var(--red-br);   }
.risk-flag.medium { background:var(--yel-bg);   color:var(--yellow);border:1px solid var(--yel-br);   }
.risk-flag.low    { background:var(--green-bg); color:var(--green); border:1px solid var(--green-br); }

.wacc-block { margin-top:8px; }
.wacc-label { font-size:10px; color:var(--txt-mid); text-transform:uppercase; letter-spacing:.1em; margin-bottom:4px; }
.wacc-badge {
  display:inline-block; font-size:28px; font-weight:900;
  font-family:var(--mono); padding:8px 16px; border-radius:4px;
}
.wacc-badge.penalty { background:var(--red-bg);   color:var(--red);   border:1px solid var(--red-br);   }
.wacc-badge.premium { background:var(--green-bg); color:var(--green); border:1px solid var(--green-br); }
.wacc-badge.neutral { background:var(--bg-card);  color:var(--txt-mid); border:1px solid var(--border); }
.wacc-modifier { font-size:12px; color:var(--txt-mid); margin-top:4px; font-family:var(--mono); }
.wacc-action { font-size:11px; color:var(--txt); margin-top:8px; line-height:1.6; }

/* ── KPI Grid ────────────────────────────────────────────────────────────── */
.kpi-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; }
.kpi-card {
  background:var(--bg-row); border:1px solid var(--border);
  border-radius:4px; padding:12px; text-align:center;
}
.kpi-label { font-size:9px; text-transform:uppercase; letter-spacing:.1em; color:var(--txt-dim); margin-bottom:6px; }
.kpi-value { font-size:20px; font-weight:800; font-family:var(--mono); }
.kpi-sub { font-size:9px; color:var(--txt-mid); margin-top:2px; }
.col-red    { color:var(--red); }
.col-green  { color:var(--green); }
.col-yellow { color:var(--yellow); }
.col-cyan   { color:var(--cyan); }
.col-mag    { color:var(--magenta); }
.col-dim    { color:var(--txt-mid); }

/* ── Bar Chart ───────────────────────────────────────────────────────────── */
.chart-section { }
.chart-row { margin-bottom:16px; }
.chart-row-header {
  display:flex; justify-content:space-between; align-items:baseline;
  margin-bottom:6px;
}
.chart-metric-name { font-size:11px; font-weight:700; }
.chart-trend { font-size:10px; color:var(--txt-mid); font-family:var(--mono); }
.bar-group { display:flex; flex-direction:column; gap:5px; }
.bar-line { display:flex; align-items:center; gap:8px; }
.bar-year { font-size:10px; color:var(--txt-dim); width:32px; flex-shrink:0; text-align:right; font-family:var(--mono); }
.bar-track {
  flex:1; background:rgba(255,255,255,.04); border-radius:3px;
  height:24px; overflow:hidden; position:relative;
}
.bar-fill {
  height:100%; border-radius:3px;
  display:flex; align-items:center; padding:0 8px;
  font-size:10px; font-weight:700; font-family:var(--mono);
  white-space:nowrap; overflow:hidden;
  transition:width .6s cubic-bezier(.25,.46,.45,.94);
}
.bar-sent { background:linear-gradient(90deg,rgba(6,182,212,.25),rgba(6,182,212,.6)); color:var(--cyan); }
.bar-s3   { background:linear-gradient(90deg,rgba(245,158,11,.2),rgba(245,158,11,.5)); color:var(--yellow); }
.bar-gas  { background:linear-gradient(90deg,rgba(244,63,94,.2),rgba(244,63,94,.6)); color:var(--red); }
.bar-gas-hi { background:linear-gradient(90deg,rgba(244,63,94,.4),rgba(244,63,94,.9)); color:#fff; }
.bar-green-reduce { background:linear-gradient(90deg,rgba(16,185,129,.25),rgba(16,185,129,.55)); color:var(--green); }

.event-marker {
  display:flex; align-items:center; gap:8px; margin:10px 0;
  padding:6px 10px; border-radius:4px;
  background:var(--yel-bg); border:1px solid var(--yel-br);
}
.event-marker-line { flex:1; height:1px; background:var(--yellow); opacity:.5; }
.event-marker-label { font-size:10px; font-weight:700; color:var(--yellow); white-space:nowrap; }

.inflection-flag {
  display:flex; align-items:center; gap:8px; padding:8px 12px;
  border-radius:4px; font-size:11px; font-weight:700; margin-top:10px;
}
.inflection-flag.gw { background:var(--red-bg); color:var(--red); border:1px solid var(--red-br); }
.inflection-flag.ok { background:var(--green-bg); color:var(--green); border:1px solid var(--green-br); }

.slope-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:10px; }
.slope-item { background:var(--bg-row); border-radius:4px; padding:8px; }
.slope-lbl { font-size:9px; text-transform:uppercase; letter-spacing:.1em; color:var(--txt-dim); }
.slope-val { font-size:15px; font-weight:800; font-family:var(--mono); margin-top:2px; }
.slope-sub { font-size:9px; color:var(--txt-mid); margin-top:1px; }

/* ── Cross-Checks ────────────────────────────────────────────────────────── */
.checks-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
.check-item {
  padding:10px 12px; border-radius:4px;
  display:flex; flex-direction:column; gap:4px;
}
.check-triggered { background:var(--red-bg);   border:1px solid var(--red-br); }
.check-pass      { background:var(--green-bg); border:1px solid var(--green-br); }
.check-label { font-size:11px; font-weight:700; display:flex; align-items:center; gap:5px; }
.check-label.triggered { color:var(--red); }
.check-label.pass { color:var(--green); }
.check-cite { font-size:9px; color:var(--txt-mid); }

/* ── Lexical Audit ───────────────────────────────────────────────────────── */
.lex-grid { display:grid; grid-template-columns:1fr; gap:10px; }
.lex-section-title {
  font-size:10px; font-weight:700; text-transform:uppercase;
  letter-spacing:.1em; margin-bottom:8px;
}
.lex-section-title.hedging  { color:var(--yellow); }
.lex-section-title.transit  { color:var(--green);  }
.phrase-wrap { display:flex; flex-wrap:wrap; gap:6px; }
.phrase {
  display:inline-block; font-size:11px; line-height:1.4;
  padding:4px 8px; border-radius:3px; font-style:italic;
  max-width:100%;
}
.phrase-hedge  { background:var(--yel-bg); border:1px solid var(--yel-br); color:var(--yellow); }
.phrase-transit{ background:var(--green-bg); border:1px solid var(--green-br); color:var(--green); }
.phrase-none   { color:var(--txt-dim); font-style:normal; font-size:11px; }

/* ── WACC sensitivity (illustrative) ─────────────────────────────────────── */
.bps-breakdown { display:flex; flex-direction:column; gap:6px; margin-top:10px; }
.bps-row { display:flex; justify-content:space-between; align-items:baseline; padding:5px 0; border-bottom:1px solid var(--border); }
.bps-row:last-child { border-bottom:none; font-weight:700; }
.bps-key { font-size:11px; color:var(--txt-mid); }
.bps-val { font-size:14px; font-weight:800; font-family:var(--mono); }

/* ── Data Provenance ─────────────────────────────────────────────────────── */
.sources-table { width:100%; border-collapse:collapse; font-size:11px; }
.sources-table th {
  text-align:left; padding:6px 10px; font-size:9px;
  text-transform:uppercase; letter-spacing:.1em; color:var(--txt-dim);
  border-bottom:1px solid var(--border);
}
.sources-table td {
  padding:6px 10px; border-bottom:1px solid rgba(26,46,71,.5);
  vertical-align:top; line-height:1.4;
}
.sources-table tr:hover td { background:rgba(30,86,208,.04); }
.td-metric { color:var(--txt-mid); max-width:160px; }
.td-value  { font-family:var(--mono); color:var(--cyan); white-space:nowrap; }
.td-year   { font-family:var(--mono); color:var(--txt-dim); }
.td-cite   { color:var(--txt); max-width:260px; }
.td-url    { max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }

/* ── Valuation Engine ────────────────────────────────────────────────────── */
.val-warning {
  padding:10px 14px; border-radius:4px; margin-bottom:10px;
  font-size:12px; font-weight:700;
}
.val-warning.penalty { background:var(--red-bg);   color:var(--red);   border:1px solid var(--red-br); }
.val-warning.ok      { background:var(--green-bg); color:var(--green); border:1px solid var(--green-br); }
.val-table { width:100%; border-collapse:collapse; font-size:11px; }
.val-table th {
  text-align:left; padding:5px 8px; font-size:9px;
  text-transform:uppercase; letter-spacing:.1em; color:var(--txt-dim);
  border-bottom:1px solid var(--border);
}
.val-table td { padding:5px 8px; border-bottom:1px solid rgba(26,46,71,.4); font-family:var(--mono); }
.val-table .val-section td { border-top:1px solid var(--border-hi); font-weight:700; }
.val-haircut { font-size:16px; font-weight:900; color:var(--red); margin-top:8px; }
.val-haircut.none { color:var(--green); }

/* ── Bias Guard ──────────────────────────────────────────────────────────── */
.bias-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; margin-top:10px; }
.bias-item { background:var(--bg-row); border-radius:4px; padding:8px; text-align:center; }
.bias-label { font-size:9px; text-transform:uppercase; letter-spacing:.1em; color:var(--txt-dim); }
.bias-val { font-size:18px; font-weight:800; font-family:var(--mono); margin-top:3px; }
.variance-badge {
  display:inline-flex; align-items:center; gap:5px;
  font-size:11px; font-weight:700; padding:4px 10px;
  border-radius:4px; margin-top:8px;
}
.variance-high { background:var(--red-bg); color:var(--red); border:1px solid var(--red-br); }
.variance-low  { background:var(--green-bg); color:var(--green); border:1px solid var(--green-br); }

/* ── Sensitivity / Stress Test ───────────────────────────────────────────── */
.scenario-table { width:100%; border-collapse:collapse; font-size:11px; }
.scenario-table th {
  text-align:right; padding:5px 8px; font-size:9px;
  text-transform:uppercase; letter-spacing:.1em; color:var(--txt-dim);
  border-bottom:1px solid var(--border);
}
.scenario-table th:first-child { text-align:left; }
.scenario-table td {
  padding:5px 8px; border-bottom:1px solid rgba(26,46,71,.4);
  text-align:right; font-family:var(--mono);
}
.scenario-table td:first-child { text-align:left; }
.scenario-table .current-row td { background:rgba(6,182,212,.04); }
.scenario-table .tipping-row td { background:rgba(245,158,11,.08); font-weight:700; color:var(--yellow); }
.td-wacc-high   { color:var(--red); font-weight:700; }
.td-wacc-med    { color:var(--yellow); font-weight:700; }
.td-wacc-low    { color:var(--green); font-weight:700; }
.mos-box {
  padding:10px 14px; border-radius:4px; margin-top:10px;
  background:var(--cyan-bg); border:1px solid rgba(6,182,212,.3);
}
.mos-label { font-size:9px; text-transform:uppercase; letter-spacing:.1em; color:var(--txt-dim); }
.mos-val { font-size:18px; font-weight:900; font-family:var(--mono); color:var(--cyan); margin:4px 0; }

/* ── Footer ──────────────────────────────────────────────────────────────── */
.footer {
  margin-top:24px; padding:14px 20px;
  background:var(--bg-panel); border:1px solid var(--border);
  border-radius:var(--r); display:flex; justify-content:space-between;
  align-items:center;
}
.footer-left { font-size:10px; color:var(--txt-dim); line-height:1.8; }
.footer-right { display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end; }

/* ── Utilities ───────────────────────────────────────────────────────────── */
.mono   { font-family:var(--mono); }
.bold   { font-weight:700; }
.small  { font-size:10px; }
.muted  { color:var(--txt-mid); }
.dim    { color:var(--txt-dim); }
.full-width { width:100%; }
hr.thin { border:none; border-top:1px solid var(--border); margin:14px 0; }

/* ── Fiduciary Command Center (static HTML / CSS only) ───────────────────── */
.cockpit-nav {
  display:flex; flex-wrap:wrap; gap:8px 14px; align-items:center;
  padding:10px 14px; margin-bottom:14px;
  background:var(--bg-panel); border:1px solid var(--border-hi); border-radius:var(--r);
  font-size:10px; font-weight:700; letter-spacing:.06em; text-transform:uppercase;
}
.cockpit-nav a { color:var(--cyan); }
.cockpit-nav a:hover { color:var(--txt); }
section[id] { scroll-margin-top: 16px; }
.glance-strip {
  display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-bottom:12px;
}
@media (max-width:1000px) { .glance-strip { grid-template-columns:repeat(2,1fr); } }
.glance-chip {
  background:var(--bg-card); border:1px solid var(--border); border-radius:var(--r);
  padding:10px 12px; text-align:center;
}
.glance-chip .g-lbl { font-size:8px; text-transform:uppercase; letter-spacing:.12em; color:var(--txt-dim); margin-bottom:4px; }
.glance-chip .g-val { font-size:18px; font-weight:900; font-family:var(--mono); }
.bundle-valuation { border:1px solid var(--border-hi); border-radius:var(--r); padding:2px; margin-bottom:12px; }

/* Heatmap */
.heatmap-wrap { overflow-x:auto; margin-top:10px; }
.heatmap-grid {
  display:grid;
  grid-template-columns:72px repeat(5, 1fr);
  gap:3px; align-items:stretch; min-width:420px;
}
.heatmap-corner { background:transparent; }
.heatmap-colh {
  font-size:9px; font-weight:700; text-align:center; color:var(--txt-mid);
  padding:6px 4px; text-transform:uppercase; letter-spacing:.06em;
}
.heatmap-rowh {
  font-size:9px; font-weight:700; color:var(--txt-mid); display:flex; align-items:center;
  justify-content:flex-end; padding-right:8px; text-transform:uppercase; letter-spacing:.05em;
}
.heatmap-cell {
  font-size:11px; font-weight:800; font-family:var(--mono); text-align:center;
  padding:8px 4px; border-radius:3px; border:1px solid var(--border);
  min-height:36px; display:flex; flex-direction:column; align-items:center; justify-content:center;
}
.heatmap-cell .hc-pct { font-size:12px; }
.heatmap-cell .hc-sub { font-size:7px; font-weight:600; color:var(--txt-mid); margin-top:2px; }
.heatmap-cell.current-cell { outline:2px solid var(--cyan); outline-offset:1px; box-shadow:0 0 12px rgba(6,182,212,.25); }
.heat-0 { background:rgba(16,185,129,.22); color:var(--green); }
.heat-1 { background:rgba(16,185,129,.1); color:#6ee7b7; }
.heat-2 { background:rgba(245,158,11,.15); color:var(--yellow); }
.heat-3 { background:rgba(244,63,94,.18); color:#fda4af; }
.heat-4 { background:rgba(244,63,94,.32); color:#fff; }
.heatmap-legend { font-size:9px; color:var(--txt-mid); margin-top:10px; line-height:1.5; }

/* Divergence */
.divergence-block { margin-top:4px; }
.divergence-caption { font-size:10px; color:var(--txt-mid); line-height:1.55; margin-bottom:10px; }
.divergence-tracks { display:flex; flex-direction:column; gap:10px; }
.dv-row { position:relative; }
.dv-label { font-size:9px; text-transform:uppercase; letter-spacing:.1em; color:var(--txt-dim); margin-bottom:4px; }
.dv-track {
  height:28px; background:rgba(255,255,255,.05); border-radius:4px; position:relative;
  overflow:visible; border:1px solid var(--border);
}
.dv-fill-narrative {
  position:absolute; left:0; top:0; bottom:0; border-radius:4px;
  background:linear-gradient(90deg,rgba(6,182,212,.35),rgba(6,182,212,.65));
  display:flex; align-items:center; padding-left:8px; font-size:10px; font-weight:800; color:var(--cyan);
}
.dv-fill-ops {
  position:absolute; left:0; top:0; bottom:0; border-radius:4px;
  background:linear-gradient(90deg,rgba(244,63,94,.35),rgba(244,63,94,.7));
  display:flex; align-items:center; padding-left:8px; font-size:10px; font-weight:800; color:#fecaca;
}
.dv-gap-band {
  position:absolute; top:-4px; bottom:-4px; left:0; right:0; pointer-events:none;
  border-radius:6px; opacity:0; transition:opacity .2s;
}
.dv-gap-band.show-gap {
  opacity:1;
  box-shadow:0 0 16px 3px rgba(244,63,94,.45), inset 0 0 8px rgba(244,63,94,.2);
  border:1px solid rgba(244,63,94,.5);
}
.dv-alert { font-size:10px; font-weight:700; color:var(--red); margin-top:8px; }

/* Logic path */
.logic-flow {
  display:flex; flex-wrap:wrap; align-items:stretch; gap:8px; margin-top:12px;
  justify-content:flex-start;
}
.logic-node {
  flex:1; min-width:100px; max-width:160px;
  background:var(--bg-row); border:1px solid var(--border); border-radius:var(--r);
  padding:10px 10px; text-align:center; position:relative;
}
.logic-node.active {
  border-color:var(--cyan); box-shadow:0 0 0 1px rgba(6,182,212,.35);
  background:rgba(6,182,212,.06);
}
.logic-node.active-warn {
  border-color:var(--red); box-shadow:0 0 0 1px rgba(244,63,94,.35);
  background:var(--red-bg);
}
.logic-node .ln-title { font-size:9px; font-weight:800; text-transform:uppercase; letter-spacing:.08em; color:var(--txt-mid); }
.logic-node .ln-sub { font-size:10px; margin-top:6px; color:var(--txt); line-height:1.4; }
.logic-connector {
  display:flex; align-items:center; color:var(--txt-dim); font-size:14px; padding:0 2px;
}
details.explanation-details { margin-top:0; }
details.explanation-details summary {
  cursor:pointer; font-size:10px; font-weight:700; text-transform:uppercase;
  letter-spacing:.08em; color:var(--cyan); margin-bottom:8px;
}
details.explanation-details[open] summary { margin-bottom:10px; }

@media print {
  body { background:#fff; color:#111; padding:12px; }
  .page { max-width:100%; }
  .heatmap-cell { border-color:#ccc; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  .heat-0, .heat-1, .heat-2, .heat-3, .heat-4 { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  .cockpit-nav { flex-wrap:wrap; page-break-inside:avoid; }
  .card, .hero { page-break-inside:avoid; }
}

/* ── Neuro-Symbolic Reflection ───────────────────────────────────────────── */
.reflection-card {
  border: 1px solid #c026d3;
  box-shadow: 0 0 0 1px rgba(192, 38, 211, 0.15);
}
.reflection-analysis {
  margin-top: 12px;
  padding: 12px 14px;
  background: var(--bg-panel);
  border-radius: var(--r);
  font-size: 12px;
  line-height: 1.55;
  color: var(--txt-mid);
  border-left: 3px solid #c026d3;
}
</style>
</head>
<body>
<div class="page">

<!-- ══════════════════════════════════════════════════════════════════════ -->
<!-- HEADER                                                                -->
<!-- ══════════════════════════════════════════════════════════════════════ -->
<header class="header">
  <div class="header-left">
    <div class="header-logo">Audit<span>Lens</span> &nbsp;<span style="font-size:13px;font-weight:400;color:var(--txt-mid)">Institutional Tear Sheet</span></div>
    <div class="header-sub">{{ system_name }} &nbsp;·&nbsp; {{ season }} &nbsp;·&nbsp; {{ team }}</div>
    <div class="header-sub" style="margin-top:4px;font-weight:700;font-size:14px;color:var(--txt)">{{ company_display }}</div>
  </div>
  <div class="header-right">
    <span class="badge badge-green">✓ CFA Rule 4.6 — 100% Public Data</span>
    <span class="badge badge-cyan">MAD Protocol v1.0</span>
    {% if risk_level == 'HIGH' %}
    <span class="badge badge-red">⚠ HIGH RISK</span>
    {% elif risk_level == 'MEDIUM' %}
    <span class="badge badge-yellow">◆ MEDIUM RISK</span>
    {% else %}
    <span class="badge badge-green">✓ LOW RISK</span>
    {% endif %}
    <div class="timestamp">Generated {{ timestamp }}</div>
  </div>
</header>

<p class="demo-disclaimer" style="margin:10px 0 14px;padding:10px 14px;background:rgba(234,179,8,0.12);border-left:3px solid #ca8a04;font-size:11px;line-height:1.55;color:var(--txt-mid);">
  <strong style="color:var(--txt)">Institutional workflow demo only.</strong>
  Illustrative sensitivity mapping; not validated investment advice. All figures from public filings (CFA Rule 4.6).
</p>

<!-- Glance strip + in-page navigation (CSS-only; Rule 4.4 offline) -->
<div class="glance-strip" id="glance">
  <div class="glance-chip">
    <div class="g-lbl">I<sub>d</sub></div>
    <div class="g-val {{ id_color_class }}">{{ id_formatted }}</div>
  </div>
  <div class="glance-chip">
    <div class="g-lbl">Risk tier</div>
    <div class="g-val {{ 'col-red' if risk_level == 'HIGH' else ('col-yellow' if risk_level == 'MEDIUM' else 'col-green') }}">{{ risk_level }}</div>
  </div>
  <div class="glance-chip">
    <div class="g-lbl">WACC adj.</div>
    <div class="g-val {{ 'col-red' if bps > 0 else ('col-green' if bps < 0 else 'col-dim') }}">{{ bps_sign }} bps</div>
  </div>
  <div class="glance-chip">
    <div class="g-lbl">Val. haircut</div>
    <div class="g-val {% if glance_haircut_pct == '—' %}col-dim{% elif valuation and valuation.is_penalised %}col-red{% else %}col-green{% endif %}">{{ glance_haircut_pct }}</div>
  </div>
</div>
<nav class="cockpit-nav" aria-label="Section navigation">
  <span style="color:var(--txt-dim)">Jump:</span>
  <a href="#summary">Summary</a>
  <a href="#divergence">Divergence</a>
  <a href="#logic-path">Logic path</a>
  <a href="#dcf">DCF</a>
  <a href="#heatmap">Sensitivity</a>
  {% if traj_available %}<a href="#trajectory">Trajectory</a>{% endif %}
  <a href="#cross-checks">Cross-checks</a>
  <a href="#provenance">Provenance</a>
</nav>

<!-- ══════════════════════════════════════════════════════════════════════ -->
<!-- MAIN GRID                                                             -->
<!-- ══════════════════════════════════════════════════════════════════════ -->
<div class="grid-2">

  <!-- ── LEFT COLUMN ──────────────────────────────────────────────────── -->
  <div class="col-main">

    <!-- HERO: I_d + WACC -->
    <section class="hero" id="summary">
      <div class="hero-grid">
        <div class="hero-left">
          <div class="id-label">Integrity Discount (I<sub>d</sub>)</div>
          <div class="id-value {{ id_color_class }}">{{ id_formatted }}</div>
          <div class="risk-flag {{ risk_class }}">{{ risk_icon }} {{ risk_flag }}</div>
        </div>
        <div>
          <div class="wacc-block">
            <div class="wacc-label">WACC adjustment (illustrative integrity-adjusted sensitivity)</div>
            <div class="wacc-badge {{ wacc_badge_class }}">{{ wacc_bps_label }}</div>
            <div class="wacc-modifier">Implied WACC Modifier: {{ wacc_modifier }}</div>
            <div class="wacc-action">{{ valuation_action }}</div>
          </div>
        </div>
      </div>
      <hr class="thin">
      <!-- KPI Row -->
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-label">ΔNarrative Sentiment</div>
          <div class="kpi-value {{ 'col-red' if delta_sent > 0 else 'col-green' }}">{{ delta_sent_fmt }}</div>
          <div class="kpi-sub">2015 → 2024&nbsp;(LLM Glass-Box)</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">ΔResource Intensity</div>
          <div class="kpi-value {{ 'col-red' if delta_ri > 0 else 'col-green' }}">{{ delta_ri_pct }}</div>
          <div class="kpi-sub">Upstream Fuel TJ&nbsp;(2015→2024)</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Disclosure Density</div>
          <div class="kpi-value col-yellow">{{ dd_fmt }}</div>
          <div class="kpi-sub">ESG Score / 100</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Denominator</div>
          <div class="kpi-value {{ 'col-red' if denom > 0 else 'col-green' }}">{{ denom_fmt }}</div>
          <div class="kpi-sub">ΔRI × DD&nbsp;({{ 'Positive → surge' if denom > 0 else 'Negative → authentic' }})</div>
        </div>
      </div>
    </section>

    <!-- DIVERGENCE DASHBOARD (normalized bars — illustrative scale) -->
    <section class="card accent-left-cyan" id="divergence">
      <div class="card-title">Narrative vs. Operations — Divergence View</div>
      <p class="divergence-caption">
        Bar widths use an <strong>illustrative scale</strong> for side-by-side comparison only:
        narrative track = |ΔSentiment| vs cap {{ div_sent_cap }}; operations = min(|ΔResource intensity|, {{ div_ri_cap }}) vs cap.
        {% if show_divergence_gap %}<strong style="color:var(--red)"> Decoupling cue</strong> (I<sub>d</sub> &gt; 0 and ΔResource &gt; 0) is consistent with obfuscation signalling for this run.{% endif %}
      </p>
      <div class="divergence-block">
        <div class="divergence-tracks">
          <div class="dv-row">
            <div class="dv-label">Narrative sentiment (Δ 2015→2024)</div>
            <div class="dv-track">
              <div class="dv-fill-narrative" style="width:{{ div_sent_width_pct }}%">{{ delta_sent_fmt }}</div>
            </div>
          </div>
          <div class="dv-row">
            <div class="dv-label">Operational intensity (|ΔResource| capped)</div>
            <div class="dv-track">
              <div class="dv-fill-ops" style="width:{{ div_ri_width_pct }}%">{{ delta_ri_pct }} <span class="small dim">(cap {{ div_ri_cap }}×)</span></div>
              <div class="dv-gap-band {{ 'show-gap' if show_divergence_gap else '' }}"></div>
            </div>
          </div>
        </div>
        {% if show_divergence_gap %}<div class="dv-alert">Divergence highlight — narrative–operations tension flagged for this issuer.</div>{% endif %}
      </div>
    </section>

    <!-- SIMPLIFIED LOGIC PATH -->
    <section class="card" id="logic-path">
      <div class="card-title">Simplified Sceptic Path (this run)</div>
      <p class="small muted" style="margin-bottom:8px;line-height:1.55">
        High-level visualization of outputs already in the JSON report — execution remains deterministic Python in the pipeline, not in the browser.
      </p>
      <div class="logic-flow">
        <div class="logic-node active">
          <div class="ln-title">1 · Inputs</div>
          <div class="ln-sub">Glass-box LLM + audited CSV metrics</div>
        </div>
        <span class="logic-connector">→</span>
        <div class="logic-node {% if logic_ri_surge %}active active-warn{% elif logic_ri_reduce %}active{% endif %}">
          <div class="ln-title">2 · ΔResource</div>
          <div class="ln-sub">{% if logic_ri_reduce %}Reduction (authentic track){% elif logic_ri_surge %}Surge{% else %}Flat / edge{% endif %}</div>
        </div>
        <span class="logic-connector">→</span>
        <div class="logic-node {% if logic_ri_reduce %}active{% elif logic_id_high %}active-warn{% elif logic_id_mod or logic_conservative %}active{% endif %}">
          <div class="ln-title">3 · I<sub>d</sub> band</div>
          <div class="ln-sub">{% if logic_ri_reduce %}Authentic alignment track{% elif logic_conservative %}Conservative ΔSent{% elif logic_id_high %}I<sub>d</sub> &gt; {{ id_obf_threshold_fmt }}{% elif logic_id_mod %}0 ≤ I<sub>d</sub> ≤ {{ id_obf_threshold_fmt }}{% else %}—{% endif %}</div>
        </div>
        <span class="logic-connector">→</span>
        <div class="logic-node {{ 'active-warn' if logic_arb else '' }}">
          <div class="ln-title">4 · Arbitrage</div>
          <div class="ln-sub">{% if logic_arb %}Jurisdictional flag / check{% else %}Not escalated{% endif %}</div>
        </div>
        <span class="logic-connector">→</span>
        <div class="logic-node active">
          <div class="ln-title">5 · WACC</div>
          <div class="ln-sub">{{ bps_sign }} bps · {{ risk_flag[0:48] }}{% if risk_flag|length > 48 %}…{% endif %}</div>
        </div>
      </div>
      {% if logic_eps %}
      <p class="small muted" style="margin-top:10px">ε-denominator safeguard was active for this run (see JSON <span class="mono">denominator_epsilon_guard</span>).</p>
      {% endif %}
      {% if logic_reflection %}
      <p class="small muted" style="margin-top:6px">Neuro-symbolic reflection re-score applied (see panel below).</p>
      {% endif %}
    </section>

    {% if reflection_triggered %}
    <section class="card reflection-card">
      <div class="card-title" style="color:#e879f9">🔄 Professional Skepticism Re-Evaluation</div>
      <p class="small muted">Neuro-Symbolic Reflection Loop: symbolic contradiction (ΔResource surge vs. positive narrative shift) triggered a second neural pass with heightened professional skepticism. Final I<sub>d</sub> uses the reflective 2024 score.</p>
      <div class="kpi-grid" style="margin-top:12px;">
        <div class="kpi-card">
          <div class="kpi-label">Initial 2024 Sentiment</div>
          <div class="kpi-value col-cyan">{{ reflection_initial_s24_fmt }}</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Hard Data (ΔResource Intensity)</div>
          <div class="kpi-value col-yellow">{{ reflection_delta_ri_fmt }}</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Reflective 2024 Sentiment</div>
          <div class="kpi-value" style="color:#e879f9;font-weight:800">{{ reflection_score_fmt }}</div>
        </div>
      </div>
      {% if reflection_analysis %}
      <div class="reflection-analysis">{{ reflection_analysis }}</div>
      {% endif %}
    </section>
    {% endif %}

    {% if traj_available %}
    <!-- TEMPORAL TRAJECTORY -->
    <section class="card" id="trajectory">
      <div class="card-title">📈 Temporal Trajectory Analysis&nbsp;—&nbsp;Event Study&nbsp;(2015 → 2021 → 2024)</div>

      <!-- Narrative Sentiment Bars -->
      <div class="chart-row">
        <div class="chart-row-header">
          <span class="chart-metric-name" style="color:var(--cyan)">Narrative Sentiment&nbsp;<span class="small muted">(AI Glass-Box, temp=0.0)</span></span>
          <span class="chart-trend">Pre slope {{ sent_slope_pre }}/yr → Post {{ sent_slope_post }}/yr&nbsp;
            {% if sent_accel %}({{ sent_accel }}){% endif %}</span>
        </div>
        <div class="bar-group">
          <div class="bar-line">
            <span class="bar-year">2015</span>
            <div class="bar-track"><div class="bar-fill bar-sent" style="width:{{ sent_pct_2015 }}%">{{ sent_2015 }}</div></div>
          </div>
          <div class="bar-line">
            <span class="bar-year" style="color:var(--yellow)">2021⚡</span>
            <div class="bar-track"><div class="bar-fill bar-sent" style="width:{{ sent_pct_2021 }}%;opacity:.8">{{ sent_2021 }}</div></div>
          </div>
          <div class="bar-line">
            <span class="bar-year">2024</span>
            <div class="bar-track"><div class="bar-fill bar-sent" style="width:{{ sent_pct_2024 }}%">{{ sent_2024 }}</div></div>
          </div>
        </div>
      </div>

      <!-- Scope 3 Bars -->
      <div class="chart-row">
        <div class="chart-row-header">
          <span class="chart-metric-name" style="color:var(--yellow)">Scope 3 GHG Emissions&nbsp;<span class="small muted">(M t CO₂e)</span></span>
          <span class="chart-trend" style="color:var(--yellow)">STRUCTURAL FREEZE — 0.00% change</span>
        </div>
        <div class="bar-group">
          {% for yr, val, pct in s3_bars %}
          <div class="bar-line">
            <span class="bar-year" {% if yr == 2021 %}style="color:var(--yellow)"{% endif %}>{{ yr }}{% if yr == 2021 %}⚡{% endif %}</span>
            <div class="bar-track"><div class="bar-fill bar-s3" style="width:{{ pct }}%">{{ val }}</div></div>
          </div>
          {% endfor %}
        </div>
      </div>

      <!-- Fossil Input Bars -->
      <div class="chart-row">
        <div class="chart-row-header">
          <span class="chart-metric-name" style="color:var(--red)">Upstream Fossil Input (TJ)&nbsp;<span class="small muted">[Shell AR24 p.78]</span></span>
          <span class="chart-trend" style="color:var(--red)">Pre {{ ri_slope_pre }} TJ/yr → Post {{ ri_slope_post }} TJ/yr&nbsp;
            {% if ri_accel %}({{ ri_accel }}){% endif %}</span>
        </div>
        <div class="bar-group">
          {% for yr, val, pct, hi in gas_bars %}
          <div class="bar-line">
            <span class="bar-year" {% if yr == 2021 %}style="color:var(--yellow)"{% endif %}>{{ yr }}{% if yr == 2021 %}⚡{% endif %}</span>
            <div class="bar-track"><div class="bar-fill {{ 'bar-gas-hi' if hi else 'bar-gas' }}" style="width:{{ pct }}%">{{ val }}</div></div>
          </div>
          {% endfor %}
        </div>
      </div>

      <!-- 2021 Event Marker -->
      <div class="event-marker">
        <div class="event-marker-line"></div>
        <span class="event-marker-label">⚡ {{ traj_event_label }}</span>
        <div class="event-marker-line"></div>
      </div>

      <!-- Inflection Verdict -->
      <div class="inflection-flag {{ 'gw' if event_driven_gw else 'ok' }}">
        {{ '🚨' if event_driven_gw else '✓' }}
        <span>{{ inflection_flag }}</span>
      </div>

      <!-- Slope Cards -->
      <div class="slope-grid" style="margin-top:12px;">
        <div class="slope-item accent-left-cyan">
          <div class="slope-lbl">Sentiment: Pre-2021 Slope</div>
          <div class="slope-val col-cyan">{{ sent_slope_pre }}/yr</div>
          <div class="slope-sub">2015 → 2021 (6 years)</div>
        </div>
        <div class="slope-item accent-left-cyan">
          <div class="slope-lbl">Sentiment: Post-2021 Slope</div>
          <div class="slope-val {{ 'col-red' if cond_sent_accel else 'col-cyan' }}">{{ sent_slope_post }}/yr</div>
          <div class="slope-sub">2021 → 2024 (3 years){% if sent_accel %} · {{ sent_accel }}{% endif %}</div>
        </div>
        <div class="slope-item accent-left-red">
          <div class="slope-lbl">Resource: Pre-2021 Slope</div>
          <div class="slope-val col-yellow">{{ ri_slope_pre }} TJ/yr</div>
          <div class="slope-sub">2015 → 2021 (6 years)</div>
        </div>
        <div class="slope-item accent-left-red">
          <div class="slope-lbl">Resource: Post-2021 Slope</div>
          <div class="slope-val col-red">{{ ri_slope_post }} TJ/yr</div>
          <div class="slope-sub">2021 → 2024 (3 years){% if ri_accel %} · {{ ri_accel }}{% endif %}</div>
        </div>
      </div>
    </section>
    {% endif %}

    <!-- SYMBOLIC CROSS-CHECKS -->
    <section class="card" id="cross-checks">
      <div class="card-title">✦ Symbolic Cross-Checks (Deterministic — Zero LLM)</div>
      <div class="checks-grid">
        {% for chk in cross_checks %}
        <div class="check-item {{ 'check-triggered' if chk.triggered else 'check-pass' }}">
          <div class="check-label {{ 'triggered' if chk.triggered else 'pass' }}">
            {{ '⚠' if chk.triggered else '✓' }} {{ chk.rule }}
          </div>
          <div class="check-cite">{{ chk.citation }}</div>
        </div>
        {% endfor %}
      </div>
    </section>

    <!-- DATA PROVENANCE -->
    <section class="card" id="provenance">
      <div class="card-title">📋 Data Provenance&nbsp;—&nbsp;CFA Rule 4.6 Compliance</div>
      <table class="sources-table">
        <thead>
          <tr>
            <th>Metric</th>
            <th>Value</th>
            <th>Year</th>
            <th>Source Citation</th>
            <th>URL</th>
          </tr>
        </thead>
        <tbody>
          {% for row in source_rows %}
          <tr>
            <td class="td-metric">{{ row.metric }}</td>
            <td class="td-value">{{ row.value }}&nbsp;{{ row.unit }}</td>
            <td class="td-year">{{ row.year }}</td>
            <td class="td-cite">{{ row.citation }}</td>
            <td class="td-url"><a href="{{ row.url }}" target="_blank">{{ row.url_short }}</a></td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </section>

  </div><!-- /col-main -->

  <!-- ── RIGHT COLUMN (SIDEBAR) ───────────────────────────────────────── -->
  <div class="col-side">

    <!-- GLASS-BOX LEXICAL AUDIT -->
    <section class="card">
      <div class="card-title">🔬 Glass-Box Lexical Audit Trail&nbsp;<span class="small dim">(XAI v2 · verbatim extraction)</span></div>

      <div class="lex-section-title hedging">⚠ Narrative Hedging / Linguistic Softening</div>
      <div class="phrase-wrap" style="margin-bottom:14px">
        {% if hedging_phrases %}
          {% for phrase in hedging_phrases %}
          <span class="phrase phrase-hedge">"{{ phrase }}"</span>
          {% endfor %}
        {% else %}
          <span class="phrase-none">(none detected)</span>
        {% endif %}
      </div>

      <div class="lex-section-title transit">✓ Transition-Aligned Evidence</div>
      <div class="phrase-wrap">
        {% if transition_phrases %}
          {% for phrase in transition_phrases %}
          <span class="phrase phrase-transit">"{{ phrase }}"</span>
          {% endfor %}
        {% else %}
          <span class="phrase-none">(none detected)</span>
        {% endif %}
      </div>

      <hr class="thin">
      <div class="small muted" style="line-height:1.7">
        Schema: <span class="mono" style="color:var(--cyan)">{{ schema_version }}</span>&nbsp;·&nbsp;
        Temp: <span class="mono" style="color:var(--green)">0.0</span>&nbsp;(deterministic)&nbsp;·&nbsp;
        Anti-hallucination directives enforced<br>
        <span style="color:var(--txt-dim)">All phrases are verbatim substrings from public filings (CFA Responsible AI)</span>
      </div>
    </section>

    <!-- Illustrative WACC / DCF sensitivity -->
    <section class="card accent-left-{{ 'red' if bps > 0 else ('green' if bps < 0 else 'dim') }}">
      <div class="card-title">💹 Illustrative WACC / DCF impact (decision-support)</div>

      <div class="bps-breakdown">
        {% if bps > 0 %}
        <div class="bps-row">
          <span class="bps-key">Base ESG Risk Premium</span>
          <span class="bps-val col-red">+100 bps</span>
        </div>
        {% if arb_triggered %}
        <div class="bps-row">
          <span class="bps-key">Jurisdictional Arbitrage Escalation</span>
          <span class="bps-val col-red">+50 bps</span>
        </div>
        {% endif %}
        {% elif bps < 0 %}
        <div class="bps-row">
          <span class="bps-key">Authentic Transition Leader Premium</span>
          <span class="bps-val col-green">{{ bps }} bps</span>
        </div>
        {% endif %}
        <div class="bps-row">
          <span class="bps-key" style="font-weight:700">Total WACC Adjustment</span>
          <span class="bps-val {{ 'col-red' if bps > 0 else ('col-green' if bps < 0 else 'col-dim') }}" style="font-size:22px">{{ bps_sign }} bps</span>
        </div>
        <div class="bps-row">
          <span class="bps-key">Implied WACC Modifier</span>
          <span class="bps-val {{ 'col-red' if bps > 0 else ('col-green' if bps < 0 else 'col-dim') }}">{{ wacc_modifier }}</span>
        </div>
      </div>

      <hr class="thin">
      <div class="small" style="color:var(--txt-mid);line-height:1.7">
        <strong style="color:var(--txt)">Valuation Action</strong><br>
        {{ valuation_action }}
      </div>
    </section>

    <!-- EXPLANATION -->
    <section class="card">
      <div class="card-title">Audit Explanation</div>
      <details class="explanation-details">
        <summary>Show full narrative (collapsed by default)</summary>
        <div style="font-size:11px;line-height:1.7;color:var(--txt-mid)">{{ explanation }}</div>
      </details>
    </section>

    {% if valuation or sensitivity_matrix %}
    <div class="bundle-valuation" id="valuation-bundle">
    {% if valuation %}
    <!-- VALUATION ENGINE — DCF IMPACT -->
    <section class="card accent-left-{{ 'red' if valuation.is_penalised else 'green' }}" id="dcf">
      <div class="card-title">💰 Valuation Impact — I_d-Adjusted DCF</div>
      {% if valuation.is_penalised %}
      <div class="val-warning penalty">
        🚨 VALUATION ADJUSTMENT: Applying +{{ valuation.premium_pct }}% WACC Premium
        ({{ valuation.premium_bps }} bps) due to I_d &lt; {{ 0.80 }} threshold.
        Integrity Score: {{ valuation.integrity_score }}
      </div>
      {% else %}
      <div class="val-warning ok">
        ✓ INTEGRITY CONFIRMED: No WACC adjustment. Integrity Score {{ valuation.integrity_score }} ≥ 0.80
      </div>
      {% endif %}
      <table class="val-table">
        <thead><tr><th>Parameter</th><th>Base</th><th>I_d-Adjusted</th></tr></thead>
        <tbody>
          <tr><td>Integrity Score</td><td>—</td><td class="{{ 'col-red' if valuation.is_penalised else 'col-green' }}">{{ valuation.integrity_score }}</td></tr>
          <tr><td>WACC</td><td>{{ valuation.base_wacc_pct }}%</td>
              <td class="{{ 'col-red' if valuation.is_penalised else 'col-green' }}">{{ valuation.adjusted_wacc_pct }}%
              (+{{ valuation.premium_bps }} bps)</td></tr>
          <tr><td>TV Factor</td><td>1.000</td>
              <td class="{{ 'col-red' if valuation.tv_discount_factor < 1 else 'col-green' }}">{{ valuation.tv_discount_factor }}</td></tr>
          <tr class="val-section"><td>PV of FCFs</td>
              <td>{{ valuation.base_pv_fcf }}</td><td>{{ valuation.adj_pv_fcf }}</td></tr>
          <tr><td>PV of Terminal Value</td>
              <td>{{ valuation.base_pv_tv }}</td><td>{{ valuation.adj_pv_tv }}</td></tr>
          <tr class="val-section"><td><strong>Total Valuation</strong></td>
              <td><strong>{{ valuation.base_valuation }}</strong></td>
              <td class="{{ 'col-red' if valuation.is_penalised else 'col-green' }}">
                <strong>{{ valuation.adjusted_valuation }}</strong></td></tr>
        </tbody>
      </table>
      <div class="val-haircut {{ 'none' if not valuation.is_penalised }}">
        {% if valuation.is_penalised %}
        Valuation Haircut: −{{ valuation.valuation_haircut }} {{ valuation.currency }}
        (−{{ valuation.haircut_pct }}%)
        {% else %}No haircut — authentic transition leader{% endif %}
      </div>
      <div class="small muted" style="margin-top:8px;line-height:1.7">
        <em>{{ valuation.note }}</em>
      </div>
    </section>
    {% endif %}

    {% if sensitivity_matrix %}
    <section class="card accent-left-accent" id="heatmap">
      <div class="card-title">Illustrative WACC × Integrity Sensitivity</div>
      <p class="small muted" style="line-height:1.55;margin-bottom:8px">
        Each cell: valuation haircut (%) from the same <span class="mono">calculate_adjusted_value</span> engine as the DCF table above.
        Colours = min–max of this 5×5 grid only. Assumes illustrative FCF/TV from <span class="mono">valuation_engine</span> — not a live price target.
        {% if sensitivity %}<strong style="color:var(--cyan)"> Gas stress scenarios below</strong> answer a different question (operational tipping), not this grid.{% endif %}
      </p>
      <div class="heatmap-wrap">
        <div class="heatmap-grid">
          <div class="heatmap-corner"></div>
          {% for wl in sensitivity_matrix.wacc_labels %}
          <div class="heatmap-colh">WACC<br>{{ wl }}</div>
          {% endfor %}
          {% for row in sensitivity_matrix.rows %}
          <div class="heatmap-rowh">Int.<br>{{ sensitivity_matrix.integrity_labels[loop.index0] }}</div>
          {% for cell in row %}
          <div class="heatmap-cell heat-{{ cell.heat_idx }}{% if cell.is_current %} current-cell{% endif %}">
            <span class="hc-pct">{{ '%.1f'|format(cell.haircut_pct) }}%</span>
            <span class="hc-sub">{% if cell.is_current %}this run{% endif %}</span>
          </div>
          {% endfor %}
          {% endfor %}
        </div>
      </div>
      <div class="heatmap-legend">
        Scale: {{ '%.1f'|format(sensitivity_matrix.min_haircut) }}% (lowest haircut in grid) → {{ '%.1f'|format(sensitivity_matrix.max_haircut) }}% (highest).
        Currency context: {{ sensitivity_matrix.currency }}.
      </div>
    </section>
    {% endif %}
    </div><!-- /bundle-valuation -->
    {% endif %}

    {% if dual_model_active %}
    <!-- DUAL-MODEL BIAS GUARD -->
    <section class="card">
      <div class="card-title">🔬 Dual-Model Bias Variance Matrix  <span class="small dim">(OpenAI / Anthropic)</span></div>
      <div class="bias-grid">
        <div class="bias-item">
          <div class="bias-label">OpenAI 2024</div>
          <div class="bias-val col-cyan">{{ score_openai_2024 }}</div>
        </div>
        <div class="bias-item">
          <div class="bias-label">Anthropic 2024</div>
          <div class="bias-val col-mag">{{ score_anthropic_2024 }}</div>
        </div>
        <div class="bias-item">
          <div class="bias-label">|Variance|</div>
          <div class="bias-val {{ 'col-red' if ai_variance_2024 > 0.15 else 'col-green' }}">{{ ai_variance_2024 }}</div>
        </div>
      </div>
      <div>
        <span class="variance-badge {{ 'variance-high' if high_ambiguity else 'variance-low' }}">
          {{ '⚠ HIGH AI AMBIGUITY (variance > 0.15) — conservative score applied' if high_ambiguity else '✓ LOW VARIANCE — consensus robust (< 0.15)' }}
        </span>
      </div>
      <hr class="thin">
      <div class="small muted" style="line-height:1.7">
        Consensus: <strong style="color:var(--cyan)">min(OpenAI, Anthropic)</strong> selected for I_d calculation &nbsp;·&nbsp;
        Models: <span class="mono">gpt-4o-mini</span> + <span class="mono" style="color:var(--magenta)">claude-3-haiku-20240307</span><br>
        <span style="color:var(--txt-dim)">Dual-Model Protocol prevents hallucinated optimism bias (CFA Stage 3 Responsible AI)</span>
      </div>
    </section>
    {% endif %}

    {% if sensitivity %}
    <!-- SENSITIVITY / MARGIN OF SAFETY -->
    <section class="card accent-left-cyan">
      <div class="card-title">⚠ Fiduciary Margin of Safety — Scenario Analysis</div>
      <table class="scenario-table">
        <thead>
          <tr>
            <th>Gas Reduction</th><th>Gas (TJ)</th><th>ΔRI</th>
            <th>I_d</th><th>WACC</th>
          </tr>
        </thead>
        <tbody>
          {% for sc in sensitivity.scenarios %}
          <tr class="{{ 'tipping-row' if sc.is_tipping else ('current-row' if sc.pct_reduction == 0 else '') }}">
            <td>{% if sc.is_tipping %}⚡ -{{ sc.pct_reduction }}% TIPPING POINT{% else %}-{{ sc.pct_reduction }}%{% if sc.pct_reduction == 0 %} ←current{% endif %}{% endif %}</td>
            <td>{{ sc.gas_mtj }}M</td>
            <td class="{{ 'col-red' if sc.delta_ri_pct and sc.delta_ri_pct > 0 else 'col-green' }}">
              {{ sc.delta_ri_pct }}%
            </td>
            <td>{{ '%.4f'|format(sc.id) if sc.id is not none else 'DIV/0' }}</td>
            <td class="{{ 'td-wacc-high' if sc.wacc_bps and sc.wacc_bps > 100 else ('td-wacc-med' if sc.wacc_bps and sc.wacc_bps > 0 else 'td-wacc-low') }}">
              {{ ('+' if sc.wacc_bps and sc.wacc_bps > 0 else '') + (sc.wacc_bps|string) + ' bps' if sc.wacc_bps is not none else '—' }}
            </td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
      <div class="mos-box">
        <div class="mos-label">Required Gas Reduction to Exit HIGH-RISK</div>
        <div class="mos-val">{{ sensitivity.margin_of_safety_pct }}%</div>
        <div class="small" style="color:var(--txt-mid)">
          Gas: {{ sensitivity.current_gas_mtj }}M → {{ sensitivity.tipping_gas_mtj }}M TJ &nbsp;·&nbsp;
          Best achievable: <strong>+{{ sensitivity.best_achievable_bps }} bps</strong>
          (structural floor due to Jurisdictional Arbitrage)
        </div>
      </div>
    </section>
    {% endif %}

    <!-- COMPLIANCE METADATA -->
    <section class="card">
      <div class="card-title">Compliance Metadata</div>
      <div style="display:flex;flex-direction:column;gap:8px;font-size:11px;">
        <div class="bps-row">
          <span class="bps-key">LLM Model</span>
          <span class="mono" style="color:var(--cyan)">gpt-4o-mini</span>
        </div>
        <div class="bps-row">
          <span class="bps-key">Temperature</span>
          <span class="mono col-green">0.0 (deterministic)</span>
        </div>
        <div class="bps-row">
          <span class="bps-key">Cache Mode</span>
          <span class="mono" style="color:var(--cyan)">api_cache.json (CFA Rule 4.4)</span>
        </div>
        <div class="bps-row">
          <span class="bps-key">Schema Version</span>
          <span class="mono" style="color:var(--cyan)">{{ schema_version }}</span>
        </div>
        <div class="bps-row">
          <span class="bps-key">License</span>
          <span class="mono col-dim">MIT</span>
        </div>
        <div class="bps-row" style="border-bottom:none">
          <span class="bps-key">Data Provenance</span>
          <span style="color:var(--green);font-weight:700">100% Public Sources</span>
        </div>
      </div>
    </section>

  </div><!-- /col-side -->
</div><!-- /grid-2 -->

<!-- ══════════════════════════════════════════════════════════════════════ -->
<!-- FOOTER                                                                -->
<!-- ══════════════════════════════════════════════════════════════════════ -->
<footer class="footer">
  <div class="footer-left">
    <strong style="color:var(--txt)">AuditLens v1.0</strong>&nbsp;·&nbsp;MAD Protocol (Multi-Agent Adversarial Detection)<br>
    Team Alpha 1 · Durham University · CFA AI Investment Challenge 2025–26<br>
    <span style="color:var(--txt-dim)">Copyright © 2026 Zongchen Nan · MIT License</span><br>
    <span style="color:var(--txt-dim)">Model Transparency: 100% Lexical Provenance · Execution: Deterministic (Temp 0.0) · Zero Generative Hallucination</span>
  </div>
  <div class="footer-right">
    <span class="badge badge-green">✓ CFA Rule 4.6</span>
    <span class="badge badge-cyan">✓ CFA Rule 4.4</span>
    <span class="badge badge-cyan">✓ Responsible AI</span>
    <span class="badge" style="color:var(--txt-dim);border-color:var(--txt-dim)">MIT License</span>
  </div>
</footer>

</div><!-- /page -->
</body>
</html>
"""


# ── Main generator function ───────────────────────────────────────────────────

def generate_tear_sheet(
    report:           dict,
    company_name:     str,
    output_path:      Path,
    sensitivity_data: dict = None,
    valuation_data:   dict = None,
) -> Path:
    """
    Render an institutional-grade, self-contained HTML Tear Sheet from the
    MAD Protocol report JSON.

    The output file is completely static — no server, no CDN, no internet.
    Judges can double-click ``data/auditlens_dashboard_{company}.html`` in
    any browser to view the full interactive dashboard.

    Parameters
    ----------
    report       : dict  Full report dict from ``_build_report()`` in run_auditlens.
    company_name : str   Company identifier ("shell" or "orsted").
    output_path  : Path  Destination for the ``.html`` file.

    Returns
    -------
    Path
        The path to the written HTML file.
    """
    # ── Unpack report sections ─────────────────────────────────────────────────
    system    = report.get("system", {})
    layers    = report.get("layers", {})
    verdict   = report.get("verdict", {})
    corp      = layers.get("corporate_agent", {})
    aud_layer = layers.get("auditor_agent", {})
    sceptic   = layers.get("sceptic_agent", {})
    traj      = sceptic.get("trajectory", {"available": False})
    fi        = sceptic.get("formula_inputs", {})
    nsr       = sceptic.get("neuro_symbolic_reflection") or {}
    reflection_triggered = bool(nsr.get("triggered"))
    _ins = nsr.get("initial_sentiment_2024")
    reflection_initial_s24_fmt = (
        f"{float(_ins):+.4f}" if _ins is not None else "—"
    )
    reflection_delta_ri_fmt = _safe(nsr.get("delta_ri_pct_display"), "—")
    _rs = nsr.get("reflective_sentiment_score")
    reflection_score_fmt = (
        f"{float(_rs):+.4f}" if _rs is not None else "—"
    )
    reflection_analysis = _safe(nsr.get("cognitive_dissonance_analysis"), "")

    # ── Core metrics ───────────────────────────────────────────────────────────
    # ── Bias guard fields ──────────────────────────────────────────────────────
    dual_active       = bool(verdict.get("dual_model_active", False))
    high_ambiguity    = bool(verdict.get("high_ambiguity_flag", False))
    score_openai_2024 = corp.get("score_openai_2024")
    score_ant_2024    = corp.get("score_anthropic_2024")
    ai_var_2024       = corp.get("ai_variance_2024", 0.0)

    # ── Valuation data (from valuation_engine, optional) ─────────────────────
    val_raw = valuation_data or report.get("valuation_analysis")
    val_obj = None
    if val_raw and isinstance(val_raw, dict):
        class _Val:
            pass
        v = _Val()
        for k, val in val_raw.items():
            setattr(v, k, val)
        val_obj = v

    # ── Sensitivity data (from --stress-test, optional) ────────────────────
    sens_raw = sensitivity_data or report.get("sensitivity_analysis")
    sens_obj = None
    if sens_raw and isinstance(sens_raw, dict) and sens_raw.get("scenarios"):
        # Convert dicts to simple objects for Jinja2 attribute access
        class _SC:
            def __init__(self, d):
                for k, v in d.items():
                    setattr(self, k, v)
        class _Sens:
            pass
        s = _Sens()
        s.scenarios         = [_SC(sc) for sc in sens_raw["scenarios"]]
        s.margin_of_safety_pct = sens_raw.get("margin_of_safety_pct", 0)
        s.current_gas_mtj   = sens_raw.get("current_gas_mtj", 0)
        s.tipping_gas_mtj   = sens_raw.get("tipping_gas_mtj", 0)
        s.best_achievable_bps = sens_raw.get("best_achievable_bps", 50)
        sens_obj = s

    id_val    = float(verdict.get("integrity_discount", 0) or 0)
    risk_flag = _safe(verdict.get("risk_flag"), "UNKNOWN")
    risk_lvl  = _safe(verdict.get("risk_level"), "UNKNOWN")
    bps       = int(verdict.get("valuation_impact_bps", 0) or 0)
    mod       = float(verdict.get("implied_wacc_modifier", 0) or 0)
    action    = _safe(verdict.get("valuation_action"), "No action.")
    expl      = _safe(verdict.get("explanation"), "")

    delta_sent = float(fi.get("delta_narrative_sentiment", 0) or 0)
    delta_ri   = float(fi.get("delta_resource_intensity", 0) or 0)
    dd         = float(fi.get("disclosure_density", 0) or 0)
    denom      = float(fi.get("denominator", 0) or 0)

    # ── Styling helpers ────────────────────────────────────────────────────────
    id_color_class = "risk-high" if risk_lvl == "HIGH" else (
        "risk-medium" if risk_lvl == "MEDIUM" else "risk-low"
    )
    risk_class = risk_lvl.lower() if risk_lvl in ("HIGH", "MEDIUM", "LOW") else "low"
    risk_icon  = "🚨" if risk_lvl == "HIGH" else ("◆" if risk_lvl == "MEDIUM" else "✓")

    if bps > 0:
        wacc_badge_class = "penalty"
        wacc_bps_label   = f"🚨 +{bps} bps WACC Penalty"
    elif bps < 0:
        wacc_badge_class = "premium"
        wacc_bps_label   = f"💎 {bps} bps Green Premium"
    else:
        wacc_badge_class = "neutral"
        wacc_bps_label   = "◆ HOLD — No Adjustment"

    bps_sign    = f"+{bps}" if bps > 0 else str(bps)
    arb_check   = sceptic.get("cross_checks", [])
    arb_triggered = any(
        c.get("triggered") and "Jurisdictional" in c.get("rule", "")
        for c in arb_check
    )

    # ── Fiduciary Command Center (HTML presentation only) ─────────────────────
    div_sent_cap = 0.5
    div_ri_cap = 2.0
    div_sent_width_pct = _pct(abs(delta_sent), div_sent_cap, floor=4.0)
    div_ri_width_pct = _pct(min(abs(delta_ri), div_ri_cap), div_ri_cap, floor=4.0)
    show_divergence_gap = id_val > 0 and delta_ri > 0

    logic_ri_surge = delta_ri > 0
    logic_ri_reduce = delta_ri < 0
    logic_conservative = delta_ri > 0 and delta_sent <= 0
    logic_id_high = (
        delta_ri > 0 and delta_sent > 0 and id_val > _ID_OBF_THRESHOLD_HTML
    )
    logic_id_mod = (
        delta_ri > 0 and delta_sent > 0 and id_val <= _ID_OBF_THRESHOLD_HTML
    )
    logic_arb = arb_triggered
    logic_eps = bool(sceptic.get("denominator_epsilon_guard"))
    id_obf_threshold_fmt = f"{_ID_OBF_THRESHOLD_HTML:.2f}"

    glance_haircut_pct = "—"
    int_for_matrix: Optional[float] = None
    base_wacc_dec_for_matrix: Optional[float] = None
    if val_raw and isinstance(val_raw, dict):
        hc = val_raw.get("haircut_pct")
        if hc is not None:
            glance_haircut_pct = f"{float(hc):.1f}%"
        if val_raw.get("integrity_score") is not None:
            int_for_matrix = float(val_raw["integrity_score"])
        bwp = val_raw.get("base_wacc_pct")
        if bwp is not None:
            base_wacc_dec_for_matrix = float(bwp) / 100.0

    sensitivity_matrix = build_wacc_integrity_sensitivity_matrix(
        company_name,
        int_for_matrix,
        base_wacc_dec_for_matrix,
    )

    # ── Trajectory section ─────────────────────────────────────────────────────
    traj_available = bool(traj.get("available"))
    s3_bars, gas_bars = [], []

    if traj_available:
        s_2015 = float(traj.get("sentiment_2015") or 0)
        s_2021 = float(traj.get("sentiment_2021") or 0)
        s_2024 = float(traj.get("sentiment_2024") or 0)
        r_2015 = float(traj.get("resource_2015") or 0)
        r_2021 = float(traj.get("resource_2021") or 0)
        r_2024 = float(traj.get("resource_2024") or 0)
        s_max  = max(abs(s_2015), abs(s_2021), abs(s_2024)) or 1.0
        r_max  = max(r_2015, r_2021, r_2024) or 1.0

        sent_pct_2015 = _pct(s_2015, s_max)
        sent_pct_2021 = _pct(s_2021, s_max)
        sent_pct_2024 = _pct(s_2024, s_max)

        # Scope 3 — build from trajectory resource or use fixed values
        s3_flat   = 1_080_000.0  # Shell: structurally frozen
        s3_bars   = [(2015, "1.08M", 100), (2021, "1.08M", 100), (2024, "1.08M", 100)]

        # Gas bars
        gas_bars = [
            (2015, _fmt_M(r_2015), _pct(r_2015, r_max), False),
            (2021, _fmt_M(r_2021), _pct(r_2021, r_max), False),
            (2024, _fmt_M(r_2024), _pct(r_2024, r_max), True),
        ]

        sp_pre   = traj.get("sentiment_slope_pre", 0)
        sp_post  = traj.get("sentiment_slope_post", 0)
        rp_pre   = traj.get("ri_slope_pre", 0)
        rp_post  = traj.get("ri_slope_post", 0)

        sent_slope_pre  = f"{sp_pre:+.4f}" if sp_pre is not None else "—"
        sent_slope_post = f"{sp_post:+.4f}" if sp_post is not None else "—"
        ri_slope_pre    = f"{rp_pre:+,.0f}" if rp_pre is not None else "—"
        ri_slope_post   = f"{rp_post:+,.0f}" if rp_post is not None else "—"

        sent_accel = (
            f"+{traj['sentiment_acceleration_pct']:.0f}% accel"
            if traj.get("sentiment_acceleration_pct") else ""
        )
        ri_accel = (
            f"+{traj['ri_acceleration_pct']:.0f}% accel"
            if traj.get("ri_acceleration_pct") else ""
        )
        cond_sent_accel = bool(traj.get("cond_sentiment_accel"))
    else:
        # Provide safe defaults so the template doesn't crash
        s_2015 = s_2021 = s_2024 = 0.0
        sent_pct_2015 = sent_pct_2021 = sent_pct_2024 = 0
        sent_slope_pre = sent_slope_post = ri_slope_pre = ri_slope_post = "—"
        sent_accel = ri_accel = ""
        cond_sent_accel = False

    event_driven_gw  = bool(traj.get("event_driven_greenwashing", False))
    inflection_flag  = _safe(traj.get("inflection_flag"), "N/A")
    traj_event_label = _safe(traj.get("event_label"), "2021 Inflection Event")

    # ── Source rows from CSV ───────────────────────────────────────────────────
    source_rows = []
    try:
        from data_loader import load_audit_data
        records = load_audit_data(company_name=company_name)
        for r in records:
            url = r.get("source_url", "").strip()
            url_short = url.replace("https://", "").rstrip("/")[:40]
            source_rows.append({
                "metric":   r.get("metric", ""),
                "value":    r.get("value", ""),
                "unit":     r.get("unit", ""),
                "year":     r.get("year", ""),
                "citation": r.get("source_citation", ""),
                "url":      url,
                "url_short": url_short,
            })
    except Exception:
        pass

    # ── Render ─────────────────────────────────────────────────────────────────
    try:
        env      = Environment(autoescape=select_autoescape(["html"]))
        template = env.from_string(_HTML_TEMPLATE)
        html     = template.render(
        # System
        system_name     = _safe(system.get("name"), "AuditLens v1.0"),
        season          = _safe(system.get("season"), "CFA AI Challenge 2025–26"),
        team            = _safe(system.get("team"), "Team Alpha 1"),
        company_display = _safe(corp.get("display_name") or system.get("display_name"), company_name.upper()),
        timestamp       = datetime.now(tz=timezone.utc).strftime("%d %b %Y  %H:%M UTC"),

        # Risk
        id_val          = id_val,
        id_formatted    = f"{id_val:+.6f}",
        id_color_class  = id_color_class,
        risk_flag       = risk_flag,
        risk_class      = risk_class,
        risk_icon       = risk_icon,
        risk_level      = risk_lvl,

        # WACC
        wacc_badge_class = wacc_badge_class,
        wacc_bps_label   = wacc_bps_label,
        wacc_modifier    = f"{mod:+.4f}",
        valuation_action = action,
        bps              = bps,
        bps_sign         = bps_sign,
        arb_triggered    = arb_triggered,
        explanation      = expl,

        # KPI
        delta_sent      = delta_sent,
        delta_sent_fmt  = f"{delta_sent:+.4f}",
        delta_ri        = delta_ri,
        delta_ri_pct    = f"{delta_ri * 100:+.1f}%",
        dd_fmt          = f"{dd:.4f}",
        denom           = denom,
        denom_fmt       = f"{denom:+.4f}",

        # Trajectory
        traj_available  = traj_available,
        sent_2015       = f"{s_2015:+.2f}" if traj_available else "",
        sent_2021       = f"{s_2021:+.2f}" if traj_available else "",
        sent_2024       = f"{s_2024:+.2f}" if traj_available else "",
        sent_pct_2015   = sent_pct_2015,
        sent_pct_2021   = sent_pct_2021,
        sent_pct_2024   = sent_pct_2024,
        s3_bars         = s3_bars,
        gas_bars        = gas_bars,
        sent_slope_pre  = sent_slope_pre,
        sent_slope_post = sent_slope_post,
        ri_slope_pre    = ri_slope_pre,
        ri_slope_post   = ri_slope_post,
        sent_accel      = sent_accel,
        ri_accel        = ri_accel,
        cond_sent_accel = cond_sent_accel,
        event_driven_gw = event_driven_gw,
        inflection_flag = inflection_flag,
        traj_event_label= traj_event_label,

        # Lexical
        hedging_phrases    = corp.get("hedging_phrases_2024") or [],
        transition_phrases = corp.get("transition_phrases_2024") or [],
        schema_version     = _safe(corp.get("schema_version"), "xai_v2"),

        # Cross-checks
        cross_checks    = arb_check,

        # Sources
        source_rows          = source_rows,
        # Bias Guard
        dual_model_active    = dual_active,
        high_ambiguity       = high_ambiguity,
        score_openai_2024    = f"{score_openai_2024:+.4f}" if score_openai_2024 is not None else "—",
        score_anthropic_2024 = f"{score_ant_2024:+.4f}" if score_ant_2024 is not None else "—",
        ai_variance_2024     = round(ai_var_2024, 4),
        # Sensitivity
        sensitivity          = sens_obj,
        # Valuation
        valuation            = val_obj,
        # Neuro-Symbolic Reflection
        reflection_triggered     = reflection_triggered,
        reflection_initial_s24_fmt = reflection_initial_s24_fmt,
        reflection_delta_ri_fmt  = reflection_delta_ri_fmt,
        reflection_score_fmt     = reflection_score_fmt,
        reflection_analysis      = reflection_analysis,

        # Fiduciary Command Center (static HTML)
        glance_haircut_pct   = glance_haircut_pct,
        sensitivity_matrix   = sensitivity_matrix,
        div_sent_cap         = div_sent_cap,
        div_ri_cap           = div_ri_cap,
        div_sent_width_pct   = div_sent_width_pct,
        div_ri_width_pct     = div_ri_width_pct,
        show_divergence_gap  = show_divergence_gap,
        logic_ri_surge       = logic_ri_surge,
        logic_ri_reduce      = logic_ri_reduce,
        logic_conservative   = logic_conservative,
        logic_id_high        = logic_id_high,
        logic_id_mod         = logic_id_mod,
        logic_arb            = logic_arb,
        logic_eps            = logic_eps,
        id_obf_threshold_fmt = id_obf_threshold_fmt,
        )
    except Exception as exc:
        logger.warning("HTML tear sheet render failed (CLI continues): %s", exc)
        raise

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html, encoding="utf-8")
    except OSError as exc:
        logger.warning("HTML tear sheet write failed: %s", exc)
        raise
    return output_path


# ── Portfolio Dashboard ───────────────────────────────────────────────────────

_PORTFOLIO_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AuditLens Portfolio Tear Sheet</title>
<style>
:root {
  --bg:        #07101e;
  --bg-card:   #0b1828;
  --bg-panel:  #0e1f32;
  --border:    #1a2e47;
  --accent:    #1e56d0;
  --txt:       #dde5f0;
  --txt-mid:   #7a90aa;
  --red:       #e05260;
  --green:     #2ecb7a;
  --yellow:    #f5c842;
  --cyan:      #4dd0e1;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--txt); font-family: 'Courier New', monospace; padding: 24px; }
h1 { font-size: 1.4rem; color: var(--cyan); border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 18px; }
h2 { font-size: 1.0rem; color: var(--txt-mid); margin: 24px 0 12px; text-transform: uppercase; letter-spacing: 0.08em; }
.meta { font-size: 0.75rem; color: var(--txt-mid); margin-bottom: 20px; }
table { width: 100%; border-collapse: collapse; font-size: 0.82rem; margin-bottom: 28px; }
th { background: var(--bg-panel); color: var(--cyan); text-align: left; padding: 8px 12px; border: 1px solid var(--border); font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.06em; }
td { padding: 8px 12px; border: 1px solid var(--border); vertical-align: middle; }
tr:nth-child(even) td { background: var(--bg-card); }
.divest  { color: var(--red);   font-weight: bold; }
.alloc   { color: var(--green); font-weight: bold; }
.hold    { color: var(--txt-mid); }
.bar-wrap { width: 100%; background: #1a2e47; border-radius: 3px; height: 12px; }
.bar { height: 12px; border-radius: 3px; min-width: 4px; transition: width 0.3s; }
.bar-base { background: var(--txt-mid); }
.bar-opt  { background: var(--cyan); }
.badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.72rem; font-weight: bold; border: 1px solid; margin-left: 6px; }
.badge-high { color: var(--red);   border-color: var(--red); }
.badge-low  { color: var(--green); border-color: var(--green); }
.badge-med  { color: var(--yellow);border-color: var(--yellow); }
.kpi-row { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 24px; }
.kpi { flex: 1; min-width: 140px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 6px; padding: 14px 18px; }
.kpi-val { font-size: 1.5rem; font-weight: bold; color: var(--cyan); }
.kpi-lbl { font-size: 0.72rem; color: var(--txt-mid); margin-top: 4px; text-transform: uppercase; }
footer { margin-top: 30px; font-size: 0.70rem; color: var(--txt-mid); border-top: 1px solid var(--border); padding-top: 10px; }
</style>
</head>
<body>
<h1>🏛  AuditLens — Fiduciary Portfolio Tear Sheet</h1>
<div class="meta">
  Generated: {{ generated_at }} &nbsp;·&nbsp;
  AUM: ${{ aum_m }}M USD &nbsp;·&nbsp;
  Assets: {{ n_assets }} &nbsp;·&nbsp;
  Weight Sum: {{ weight_sum }}% &nbsp;·&nbsp;
  MAD Protocol v1.0 — CFA AI Investment Challenge 2025-26
</div>

<div class="kpi-row">
  <div class="kpi"><div class="kpi-val">{{ n_assets }}</div><div class="kpi-lbl">Companies Scanned</div></div>
  <div class="kpi"><div class="kpi-val" style="color:var(--red)">{{ n_high }}</div><div class="kpi-lbl">High-Risk Flagged</div></div>
  <div class="kpi"><div class="kpi-val" style="color:var(--green)">{{ n_low }}</div><div class="kpi-lbl">Authentic Leaders</div></div>
  <div class="kpi"><div class="kpi-val">${{ max_divest_m }}M</div><div class="kpi-lbl">Max Divestment</div></div>
  <div class="kpi"><div class="kpi-val">${{ max_alloc_m }}M</div><div class="kpi-lbl">Max Allocation</div></div>
</div>

<h2>Portfolio Reallocation Matrix</h2>
<table>
<thead>
  <tr>
    <th>Asset</th>
    <th>Risk Flag</th>
    <th>WACC Signal</th>
    <th>Tilt ×</th>
    <th>Baseline Weight</th>
    <th>Optimized Weight</th>
    <th>Δ Weight</th>
    <th>Δ Capital (USD)</th>
  </tr>
</thead>
<tbody>
{% for p in positions %}
  {% set is_alloc = p.delta_weight_pct > 0 %}
  {% set is_divest = p.delta_weight_pct < 0 %}
  {% set row_class = 'alloc' if is_alloc else ('divest' if is_divest else 'hold') %}
  {% set dir_sym = '↑' if is_alloc else ('↓' if is_divest else '=') %}
  {% set action  = 'ALLOCATE' if is_alloc else ('DIVEST' if is_divest else 'HOLD') %}
  {% set badge_class = 'badge-low' if p.risk_level == 'LOW' else ('badge-high' if p.risk_level == 'HIGH' else 'badge-med') %}
  <tr>
    <td>{{ p.display_name }}</td>
    <td>{{ p.risk_flag[:30] }}<span class="badge {{ badge_class }}">{{ p.risk_level }}</span></td>
    <td class="{{ row_class }}">{{ '+' if p.wacc_bps > 0 else '' }}{{ p.wacc_bps }} bps</td>
    <td class="{{ row_class }}">{{ p.tilt_multiplier }}×</td>
    <td>
      <div class="bar-wrap"><div class="bar bar-base" style="width:{{ p.baseline_weight_pct }}%"></div></div>
      {{ "%.2f"|format(p.baseline_weight_pct) }}%
    </td>
    <td class="{{ row_class }}">
      <div class="bar-wrap"><div class="bar bar-opt" style="width:{{ p.optimized_weight_pct }}%"></div></div>
      {{ "%.2f"|format(p.optimized_weight_pct) }}%
    </td>
    <td class="{{ row_class }}">{{ dir_sym }} {{ "%+.2f"|format(p.delta_weight_pct) }}%</td>
    <td class="{{ row_class }}">{{ dir_sym }} ${{ "%+.2f"|format(p.delta_capital_usd / 1e6) }}M {{ action }}</td>
  </tr>
{% endfor %}
</tbody>
</table>

<h2>Allocation Bar Chart — Baseline vs. Optimized</h2>
<table>
<thead>
  <tr><th>Asset</th><th>Baseline EW ({{ "%.1f"|format(100.0/n_assets) }}%)</th><th>Optimized Weight</th></tr>
</thead>
<tbody>
{% for p in positions %}
  {% set is_alloc = p.delta_weight_pct > 0 %}
  {% set bar_col  = 'var(--green)' if is_alloc else ('var(--red)' if p.delta_weight_pct < 0 else 'var(--txt-mid)') %}
  <tr>
    <td>{{ p.display_name }}</td>
    <td>
      <div class="bar-wrap" style="max-width:300px">
        <div class="bar bar-base" style="width:{{ p.baseline_weight_pct }}%"></div>
      </div>
      {{ "%.2f"|format(p.baseline_weight_pct) }}%
    </td>
    <td>
      <div class="bar-wrap" style="max-width:300px">
        <div class="bar" style="width:{{ p.optimized_weight_pct }}%; background:{{ bar_col }}"></div>
      </div>
      <strong style="color:{{ bar_col }}">{{ "%.2f"|format(p.optimized_weight_pct) }}%</strong>
    </td>
  </tr>
{% endfor %}
</tbody>
</table>

<h2>Methodology Note</h2>
<p style="font-size:0.80rem;color:var(--txt-mid);line-height:1.6">
  <strong style="color:var(--txt)">Tilt formula:</strong>
  <code>tilt_multiplier = max(0.1, 1.0 &minus; wacc_bps / 500)</code>.
  Long-only constraint enforced (minimum multiplier 0.1&times;).
  Raw weights normalised to 100%. AUM reallocation = Δ_weight &times; AUM.
  Baseline = Equal-Weight across {{ n_assets }} companies.
  <strong style="color:var(--yellow)">ILLUSTRATIVE ONLY</strong> — replace ${{ aum_m }}M AUM
  with a live notional only inside your own risk framework; this sheet is a demo artefact, not a live execution system.
  All data from public filings only (CFA Rule 4.6). No proprietary data used.
</p>

<footer>
  AuditLens MAD Protocol v1.0 · Team Alpha 1 · Durham University · CFA AI Investment Challenge 2025-26 ·
  Copyright © 2026 Zongchen Nan · MIT License · Generated by run_auditlens.py --sector-scan --use-cached
</footer>
</body>
</html>
"""


def generate_portfolio_dashboard(portfolio: dict, output_path: Path) -> Path:
    """
    Render a self-contained Portfolio Reallocation HTML Tear Sheet.

    No external CDNs, no JavaScript, no server required.
    Judges can double-click the output file in any browser.

    Parameters
    ----------
    portfolio   : dict  Output from ``portfolio_optimizer.run_portfolio_optimization``.
    output_path : Path  Destination for the ``.html`` file.

    Returns
    -------
    Path  The path to the written HTML file.
    """
    from datetime import datetime, timezone

    positions  = portfolio.get("positions", [])
    aum        = portfolio.get("aum_usd", 100_000_000.0)
    n          = portfolio.get("n_assets", len(positions)) or 1
    weight_sum = round(portfolio.get("weight_sum_check", 0.0), 4)

    n_high = sum(1 for p in positions if p.get("risk_level") == "HIGH")
    n_low  = sum(1 for p in positions if p.get("risk_level") == "LOW")
    divests = [abs(p["delta_capital_usd"]) for p in positions if p["delta_weight_pct"] < 0]
    allocs  = [abs(p["delta_capital_usd"]) for p in positions if p["delta_weight_pct"] > 0]
    max_divest_m = round(max(divests) / 1e6, 2) if divests else 0.0
    max_alloc_m  = round(max(allocs)  / 1e6, 2) if allocs  else 0.0

    try:
        env  = Environment(autoescape=True)
        tmpl = env.from_string(_PORTFOLIO_TEMPLATE)
        html = tmpl.render(
            generated_at = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            aum_m        = round(aum / 1e6, 0).__int__(),
            n_assets     = n,
            weight_sum   = weight_sum,
            n_high       = n_high,
            n_low        = n_low,
            max_divest_m = max_divest_m,
            max_alloc_m  = max_alloc_m,
            positions    = positions,
        )
    except Exception as exc:
        logger.warning("Portfolio HTML render failed (CLI continues): %s", exc)
        raise

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html, encoding="utf-8")
    except OSError as exc:
        logger.warning("Portfolio HTML write failed: %s", exc)
        raise
    return output_path
