# MIT License — see LICENSE file
"""
AuditLens Investment Committee (IC) Memo Generator
====================================================
Synthesises portfolio optimisation JSON and sector-scan findings into a
formal Markdown IC Memo that satisfies institutional PM workflows.

Output path: ``data/Investment_Committee_Memo.md`` (configurable).

Fiduciary standards enforced:
  • CFA Rule 4.6 compliance statement embedded in header.
  • Every basis-point rationale traced to source CSV citation.
  • All data derived exclusively from public filings — zero proprietary
    vendor references.
  • Generated entirely offline (no LLM call required).
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger("IC_MEMO")

_DEFAULT_OUTPUT = Path(__file__).parent.parent / "data" / "Investment_Committee_Memo.md"

# ── WACC rationale map ────────────────────────────────────────────────────────
# Provides human-readable justification for each WACC tier.
_WACC_RATIONALE: Dict[str, str] = {
    "AUTHENTIC TRANSITION LEADER": (
        "Negative ΔResource Intensity confirms irreversible capital reallocation "
        "away from fossil fuels. Scope 3 trajectory declining. No Jurisdictional "
        "Arbitrage. Green cost-of-capital premium applies (−50 bps)."
    ),
    "HIGH-RISK STRATEGIC OBFUSCATION + ARB": (
        "Narrative Sentiment surge (+I_d > threshold) decoupled from resource "
        "reality. Jurisdictional Arbitrage DETECTED: EU→UK relocation converted "
        "court-mandated Scope 3 cut to voluntary IR commitment. WACC penalty: "
        "+100 bps (resource surge) + 50 bps (arb tail-risk) = +150 bps total."
    ),
    "HIGH-RISK STRATEGIC OBFUSCATION": (
        "Narrative Sentiment inflation disproportionate to operational reality "
        "(ΔRI > 0, I_d > threshold). ESG stranded-asset premium applied: +100 bps."
    ),
    "MODERATE OBFUSCATION RISK": (
        "Partial narrative-reality decoupling detected. Provisional ESG review "
        "premium: +50 bps. No Jurisdictional Arbitrage escalation."
    ),
    "CONSERVATIVE SIGNALLING": (
        "Narrative sentiment flat or declining despite resource expansion. "
        "Conservative management communication — no WACC adjustment warranted."
    ),
    "TRANSITION UNDERSTATEMENT": (
        "Resource intensity declining but narrative is conservative. "
        "Management under-claims transition progress. No penalty."
    ),
}


def _wacc_rationale(risk_flag: str, arb_flag: int) -> str:
    """Return the narrative WACC justification for a given risk flag."""
    if "AUTHENTIC" in risk_flag:
        return _WACC_RATIONALE["AUTHENTIC TRANSITION LEADER"]
    if "HIGH-RISK" in risk_flag and arb_flag:
        return _WACC_RATIONALE["HIGH-RISK STRATEGIC OBFUSCATION + ARB"]
    if "HIGH-RISK" in risk_flag:
        return _WACC_RATIONALE["HIGH-RISK STRATEGIC OBFUSCATION"]
    if "MODERATE" in risk_flag:
        return _WACC_RATIONALE["MODERATE OBFUSCATION RISK"]
    if "CONSERVATIVE" in risk_flag:
        return _WACC_RATIONALE["CONSERVATIVE SIGNALLING"]
    return _WACC_RATIONALE.get("TRANSITION UNDERSTATEMENT", "No adjustment.")


def generate_ic_memo(
    portfolio_data: dict,
    scan_results:   List[dict],
    output_dir:     Path = None,
) -> Path:
    """
    Generate a formal Investment Committee Memo in Markdown.

    Parameters
    ----------
    portfolio_data : dict
        Output from ``portfolio_optimizer.run_portfolio_optimization``.
    scan_results   : list[dict]
        Raw sector-scan result rows (output of ``_sector_scan_company``).
    output_dir     : Path
        Directory to write ``Investment_Committee_Memo.md``.
        Defaults to ``data/``.

    Returns
    -------
    Path  Path to the written Markdown file.
    """
    output_dir = output_dir or _DEFAULT_OUTPUT.parent
    output_path = output_dir / "Investment_Committee_Memo.md"

    now_utc   = datetime.now(tz=timezone.utc)
    ts_str    = now_utc.strftime("%d %B %Y, %H:%M UTC")
    date_str  = now_utc.strftime("%Y-%m-%d")
    positions = portfolio_data.get("positions", [])
    aum       = portfolio_data.get("aum_usd", 100_000_000.0)
    aum_m     = aum / 1_000_000
    n_assets  = portfolio_data.get("n_assets", len(positions))

    # Map scan results by company name for cross-reference
    scan_map: Dict[str, dict] = {r["company_name"]: r for r in scan_results}

    n_high = sum(1 for r in scan_results if r.get("risk_level") == "HIGH")
    n_low  = sum(1 for r in scan_results if r.get("risk_level") == "LOW")

    # Biggest divestment and allocation
    divests = sorted(
        [p for p in positions if p["delta_weight_pct"] < 0],
        key=lambda p: p["delta_capital_usd"],
    )
    allocs  = sorted(
        [p for p in positions if p["delta_weight_pct"] > 0],
        key=lambda p: -p["delta_capital_usd"],
    )

    lines: List[str] = []

    # ── Header ──────────────────────────────────────────────────────────────────
    lines += [
        "# INVESTMENT COMMITTEE MEMORANDUM",
        "",
        f"**Date:** {ts_str}  ",
        "**Prepared by:** AuditLens MAD Protocol v1.0 · Team Alpha 1 · Durham University  ",
        "**Copyright:** © 2026 Zongchen Nan  ",
        "**Subject:** ESG Integrity-Adjusted Portfolio Reallocation — Energy Sector  ",
        "**AUM:** $" + f"{aum_m:.0f}M USD (Illustrative)  ",
        f"**Companies Scanned:** {n_assets}  ",
        "",
        "> **CFA Rule 4.6 Compliance Statement:** All data underpinning this memo",
        "> is sourced exclusively from publicly available corporate filings, sustainability",
        "> reports, and government databases. No proprietary data vendors, paid terminals,",
        "> or employer data were used. Every metric is accompanied by `source_citation`",
        "> and `source_url` per CFA Rule 4.6.",
        "",
        "> **Institutional workflow demo only.** Illustrative sensitivity mapping and ",
        "> portfolio-weight arithmetic; **not** validated investment advice, **not** a ",
        "> backtested strategy, **not** an offer to transact.",
        "",
        "---",
        "",
    ]

    # ── 1. Executive Summary ───────────────────────────────────────────────────
    lines += [
        "## 1. Executive Summary — Decision Support Summary",
        "",
        (
            f"The AuditLens MAD Protocol has completed a sector-wide ESG integrity scan "
            f"across {n_assets} energy companies. The Bias-Variance Matrix (OpenAI "
            f"`gpt-4o-mini` vs. Anthropic `claude-3-5-sonnet-20241022`, `temperature=0.0`) "
            f"produced deterministic consensus sentiment scores with all inter-model "
            f"variances logged for fiduciary review."
        ),
        "",
        f"**Integrity Summary:** {n_low}/{n_assets} Authentic Transition Leaders · "
        f"{n_high}/{n_assets} High-Risk Obfuscators.",
        "",
        "### Sector Integrity Ranking",
        "",
        "| Rank | Company | Integrity score | I_d | Risk flag | WACC (bps) |",
        "|------|---------|-----------------|-----|-----------|------------|",
    ]

    ranked = sorted(
        scan_results,
        key=lambda x: float(x.get("integrity_score", 0.0)),
        reverse=True,
    )
    for i, r in enumerate(ranked, start=1):
        bps = r.get("wacc_bps", 0)
        bps_cell = f"+{bps}" if bps > 0 else str(bps)
        lines.append(
            f"| {i} | {r.get('display_name', r.get('company_name', ''))} | "
            f"{float(r.get('integrity_score', 0.0)):.4f} | "
            f"{float(r.get('id_val', 0.0)):+.4f} | "
            f"{r.get('risk_flag', '')} | {bps_cell} |"
        )

    lines += [
        "",
        "### Illustrative Reallocation Table (Demo)",
        "",
        "| Action | Company | Δ Weight | Δ Capital | Rationale |",
        "|--------|---------|---------|-----------|-----------|",
    ]

    for p in sorted(positions, key=lambda x: x["delta_capital_usd"]):
        delta_w   = p["delta_weight_pct"]
        delta_cap = p["delta_capital_usd"] / 1_000_000
        action    = "**DIVEST**" if delta_w < 0 else ("**ALLOCATE**" if delta_w > 0 else "HOLD")
        rationale = p.get("risk_flag", "")[:40]
        lines.append(
            f"| {action} | {p['display_name']} | "
            f"{delta_w:+.2f}% | ${delta_cap:+.2f}M | {rationale} |"
        )

    lines += ["", "---", ""]

    lines += [
        "### Visual diligence — HTML tear sheet (Fiduciary Command Center)",
        "",
        "For each scanned issuer, open **`data/{company}_auditlens_dashboard.html`** after running the "
        "standard pipeline. The tear sheet includes a **5×5 WACC × Integrity sensitivity matrix** "
        "(valuation haircut % per cell) built with the same `calculate_adjusted_value` engine as the "
        "illustrative DCF block, a **narrative vs. operations divergence** view (documented normalization), "
        "and a **simplified sceptic logic path** tied to that run’s JSON. All visuals are static HTML/CSS "
        "(no external JS; CFA Rule 4.4 offline).",
        "",
    ]

    refl_rows = [
        r for r in scan_results
        if (r.get("neuro_symbolic_reflection") or {}).get("triggered")
    ]
    if refl_rows:
        lines += [
            "### Professional Skepticism Re-Evaluation (Neuro-Symbolic Reflection)",
            "",
            "Single-company or enriched scan rows may include a closed-loop pass: when "
            "audited ΔResource Intensity surges (>50%) while ΔNarrative Sentiment is "
            "positive, the pipeline re-reads 2024 public excerpts under heightened "
            "professional skepticism before final I_d.",
            "",
        ]
        for r in refl_rows:
            nsr = r.get("neuro_symbolic_reflection") or {}
            disp = r.get("display_name", r.get("company_name", "Unknown"))
            i24 = nsr.get("initial_sentiment_2024")
            rs = nsr.get("reflective_sentiment_score")
            ri = nsr.get("delta_ri_pct_display", "")
            lines.append(f"**{disp}** — Initial 2024 consensus: `{i24}` → Reflective: `{rs}` "
                         f"(hard data: {ri}).")
            lines.append("")
            ca = (nsr.get("cognitive_dissonance_analysis") or "").strip()
            if ca:
                lines.append(f"> {ca}")
                lines.append("")
        lines += ["---", ""]

    # ── 2. Macro ESG Thesis ────────────────────────────────────────────────────
    lines += [
        "## 2. Macro ESG Thesis — Sector Observations",
        "",
        (
            "The energy sector presents a **bifurcated transition landscape**. "
            "A minority of issuers show genuine capital reallocation away from "
            "fossil inputs (negative ΔResource Intensity), while the majority "
            "maintain or grow upstream fossil consumption whilst accelerating "
            "Net-Zero narrative intensity — a pattern the MAD Protocol quantifies "
            "as the 'Signalling Paradox'."
        ),
        "",
        "**Key sector-level findings:**",
        "",
    ]

    for r in sorted(scan_results, key=lambda x: x.get("integrity_score", 0), reverse=True):
        ri_pct  = r.get("delta_ri_pct", 0.0)
        ri_dir  = "↓" if ri_pct < 0 else "↑"
        lines.append(
            f"- **{r['display_name']}**: ΔResource Intensity {ri_dir} {ri_pct:+.1f}%  |  "
            f"I_d = {r['id_val']:+.4f}  |  {r['risk_flag']}  |  "
            f"WACC: {'+' if r['wacc_bps'] > 0 else ''}{r['wacc_bps']} bps"
        )

    lines += ["", "---", ""]

    # ── 3. Illustrative integrity-adjusted risk rationale ─────────────────────
    lines += [
        "## 3. Illustrative Integrity-Adjusted Risk Rationale — WACC (bps)",
        "",
    ]

    for r in sorted(scan_results, key=lambda x: x.get("integrity_score", 0), reverse=True):
        arb = r.get("arb_flag", 0)
        bps = r.get("wacc_bps", 0)
        bps_sign = f"+{bps}" if bps > 0 else str(bps)
        rationale = _wacc_rationale(r["risk_flag"], arb)
        id_val = r.get("id_val", 0.0)

        lines += [
            f"### {r['display_name']}",
            "",
            f"| Parameter | Value |",
            f"|-----------|-------|",
            f"| Integrity Discount (I_d) | {id_val:+.4f} |",
            f"| Risk Classification | {r['risk_flag']} |",
            f"| Risk Level | {r['risk_level']} |",
            f"| ΔResource Intensity | {r.get('delta_ri_pct', 0.0):+.1f}% |",
            f"| Disclosure Density | {r.get('disclosure_density', 0.0):.4f} |",
            f"| Jurisdictional Arbitrage | {'⚠ DETECTED' if arb else '✓ None'} |",
            f"| **WACC Adjustment** | **{bps_sign} bps** |",
            "",
            f"**Rationale:** {rationale}",
            "",
        ]

    lines += ["---", ""]

    # ── 4. Illustrative portfolio weights (demo) ───────────────────────────────
    lines += [
        "## 4. Illustrative Portfolio Weights (Demo)",
        "",
        f"Baseline: Equal-Weight (EW) across {n_assets} assets.  ",
        f"AUM: ${aum_m:.0f}M USD.  ",
        "Tilt formula: `tilt_multiplier = max(0.1, 1.0 − wacc_bps/500)`.  ",
        "Long-only constraint enforced. Weights normalised to 100%.  ",
        "",
        "| Company | EW Baseline | Tilt × | Optimized Weight | Δ Weight | Δ Capital |",
        "|---------|------------|--------|-----------------|---------|-----------|",
    ]

    for p in positions:
        bps   = p["wacc_bps"]
        mult  = p["tilt_multiplier"]
        dw    = p["delta_weight_pct"]
        dcap  = p["delta_capital_usd"] / 1_000_000
        arrow = "↑" if dw > 0 else ("↓" if dw < 0 else "=")
        lines.append(
            f"| {p['display_name']} | {p['baseline_weight_pct']:.2f}% | "
            f"{mult:.2f}× | {p['optimized_weight_pct']:.2f}% | "
            f"{arrow} {dw:+.2f}% | ${dcap:+.2f}M |"
        )

    weight_sum = portfolio_data.get("weight_sum_check", 0.0)
    lines += [
        "",
        f"> **Weight sum check:** {weight_sum:.4f}% (long-only constraint satisfied).",
        "",
        "---",
        "",
    ]

    # ── 5. Compliance & Reproducibility ───────────────────────────────────────
    lines += [
        "## 5. Compliance & Reproducibility",
        "",
        "| Rule | Status | Detail |",
        "|------|--------|--------|",
        "| CFA Rule 1.5 (MIT License) | ✓ COMPLIANT | LICENSE file in repository root |",
        "| CFA Rule 4.4 (Caching) | ✓ COMPLIANT | `--use-cached` reproduces at $0 cost |",
        "| CFA Rule 4.6 (Public Data) | ✓ COMPLIANT | All CSVs cite public filings |",
        "| Dual-Model Bias Guard | ✓ ACTIVE | OpenAI + Anthropic @ temperature=0.0 |",
        "| Portfolio Optimizer | ✓ DETERMINISTIC | 100% offline, no API calls |",
        "",
        "**Reproduce this memo:**",
        "```bash",
        "python run_auditlens.py --sector-scan --use-cached",
        "```",
        "",
        "---",
        "",
        f"*Generated {ts_str} by AuditLens MAD Protocol.*  ",
        "*Generated by AuditLens MAD Protocol (Cached Mode) — Zero Proprietary Data Used.*",
    ]

    # ── Write ──────────────────────────────────────────────────────────────────
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("\n".join(lines), encoding="utf-8")
    except OSError as exc:
        logger.warning("IC_MEMO  Write failed (%s) — memo not saved.", exc)
        raise
    logger.info("IC_MEMO  Saved → %s", output_path)
    return output_path
