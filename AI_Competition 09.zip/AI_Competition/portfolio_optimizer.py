# MIT License — see LICENSE file
"""
AuditLens Portfolio Optimizer
==============================
Translates batch ``--sector-scan`` I_d / WACC signals into a long-only,
I_d-tilted portfolio that reallocates institutional AUM away from
high-risk greenwashers toward authentic transition leaders.

Algorithm:
  1. Start from an Equal-Weight (EW) baseline across all successfully
     scanned companies (CFA Rule 4.6-clean sector universe).
  2. Compute a ``tilt_multiplier`` from each company's WACC adjustment:
         tilt_multiplier = max(0.1, 1.0 − (wacc_bps / 500.0))
     Interpretation:
       • Shell  +150 bps → 1.0 − 0.30 = 0.70×  (underweight)
       • Ørsted  −50 bps → 1.0 − (−0.10) = 1.10×  (overweight)
  3. Raw weights = Baseline_Weight × tilt_multiplier.
  4. Normalise to 100% (long-only constraint: raw weight floored at
     min_raw_weight > 0 before normalisation).
  5. Δ_Weight = Optimised − Baseline; Δ_Capital = Δ_Weight × AUM.

Design principles:
  • 100% deterministic — no LLM calls, no external data fetches.
  • Operates fully offline (CFA Rule 4.4).
  • Division-by-zero guard: if raw weight sum is effectively zero,
    falls back to equal-weight output.
  • No shorting: optimised weights are always > 0 (min raw = 0.1×).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger("PORTFOLIO_OPTIMIZER")

# ── Constants ─────────────────────────────────────────────────────────────────
INSTITUTIONAL_AUM_USD: float = 100_000_000.0   # $100 M illustrative AUM
_TILT_DENOMINATOR: float     = 500.0            # bps scaling factor
_MIN_TILT_MULTIPLIER: float  = 0.1              # absolute floor — no zero-weight
_RAW_WEIGHT_EPSILON: float   = 1e-12            # denominator guard for normalisation

OUTPUT_PATH: Path = Path(__file__).parent / "data" / "portfolio_optimization.json"


# ── Core computation ──────────────────────────────────────────────────────────

def calculate_optimized_weights(
    scan_results: List[Dict],
    aum_usd: float = INSTITUTIONAL_AUM_USD,
) -> List[Dict]:
    """
    Compute I_d-tilted optimised weights for a long-only sector portfolio.

    Parameters
    ----------
    scan_results : list[dict]
        Each dict must contain at minimum:
        ``company_name``, ``display_name``, ``wacc_bps`` (int),
        ``risk_level`` (str), ``risk_flag`` (str), ``id_val`` (float).
    aum_usd : float
        Hypothetical institutional AUM in USD (default $100 M).

    Returns
    -------
    list[dict]
        One entry per company with keys:
        ``company_name``, ``display_name``, ``baseline_weight_pct``,
        ``tilt_multiplier``, ``raw_weight``, ``optimized_weight_pct``,
        ``delta_weight_pct``, ``delta_capital_usd``,
        ``wacc_bps``, ``risk_level``, ``risk_flag``, ``id_val``.
    """
    if not scan_results:
        logger.warning("PORTFOLIO_OPTIMIZER: empty scan_results — returning []")
        return []

    n = len(scan_results)
    baseline_weight = 100.0 / n   # Equal-Weight baseline (%)

    rows: List[Dict] = []
    for r in scan_results:
        bps  = int(r.get("wacc_bps", 0))
        mult = max(_MIN_TILT_MULTIPLIER, 1.0 - (bps / _TILT_DENOMINATOR))
        raw  = (baseline_weight / 100.0) * mult   # raw weight in [0, 1] scale
        rows.append({
            "company_name":       r["company_name"],
            "display_name":       r["display_name"],
            "baseline_weight_pct": round(baseline_weight, 6),
            "tilt_multiplier":    round(mult, 6),
            "raw_weight":         raw,
            "wacc_bps":           bps,
            "risk_level":         r.get("risk_level", ""),
            "risk_flag":          r.get("risk_flag", ""),
            "id_val":             float(r.get("id_val", 0.0)),
        })

    # ── Normalise to 100 % (long-only constraint) ─────────────────────────────
    total_raw = sum(r["raw_weight"] for r in rows)
    if total_raw < _RAW_WEIGHT_EPSILON:
        logger.warning(
            "PORTFOLIO_OPTIMIZER: raw weight sum effectively zero — "
            "falling back to equal-weight."
        )
        total_raw = 1.0
        for r in rows:
            r["raw_weight"] = 1.0 / n

    for r in rows:
        opt_pct = (r["raw_weight"] / total_raw) * 100.0
        delta_pct = opt_pct - r["baseline_weight_pct"]
        delta_capital = (delta_pct / 100.0) * aum_usd
        r["optimized_weight_pct"] = round(opt_pct, 6)
        r["delta_weight_pct"]     = round(delta_pct, 6)
        r["delta_capital_usd"]    = round(delta_capital, 2)
        # Remove internal raw_weight (not needed in JSON output)
        del r["raw_weight"]

    return rows


def run_portfolio_optimization(
    scan_results: List[Dict],
    aum_usd: float = INSTITUTIONAL_AUM_USD,
    output_path: Path = OUTPUT_PATH,
) -> Dict:
    """
    End-to-end portfolio optimization: compute weights and persist to JSON.

    Parameters
    ----------
    scan_results  : list[dict]  Sector scan output from ``_run_sector_scan``.
    aum_usd       : float       Institutional AUM (USD).
    output_path   : Path        JSON export path.

    Returns
    -------
    dict
        ``positions``        — list of per-company weight dicts,
        ``aum_usd``          — AUM used,
        ``n_assets``         — number of companies processed,
        ``weight_sum_check`` — must be ≈100.0 for validity.
    """
    positions = calculate_optimized_weights(scan_results, aum_usd)

    if not positions:
        return {
            "positions": [],
            "aum_usd": aum_usd,
            "n_assets": 0,
            "weight_sum_check": 0.0,
            "note": "No valid sector-scan results to optimise.",
        }

    weight_sum = round(sum(p["optimized_weight_pct"] for p in positions), 6)

    result = {
        "positions":        positions,
        "aum_usd":          aum_usd,
        "n_assets":         len(positions),
        "weight_sum_check": weight_sum,
        "methodology": (
            "Long-only I_d-tilted portfolio. "
            "tilt_multiplier = max(0.1, 1.0 - wacc_bps/500). "
            "Raw weights normalised to 100%. "
            "AUM reallocation = Δ_weight_pct × AUM. "
            "Illustrative only — replace AUM with live portfolio data."
        ),
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2, ensure_ascii=False)
    logger.info(
        "PORTFOLIO_OPTIMIZER  Saved %d positions → %s  (weight_sum=%.4f%%)",
        len(positions), output_path, weight_sum,
    )
    return result
