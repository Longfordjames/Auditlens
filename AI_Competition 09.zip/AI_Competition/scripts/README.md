# Scripts

## `rekey_corporate_cache.py`

After editing `Data_Input/narratives/*_excerpts.yaml` or changing excerpt text used by CorporateAgent, prompt hashes in `data/api_cache.json` no longer match. Labels such as `CorporateAgent_openai_shell_2024` stay the same.

Run from the repository root:

```bash
python3 scripts/rekey_corporate_cache.py --dry-run
python3 scripts/rekey_corporate_cache.py
```

This copies each labeled entry to the key implied by the current prompts (no API calls; CFA Rule 4.4). Alternatively, run `run_auditlens.py` without `--use-cached` for affected companies to refresh cache live.

### Optional CI guard (strict reproducibility)

To fail CI when narrative inputs change without a deliberate cache refresh, record a baseline hash and compare in a job:

```bash
shasum -a 256 Data_Input/narratives/*.yaml Data_Input/manifest.yaml > data/cache_baseline_hash.txt
```

Commit `data/cache_baseline_hash.txt` and add a check step that recomputes the hash and diffs against the committed file, printing a message to run `rekey_corporate_cache.py` or a live refresh when they diverge.
