# MIT License — see LICENSE file
"""
AuditLens Agent Package
=======================
Three-layer MAD Protocol (Multi-Agent Adversarial Detection):

  Layer 1  corporate_agent  (Neural)    — narrative sentiment extraction
  Layer 2  auditor_agent    (OSINT)     — ground-truth public data ingestion
  Layer 3  sceptic_agent    (Symbolic)  — deterministic Id gatekeeper
"""
