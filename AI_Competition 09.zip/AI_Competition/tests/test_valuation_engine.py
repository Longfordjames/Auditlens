# MIT License — see LICENSE file
"""
tests/test_valuation_engine.py
================================
Unit tests for the Valuation Engine — WACC premium calculation,
DCF adjustment, Integrity Score normalisation, and scenario logic.

All tests run offline: no LLM calls, no file I/O, no network.

Coverage areas:
  • Integrity Score mapping: risk level → [0, 1] range
  • WACC premium scaling:    linear 100–200 bps, threshold 0.80
  • Division-by-zero guard:  zero base_wacc handled gracefully
  • DCF arithmetic:          adjusted valuation < base valuation when penalised
  • Terminal value haircut:  severity tiers applied correctly
  • Full scenario:           Shell (HIGH-RISK), Ørsted (AUTHENTIC LEADER)
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from valuation_engine import (
    INTEGRITY_THRESHOLD,
    MAX_PREMIUM_BPS,
    MIN_PREMIUM_BPS,
    calculate_adjusted_value,
    calculate_wacc_premium,
    normalize_id_to_integrity_score,
    run_valuation_scenario,
)


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Integrity Score Normalisation
# ═══════════════════════════════════════════════════════════════════════════════

class TestIntegrityScoreNormalisation:
    """normalize_id_to_integrity_score() maps risk classification correctly."""

    def test_authentic_leader_returns_1_0(self):
        """AUTHENTIC TRANSITION LEADER → 1.0 (above threshold, no penalty)."""
        score = normalize_id_to_integrity_score("LOW", "AUTHENTIC TRANSITION LEADER")
        assert score == 1.0

    def test_authentic_leader_above_threshold(self):
        """AUTHENTIC LEADER score must be ≥ INTEGRITY_THRESHOLD (0.80)."""
        score = normalize_id_to_integrity_score("LOW", "AUTHENTIC TRANSITION LEADER")
        assert score >= INTEGRITY_THRESHOLD

    def test_low_risk_conservative_below_threshold(self):
        """CONSERVATIVE SIGNALLING → 0.85 (above threshold)."""
        score = normalize_id_to_integrity_score("LOW", "CONSERVATIVE SIGNALLING")
        assert score == 0.85
        assert score >= INTEGRITY_THRESHOLD

    def test_medium_risk_below_threshold(self):
        """MODERATE OBFUSCATION → 0.55 (below threshold → triggers premium)."""
        score = normalize_id_to_integrity_score("MEDIUM", "MODERATE OBFUSCATION RISK")
        assert score == 0.55
        assert score < INTEGRITY_THRESHOLD

    def test_high_risk_with_arb_very_low(self):
        """HIGH-RISK + Jurisdictional Arbitrage → 0.20 (worst case)."""
        score = normalize_id_to_integrity_score(
            "HIGH", "HIGH-RISK STRATEGIC OBFUSCATION — ESCALATED"
        )
        assert score == 0.20

    def test_high_risk_no_arb_slightly_higher(self):
        """HIGH-RISK without Arb → 0.30."""
        score = normalize_id_to_integrity_score("HIGH", "HIGH-RISK STRATEGIC OBFUSCATION")
        assert score == 0.30

    def test_all_scores_in_valid_range(self):
        """All possible risk levels produce scores in [0.0, 1.0]."""
        cases = [
            ("HIGH", "HIGH-RISK STRATEGIC OBFUSCATION — ESCALATED"),
            ("HIGH", "HIGH-RISK STRATEGIC OBFUSCATION"),
            ("MEDIUM", "MODERATE OBFUSCATION RISK"),
            ("LOW", "CONSERVATIVE SIGNALLING"),
            ("LOW", "AUTHENTIC TRANSITION LEADER"),
        ]
        for level, flag in cases:
            score = normalize_id_to_integrity_score(level, flag)
            assert 0.0 <= score <= 1.0, f"Score {score} out of range for {flag}"


# ═══════════════════════════════════════════════════════════════════════════════
# 2. WACC Premium Calculation
# ═══════════════════════════════════════════════════════════════════════════════

class TestWACCPremiumCalculation:
    """calculate_wacc_premium() scaling and boundary conditions."""

    def test_above_threshold_returns_zero(self):
        """Integrity score >= 0.80 → 0 bps (no adjustment needed)."""
        assert calculate_wacc_premium(0.80) == 0
        assert calculate_wacc_premium(0.90) == 0
        assert calculate_wacc_premium(1.00) == 0

    def test_at_threshold_just_below_returns_minimum(self):
        """Just below threshold (0.799…) → approaches MIN_PREMIUM_BPS (100 bps)."""
        premium = calculate_wacc_premium(0.79)
        assert premium > 0
        assert premium <= MIN_PREMIUM_BPS + 5   # within 5 bps of minimum

    def test_zero_score_returns_maximum(self):
        """Integrity score = 0.0 → MAX_PREMIUM_BPS (200 bps)."""
        assert calculate_wacc_premium(0.0) == MAX_PREMIUM_BPS

    def test_midpoint_score_returns_midpoint_premium(self):
        """Integrity score = 0.40 (midpoint of [0, 0.80]) → ~150 bps."""
        premium = calculate_wacc_premium(0.40)
        assert 145 <= premium <= 155   # within 5 bps of 150

    def test_negative_score_capped_at_maximum(self):
        """Negative integrity score → capped at MAX_PREMIUM_BPS (200 bps)."""
        assert calculate_wacc_premium(-0.5) == MAX_PREMIUM_BPS
        assert calculate_wacc_premium(-999) == MAX_PREMIUM_BPS

    def test_premium_monotonically_decreasing_with_score(self):
        """Higher integrity score → lower WACC premium (monotonic)."""
        scores = [0.0, 0.20, 0.40, 0.55, 0.70, 0.80]
        premiums = [calculate_wacc_premium(s) for s in scores]
        for i in range(len(premiums) - 1):
            assert premiums[i] >= premiums[i + 1], (
                f"Premium not monotone at score={scores[i]}: {premiums[i]} < {premiums[i+1]}"
            )

    def test_shell_integrity_score_yields_expected_premium(self):
        """Shell (integrity=0.20): premium = 100 + (0.80-0.20)/0.80 × 100 = 175 bps."""
        premium = calculate_wacc_premium(0.20)
        assert premium == 175

    def test_premium_range_is_100_to_200(self):
        """Premium is always in [0, MAX_PREMIUM_BPS] — no overflow."""
        for score in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.79, 0.8, 1.0]:
            p = calculate_wacc_premium(score)
            assert 0 <= p <= MAX_PREMIUM_BPS


# ═══════════════════════════════════════════════════════════════════════════════
# 3. DCF Adjusted Value Calculation
# ═══════════════════════════════════════════════════════════════════════════════

class TestDCFAdjustedValue:
    """calculate_adjusted_value() arithmetic correctness."""

    _FCF     = [10.0, 10.0, 10.0, 10.0, 10.0]
    _WACC    = 0.08
    _TV      = 80.0
    _N       = 5
    _INT_OK  = 1.0    # above threshold — no penalty
    _INT_BAD = 0.20   # below threshold — penalty

    def test_no_penalty_when_above_threshold(self):
        """Integrity score ≥ 0.80 → adjusted valuation equals base valuation."""
        result = calculate_adjusted_value(
            self._FCF, self._WACC, self._INT_OK, self._TV, self._N
        )
        assert abs(result["adjusted_valuation"] - result["base_valuation"]) < 0.01
        assert result["premium_bps"] == 0
        assert result["valuation_haircut"] < 0.01

    def test_penalty_reduces_valuation(self):
        """With penalty (score < 0.80) → adjusted valuation < base valuation."""
        result = calculate_adjusted_value(
            self._FCF, self._WACC, self._INT_BAD, self._TV, self._N
        )
        assert result["adjusted_valuation"] < result["base_valuation"]
        assert result["valuation_haircut"] > 0
        assert result["haircut_pct"] > 0

    def test_higher_base_wacc_reduces_all_pvs(self):
        """Higher base WACC → lower PV of FCFs and TV (basic DCF property)."""
        r1 = calculate_adjusted_value(self._FCF, 0.08, 0.20, self._TV, self._N)
        r2 = calculate_adjusted_value(self._FCF, 0.12, 0.20, self._TV, self._N)
        assert r2["base_valuation"] < r1["base_valuation"]

    def test_tv_haircut_applied_for_low_integrity(self):
        """Integrity score < 0.40 → TV discount factor = 0.90."""
        result = calculate_adjusted_value(
            self._FCF, self._WACC, 0.20, self._TV, self._N
        )
        assert result["tv_discount_factor"] == 0.90

    def test_tv_haircut_mild_for_medium_integrity(self):
        """Integrity score 0.40–0.79 → TV discount factor = 0.95."""
        result = calculate_adjusted_value(
            self._FCF, self._WACC, 0.55, self._TV, self._N
        )
        assert result["tv_discount_factor"] == 0.95

    def test_no_tv_haircut_above_threshold(self):
        """Integrity score ≥ 0.80 → TV discount factor = 1.00."""
        result = calculate_adjusted_value(
            self._FCF, self._WACC, 1.0, self._TV, self._N
        )
        assert result["tv_discount_factor"] == 1.00

    def test_adjusted_wacc_equals_base_plus_premium(self):
        """Adjusted WACC = base WACC + premium rate."""
        result = calculate_adjusted_value(
            self._FCF, self._WACC, 0.20, self._TV, self._N
        )
        expected_adj_wacc = self._WACC + result["premium_bps"] / 10_000
        assert abs(result["adjusted_wacc_pct"] - expected_adj_wacc * 100) < 0.01

    def test_output_schema_complete(self):
        """Output dict contains all required keys."""
        result = calculate_adjusted_value(
            self._FCF, self._WACC, 0.20, self._TV, self._N
        )
        required = {
            "base_wacc_pct", "premium_bps", "premium_pct", "adjusted_wacc_pct",
            "tv_discount_factor", "base_pv_fcf", "adj_pv_fcf",
            "base_pv_tv", "adj_pv_tv",
            "base_valuation", "adjusted_valuation",
            "valuation_haircut", "haircut_pct",
        }
        assert required.issubset(result.keys())

    def test_pv_fcf_sums_correctly(self):
        """PV of FCFs = Σ [FCF_t / (1+r)^t] — verify one case exactly."""
        fcf = [10.0]
        r   = 0.10
        tv  = 0.0
        result = calculate_adjusted_value(fcf, r, 1.0, tv, n_years=1)
        expected_pv = 10.0 / 1.10
        assert abs(result["base_pv_fcf"] - expected_pv) < 0.001


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Full Scenario Tests (Shell + Ørsted)
# ═══════════════════════════════════════════════════════════════════════════════

class TestFullScenarios:
    """run_valuation_scenario() end-to-end correctness."""

    def test_shell_high_risk_is_penalised(self):
        """Shell (HIGH-RISK) → is_penalised = True, premium > 0."""
        result = run_valuation_scenario(
            "shell", "HIGH", "HIGH-RISK STRATEGIC OBFUSCATION — ESCALATED"
        )
        assert result["is_penalised"] is True
        assert result["premium_bps"] > 0

    def test_shell_wacc_premium_is_175_bps(self):
        """Shell (integrity=0.20) → exactly 175 bps WACC premium."""
        result = run_valuation_scenario(
            "shell", "HIGH", "HIGH-RISK STRATEGIC OBFUSCATION — ESCALATED"
        )
        assert result["premium_bps"] == 175

    def test_shell_adjusted_valuation_lower_than_base(self):
        """Shell adjusted valuation < base valuation."""
        result = run_valuation_scenario(
            "shell", "HIGH", "HIGH-RISK STRATEGIC OBFUSCATION — ESCALATED"
        )
        assert result["adjusted_valuation"] < result["base_valuation"]

    def test_shell_haircut_is_positive(self):
        """Shell valuation haircut is positive (loss of value)."""
        result = run_valuation_scenario(
            "shell", "HIGH", "HIGH-RISK STRATEGIC OBFUSCATION — ESCALATED"
        )
        assert result["valuation_haircut"] > 0
        assert result["haircut_pct"] > 0

    def test_orsted_authentic_leader_not_penalised(self):
        """Ørsted (AUTHENTIC TRANSITION LEADER) → no penalty."""
        result = run_valuation_scenario(
            "orsted", "LOW", "AUTHENTIC TRANSITION LEADER"
        )
        assert result["is_penalised"] is False
        assert result["premium_bps"] == 0

    def test_orsted_adjusted_equals_base(self):
        """Ørsted: adjusted valuation = base valuation (no adjustment)."""
        result = run_valuation_scenario(
            "orsted", "LOW", "AUTHENTIC TRANSITION LEADER"
        )
        assert abs(result["adjusted_valuation"] - result["base_valuation"]) < 0.01

    def test_orsted_integrity_score_above_threshold(self):
        """Ørsted Integrity Score ≥ 0.80."""
        result = run_valuation_scenario(
            "orsted", "LOW", "AUTHENTIC TRANSITION LEADER"
        )
        assert result["integrity_score"] >= INTEGRITY_THRESHOLD

    def test_scenario_output_includes_company_metadata(self):
        """Full scenario includes company, currency, note, breach_label."""
        result = run_valuation_scenario(
            "shell", "HIGH", "HIGH-RISK STRATEGIC OBFUSCATION"
        )
        assert "company"       in result
        assert "currency"      in result
        assert "note"          in result
        assert "breach_label"  in result
        assert "ILLUSTRATIVE"  in result["note"].upper()

    def test_benchmark_wacc_premium_spread(self):
        """Shell (penalised) has higher adjusted WACC than Ørsted (not penalised)."""
        shell  = run_valuation_scenario(
            "shell", "HIGH", "HIGH-RISK STRATEGIC OBFUSCATION — ESCALATED"
        )
        orsted = run_valuation_scenario(
            "orsted", "LOW", "AUTHENTIC TRANSITION LEADER"
        )
        assert shell["adjusted_wacc_pct"] > orsted["adjusted_wacc_pct"]
        assert shell["premium_bps"] > orsted["premium_bps"]
