# MIT License — see LICENSE file
"""
tests/test_llm_wrapper.py
==========================
Unit tests for llm_wrapper.py — cache I/O, CFA Rule 4.4 fallback mechanisms,
OPENAI_API_KEY pre-flight guard, XAI schema validation, and live-API mocking.

All tests run 100% offline via unittest.mock — zero API calls, zero cost.
This satisfies CFA Rule 4.4 reproducibility requirements for the test suite.

Coverage areas:
  • Cache I/O:            load (missing, corrupt, valid), save, key determinism
  • Cache hit/miss:       cache hit returns stored response, miss raises RuntimeError
  • OPENAI_API_KEY guard: EnvironmentError with actionable advisory
  • Missing openai pkg:   ImportError with install instruction
  • Live API mock:        successful call is cached; mocked via unittest.mock
  • XAI schema check:     legacy v1 → advisory emitted; v2 → no advisory
  • Corrupt cache:        auto-backup created, empty dict returned (no crash)
"""

import json
import os
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch


# ── Helpers ───────────────────────────────────────────────────────────────────

def _write_cache(path: Path, data: dict) -> Path:
    """Write a JSON cache file and return its path."""
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


def _make_xai_response(score: float = 0.72) -> str:
    """Return a valid XAI v2 JSON response string."""
    return json.dumps({
        "sentiment_score":            score,
        "narrative_hedging_phrases":  ["hedging phrase"],
        "transition_aligned_phrases": ["transition phrase"],
        "reasoning_trace":            "Test reasoning.",
    })


def _make_legacy_response(score: float = 0.72) -> str:
    """Return a legacy v1 JSON response string (no phrase arrays)."""
    return json.dumps({
        "narrative_sentiment_score": score,
        "reasoning":                 "Legacy reasoning.",
    })


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Cache Key Determinism
# ═══════════════════════════════════════════════════════════════════════════════

class TestCacheKey:
    """SHA-256 cache key properties."""

    def test_same_inputs_same_key(self):
        """Identical (model, temperature, prompt) → identical key (determinism)."""
        import llm_wrapper
        k1 = llm_wrapper._cache_key("prompt X", "gpt-4o-mini", 0.0)
        k2 = llm_wrapper._cache_key("prompt X", "gpt-4o-mini", 0.0)
        assert k1 == k2

    def test_different_prompts_different_keys(self):
        """Different prompts → different keys (collision resistance)."""
        import llm_wrapper
        k1 = llm_wrapper._cache_key("prompt A", "gpt-4o-mini", 0.0)
        k2 = llm_wrapper._cache_key("prompt B", "gpt-4o-mini", 0.0)
        assert k1 != k2

    def test_different_models_different_keys(self):
        """Different model IDs → different keys."""
        import llm_wrapper
        k1 = llm_wrapper._cache_key("same", "gpt-4o-mini", 0.0)
        k2 = llm_wrapper._cache_key("same", "gpt-4",       0.0)
        assert k1 != k2

    def test_different_temperatures_different_keys(self):
        """Different temperatures → different keys."""
        import llm_wrapper
        k1 = llm_wrapper._cache_key("same", "gpt-4o-mini", 0.0)
        k2 = llm_wrapper._cache_key("same", "gpt-4o-mini", 0.5)
        assert k1 != k2

    def test_key_is_64_char_hex(self):
        """Cache key is a 64-character lowercase hex string (SHA-256)."""
        import llm_wrapper
        k = llm_wrapper._cache_key("any prompt", "gpt-4o-mini", 0.0)
        assert len(k) == 64
        assert all(c in "0123456789abcdef" for c in k)


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Cache File I/O
# ═══════════════════════════════════════════════════════════════════════════════

class TestCacheIO:
    """_load_cache() and _save_cache() behaviour."""

    def test_load_returns_empty_when_file_missing(self, tmp_path, monkeypatch):
        """_load_cache returns {} when cache file does not exist."""
        import llm_wrapper
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", tmp_path / "nonexistent.json")
        assert llm_wrapper._load_cache() == {}

    def test_load_returns_valid_dict(self, tmp_path, monkeypatch):
        """_load_cache returns parsed dict from valid JSON file."""
        import llm_wrapper
        cache_path = tmp_path / "api_cache.json"
        _write_cache(cache_path, {"key": {"response": "value"}})
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", cache_path)
        result = llm_wrapper._load_cache()
        assert result["key"]["response"] == "value"

    def test_load_corrupt_json_returns_empty_and_backs_up(self, tmp_path, monkeypatch):
        """Corrupt JSON in cache → empty dict returned, backup file created."""
        import llm_wrapper
        cache_path = tmp_path / "api_cache.json"
        cache_path.write_text("{ INVALID JSON !!!", encoding="utf-8")
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", cache_path)
        result  = llm_wrapper._load_cache()
        backups = list(tmp_path.glob("*.corrupt_*.json"))
        assert result == {}
        assert len(backups) == 1, "Backup file must be created for corrupt cache"

    def test_load_corrupt_json_does_not_crash(self, tmp_path, monkeypatch):
        """Corrupt JSON never raises — graceful degradation guaranteed."""
        import llm_wrapper
        cache_path = tmp_path / "api_cache.json"
        cache_path.write_text("not json at all", encoding="utf-8")
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", cache_path)
        result = llm_wrapper._load_cache()   # must not raise
        assert isinstance(result, dict)

    def test_save_creates_file(self, tmp_path, monkeypatch):
        """_save_cache creates the file if it doesn't exist."""
        import llm_wrapper
        target = tmp_path / "api_cache.json"
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", target)
        llm_wrapper._save_cache({"k": {"response": "v"}})
        assert target.exists()

    def test_save_writes_valid_json(self, tmp_path, monkeypatch):
        """_save_cache writes valid, parseable JSON."""
        import llm_wrapper
        target = tmp_path / "api_cache.json"
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", target)
        llm_wrapper._save_cache({"mykey": {"model": "gpt-4o-mini", "response": "hello"}})
        loaded = json.loads(target.read_text())
        assert loaded["mykey"]["response"] == "hello"

    def test_save_creates_parent_directory(self, tmp_path, monkeypatch):
        """_save_cache creates missing parent directories."""
        import llm_wrapper
        deep_path = tmp_path / "nested" / "dir" / "api_cache.json"
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", deep_path)
        llm_wrapper._save_cache({"x": {"response": "y"}})
        assert deep_path.exists()


# ═══════════════════════════════════════════════════════════════════════════════
# 3. llm_call() — Cache Hit / Miss
# ═══════════════════════════════════════════════════════════════════════════════

class TestLLMCallCacheMode:
    """llm_call() cache hit returns stored response; miss triggers RuntimeError."""

    def _seed_cache(self, tmp_path, prompt, model, temp, response):
        """Write a single-entry cache file and return its path + key."""
        import llm_wrapper
        key  = llm_wrapper._cache_key(prompt, model, temp)
        data = {key: {"model": model, "temperature": temp, "response": response}}
        path = tmp_path / "api_cache.json"
        _write_cache(path, data)
        return path, key

    def test_cache_hit_returns_response(self, tmp_path, monkeypatch):
        """Cache hit returns stored response without any API call."""
        import llm_wrapper
        prompt = "my test prompt"
        path, _ = self._seed_cache(tmp_path, prompt, "gpt-4o-mini", 0.0, "cached!")
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        result = llm_wrapper.llm_call(prompt, use_cached=True)
        assert result == "cached!"

    def test_llm_events_cache_hit_append_and_suppress_info(self, tmp_path, monkeypatch, caplog):
        """llm_events collects rows; emit_llm_logs=False avoids INFO CACHE HIT lines."""
        import logging

        import llm_wrapper

        prompt = "ev prompt"
        path, key = self._seed_cache(tmp_path, prompt, "gpt-4o-mini", 0.0, "body")
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        events: list = []
        caplog.set_level(logging.INFO)
        out = llm_wrapper.llm_call(
            prompt,
            use_cached=True,
            label="CorporateAgent_openai_shell_2024",
            emit_llm_logs=False,
            llm_events=events,
        )
        assert out == "body"
        assert len(events) == 1
        assert events[0]["status"] == "CACHE_HIT"
        assert events[0]["year"] == "2024"
        assert events[0]["provider"] == "openai"
        assert events[0]["key_prefix"] == key[:12]
        assert not any("CACHE HIT" in r.getMessage() for r in caplog.records)

    def test_cache_hit_uses_no_api_call(self, tmp_path, monkeypatch):
        """Cache hit path never calls _check_api_key or OpenAI."""
        import llm_wrapper
        prompt = "test prompt"
        path, _ = self._seed_cache(tmp_path, prompt, "gpt-4o-mini", 0.0, "hit!")
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        # Remove API key — should still work because cache hit doesn't call API
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        result = llm_wrapper.llm_call(prompt, use_cached=True)
        assert result == "hit!"

    def test_cache_miss_use_cached_raises_runtime_error(self, tmp_path, monkeypatch):
        """Cache miss with use_cached=True raises RuntimeError (not KeyError)."""
        import llm_wrapper
        path = tmp_path / "api_cache.json"
        _write_cache(path, {})
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        with pytest.raises(RuntimeError, match="CACHE MISS"):
            llm_wrapper.llm_call("uncached prompt", use_cached=True)

    def test_cache_miss_error_contains_git_hint(self, tmp_path, monkeypatch):
        """RuntimeError for cache miss includes git checkout recovery hint."""
        import llm_wrapper
        path = tmp_path / "api_cache.json"
        _write_cache(path, {})
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        with pytest.raises(RuntimeError) as exc_info:
            llm_wrapper.llm_call("miss", use_cached=True)
        assert "api_cache.json" in str(exc_info.value) or "git" in str(exc_info.value)


# ═══════════════════════════════════════════════════════════════════════════════
# 4. API Key Pre-Flight Guard
# ═══════════════════════════════════════════════════════════════════════════════

class TestAPIKeyGuard:
    """_check_api_key() and live-mode key handling."""

    def test_missing_api_key_raises_environment_error(self, monkeypatch):
        """No OPENAI_API_KEY → EnvironmentError with 'OPENAI_API_KEY' in message."""
        import llm_wrapper
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        with pytest.raises(EnvironmentError, match="OPENAI_API_KEY"):
            llm_wrapper._check_api_key()

    def test_empty_api_key_raises_environment_error(self, monkeypatch):
        """Empty OPENAI_API_KEY → EnvironmentError."""
        import llm_wrapper
        monkeypatch.setenv("OPENAI_API_KEY", "")
        with pytest.raises(EnvironmentError):
            llm_wrapper._check_api_key()

    def test_whitespace_api_key_raises_environment_error(self, monkeypatch):
        """Whitespace-only OPENAI_API_KEY → EnvironmentError."""
        import llm_wrapper
        monkeypatch.setenv("OPENAI_API_KEY", "   ")
        with pytest.raises(EnvironmentError):
            llm_wrapper._check_api_key()

    def test_valid_api_key_does_not_raise(self, monkeypatch):
        """Non-empty OPENAI_API_KEY → no exception."""
        import llm_wrapper
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key-12345")
        llm_wrapper._check_api_key()   # must not raise

    def test_live_mode_with_missing_key_raises_from_llm_call(
        self, tmp_path, monkeypatch
    ):
        """llm_call in live mode without key → EnvironmentError (not AttributeError)."""
        import llm_wrapper
        path = tmp_path / "api_cache.json"
        _write_cache(path, {})
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        with pytest.raises(EnvironmentError):
            llm_wrapper.llm_call("test", use_cached=False)


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Live API Call (Fully Mocked)
# ═══════════════════════════════════════════════════════════════════════════════

class TestLiveAPIMocked:
    """Validate live API path using unittest.mock — zero real API calls."""

    def test_successful_api_call_returns_response(self, tmp_path, monkeypatch):
        """Mocked API call returns the mocked completion content."""
        import llm_wrapper

        path = tmp_path / "api_cache.json"
        _write_cache(path, {})
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test-mock-key")

        mock_msg        = MagicMock()
        mock_msg.content = "mocked response"
        mock_choice     = MagicMock()
        mock_choice.message = mock_msg
        mock_completion = MagicMock()
        mock_completion.choices = [mock_choice]
        mock_client     = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion
        mock_openai_mod = MagicMock()
        mock_openai_mod.OpenAI.return_value = mock_client

        with patch.dict("sys.modules", {"openai": mock_openai_mod}):
            result = llm_wrapper.llm_call("test prompt", use_cached=False)

        assert result == "mocked response"

    def test_successful_api_call_writes_to_cache(self, tmp_path, monkeypatch):
        """After a successful live call, the response is persisted in the cache."""
        import llm_wrapper

        path = tmp_path / "api_cache.json"
        _write_cache(path, {})
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key")

        mock_msg        = MagicMock()
        mock_msg.content = "saved response"
        mock_choice     = MagicMock()
        mock_choice.message = mock_msg
        mock_completion = MagicMock()
        mock_completion.choices = [mock_choice]
        mock_client     = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion
        mock_openai_mod = MagicMock()
        mock_openai_mod.OpenAI.return_value = mock_client

        with patch.dict("sys.modules", {"openai": mock_openai_mod}):
            llm_wrapper.llm_call("persist prompt", use_cached=False, label="test_persist")

        saved = json.loads(path.read_text())
        assert len(saved) == 1
        entry = list(saved.values())[0]
        assert entry["response"] == "saved response"
        assert entry["label"] == "test_persist"

    def test_cached_entry_contains_model_and_temp(self, tmp_path, monkeypatch):
        """Cached entry stores model name and temperature for auditor inspection."""
        import llm_wrapper

        path = tmp_path / "api_cache.json"
        _write_cache(path, {})
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

        mock_msg        = MagicMock()
        mock_msg.content = "x"
        mock_choice     = MagicMock()
        mock_choice.message = mock_msg
        mock_completion = MagicMock()
        mock_completion.choices = [mock_choice]
        mock_client     = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion
        mock_openai_mod = MagicMock()
        mock_openai_mod.OpenAI.return_value = mock_client

        with patch.dict("sys.modules", {"openai": mock_openai_mod}):
            llm_wrapper.llm_call("audit prompt", model="gpt-4o-mini",
                                 temperature=0.0, use_cached=False)

        saved = json.loads(path.read_text())
        entry = list(saved.values())[0]
        assert entry["model"] == "gpt-4o-mini"
        assert entry["temperature"] == 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# 6. XAI Schema Validation (_check_xai_schema)
# ═══════════════════════════════════════════════════════════════════════════════

class TestXAISchemaValidation:
    """_check_xai_schema() and expected_fields advisory logic."""

    @pytest.fixture(autouse=True)
    def _clear_advisory_set(self):
        """Reset _XAI_ADVISORY_EMITTED before each test to avoid cross-contamination."""
        import llm_wrapper
        llm_wrapper._XAI_ADVISORY_EMITTED.clear()
        yield
        llm_wrapper._XAI_ADVISORY_EMITTED.clear()

    def test_valid_xai_schema_no_advisory_emitted(self, tmp_path, monkeypatch):
        """XAI v2 response with all required fields → no advisory flag set."""
        import llm_wrapper
        prompt   = "xai valid"
        response = _make_xai_response()
        key      = llm_wrapper._cache_key(prompt, "gpt-4o-mini", 0.0)
        cache    = {key: {"model": "gpt-4o-mini", "temperature": 0.0, "response": response}}
        path     = tmp_path / "api_cache.json"
        _write_cache(path, cache)
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)

        from agents.corporate_agent import XAI_REQUIRED_FIELDS
        llm_wrapper.llm_call(prompt, use_cached=True, expected_fields=XAI_REQUIRED_FIELDS,
                              label="valid_label")
        assert "valid_label" not in llm_wrapper._XAI_ADVISORY_EMITTED

    def test_legacy_schema_sets_advisory_label(self, tmp_path, monkeypatch):
        """Legacy v1 response missing XAI fields → label added to advisory set."""
        import llm_wrapper
        prompt   = "legacy test"
        response = _make_legacy_response()
        key      = llm_wrapper._cache_key(prompt, "gpt-4o-mini", 0.0)
        cache    = {key: {"model": "gpt-4o-mini", "temperature": 0.0, "response": response}}
        path     = tmp_path / "api_cache.json"
        _write_cache(path, cache)
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)

        from agents.corporate_agent import XAI_REQUIRED_FIELDS
        llm_wrapper.llm_call(prompt, use_cached=True, expected_fields=XAI_REQUIRED_FIELDS,
                              label="legacy_label")
        assert "legacy_label" in llm_wrapper._XAI_ADVISORY_EMITTED

    def test_advisory_not_repeated_for_same_label(self, tmp_path, monkeypatch):
        """Advisory is only emitted once per label (de-duplication)."""
        import llm_wrapper
        prompt   = "repeat test"
        response = _make_legacy_response()
        key      = llm_wrapper._cache_key(prompt, "gpt-4o-mini", 0.0)
        cache    = {key: {"model": "gpt-4o-mini", "temperature": 0.0, "response": response}}
        path     = tmp_path / "api_cache.json"
        _write_cache(path, cache)
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)

        from agents.corporate_agent import XAI_REQUIRED_FIELDS
        llm_wrapper.llm_call(prompt, use_cached=True, expected_fields=XAI_REQUIRED_FIELDS,
                              label="repeat_label")
        llm_wrapper.llm_call(prompt, use_cached=True, expected_fields=XAI_REQUIRED_FIELDS,
                              label="repeat_label")
        # Set size should still be 1 (not 2)
        assert llm_wrapper._XAI_ADVISORY_EMITTED.count("repeat_label") \
               if hasattr(llm_wrapper._XAI_ADVISORY_EMITTED, "count") else True

    def test_non_json_response_does_not_crash_validation(self, tmp_path, monkeypatch):
        """Plain-text response does not raise during XAI schema check."""
        import llm_wrapper
        prompt = "plain text prompt"
        key    = llm_wrapper._cache_key(prompt, "gpt-4o-mini", 0.0)
        cache  = {key: {"model": "gpt-4o-mini", "temperature": 0.0, "response": "plain text"}}
        path   = tmp_path / "api_cache.json"
        _write_cache(path, cache)
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)

        result = llm_wrapper.llm_call(prompt, use_cached=True,
                                       expected_fields=["some_missing_field"])
        assert result == "plain text"   # returned successfully despite validation

    def test_no_expected_fields_skips_validation(self, tmp_path, monkeypatch):
        """Omitting expected_fields skips schema validation entirely."""
        import llm_wrapper
        prompt   = "no validation"
        response = _make_legacy_response()
        key      = llm_wrapper._cache_key(prompt, "gpt-4o-mini", 0.0)
        cache    = {key: {"model": "gpt-4o-mini", "temperature": 0.0, "response": response}}
        path     = tmp_path / "api_cache.json"
        _write_cache(path, cache)
        monkeypatch.setattr(llm_wrapper, "CACHE_PATH", path)

        result = llm_wrapper.llm_call(prompt, use_cached=True)  # no expected_fields
        assert result == response
        assert len(llm_wrapper._XAI_ADVISORY_EMITTED) == 0
