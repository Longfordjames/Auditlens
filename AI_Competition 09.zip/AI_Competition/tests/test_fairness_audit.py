# MIT License — see LICENSE file
"""
tests/test_fairness_audit.py
==============================
Unit tests for the Fairness & Bias Audit Engine.

Coverage:
  • Cohort statistics computation (avg I_d, WACC, ΔRI).
  • Neutrality test logic: confirmed / bias indicator / inconclusive.
  • Division-by-zero guard: missing region → INCONCLUSIVE (no crash).
  • Empty results list → graceful handling.
  • Output file written: Markdown is valid and non-empty.
  • Mixed region scan: entries correctly partitioned.

All tests are 100% offline.
"""

import math
from pathlib import Path

import pytest

from fairness_audit import (
    NEUTRALITY_TOLERANCE,
    REGION_MAP,
    _cohort_stats,
    _neutrality_check,
    run_fairness_audit,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

def _row(company, id_val, wacc_bps, delta_ri_pct):
    return {
        "company_name": company,
        "display_name": company.upper(),
        "id_val":       id_val,
        "wacc_bps":     wacc_bps,
        "delta_ri_pct": delta_ri_pct,
        "risk_level":   "HIGH" if wacc_bps > 0 else "LOW",
        "risk_flag":    "HIGH-RISK STRATEGIC OBFUSCATION" if wacc_bps > 0 else "AUTHENTIC TRANSITION LEADER",
    }


_SHELL_ROW  = _row("shell",         0.065, 150,  964.6)
_BP_ROW     = _row("bp",            1.835, 100,   28.9)
_ORSTED_ROW = _row("orsted",       -0.805, -50,  -87.5)
_TOTAL_ROW  = _row("totalenergies", 1.990, 100,   30.0)

_ALL_ROWS   = [_SHELL_ROW, _BP_ROW, _ORSTED_ROW, _TOTAL_ROW]


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Cohort statistics
# ═══════════════════════════════════════════════════════════════════════════════

class TestCohortStats:
    """_cohort_stats correctly averages fields."""

    def test_empty_cohort_returns_nulls(self):
        stats = _cohort_stats([])
        assert stats["n"] == 0
        assert stats["avg_id"] is None
        assert stats["avg_wacc_bps"] is None

    def test_single_row_equals_itself(self):
        stats = _cohort_stats([_SHELL_ROW])
        assert abs(stats["avg_id"]       - _SHELL_ROW["id_val"]) < 1e-6
        assert abs(stats["avg_wacc_bps"] - _SHELL_ROW["wacc_bps"]) < 1e-6

    def test_two_rows_averaged(self):
        rows  = [_row("a", 1.0, 100, 50.0), _row("b", 3.0, 200, 150.0)]
        stats = _cohort_stats(rows)
        assert abs(stats["avg_id"]         - 2.0)   < 1e-6
        assert abs(stats["avg_wacc_bps"]   - 150.0) < 1e-6
        assert abs(stats["avg_delta_ri_pct"] - 100.0) < 1e-6

    def test_n_matches_input(self):
        assert _cohort_stats(_ALL_ROWS[:2])["n"] == 2

    def test_companies_list_in_output(self):
        stats = _cohort_stats([_SHELL_ROW, _BP_ROW])
        assert "shell" in stats["companies"]
        assert "bp"    in stats["companies"]


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Neutrality check
# ═══════════════════════════════════════════════════════════════════════════════

class TestNeutralityCheck:
    """_neutrality_check logic gates."""

    def _stats(self, rows):
        return _cohort_stats(rows)

    def test_missing_uk_returns_inconclusive(self):
        uk = _cohort_stats([])
        eu = _cohort_stats([_ORSTED_ROW])
        status, _, ratio = _neutrality_check(uk, eu)
        assert "INCONCLUSIVE" in status
        assert ratio is None

    def test_missing_eu_returns_inconclusive(self):
        uk = _cohort_stats([_SHELL_ROW])
        eu = _cohort_stats([])
        status, _, ratio = _neutrality_check(uk, eu)
        assert "INCONCLUSIVE" in status

    def test_proportional_difference_confirms_neutrality(self):
        """Build cohorts where I_d difference exactly tracks ΔRI difference."""
        # ΔRI diff = 50 pp → I_d diff = 0.5 → ratio = 0.5/(50/100) = 1.0 ≤ 1.5
        uk = _cohort_stats([_row("uk", 0.5, 100, 75.0)])
        eu = _cohort_stats([_row("eu", 0.0,   0, 25.0)])
        status, _, ratio = _neutrality_check(uk, eu)
        assert ratio <= NEUTRALITY_TOLERANCE
        assert "CONFIRMED" in status

    def test_disproportionate_difference_flags_bias(self):
        """I_d diff >> ΔRI diff → BIAS INDICATOR."""
        # ΔRI diff = 1 pp, I_d diff = 5.0 → ratio = 5.0/(1/100) = 500 >> 1.5
        uk = _cohort_stats([_row("uk", 5.0, 100, 1.5)])
        eu = _cohort_stats([_row("eu", 0.0,   0, 0.5)])
        status, _, ratio = _neutrality_check(uk, eu)
        assert ratio > NEUTRALITY_TOLERANCE
        assert "BIAS" in status

    def test_identical_cohorts_confirmed_neutral(self):
        """Identical averages → CONFIRMED."""
        uk = _cohort_stats([_row("a", 1.0, 100, 50.0)])
        eu = _cohort_stats([_row("b", 1.0, 100, 50.0)])
        status, _, ratio = _neutrality_check(uk, eu)
        assert "CONFIRMED" in status
        assert ratio == 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Full audit run
# ═══════════════════════════════════════════════════════════════════════════════

class TestRunFairnessAudit:
    """Integration tests for run_fairness_audit()."""

    def test_full_scan_returns_required_keys(self, tmp_path):
        result = run_fairness_audit(_ALL_ROWS, output_path=tmp_path / "fd.md")
        required = {
            "uk_stats", "eu_stats", "neutrality_status",
            "neutrality_explanation", "id_ri_ratio", "output_path",
        }
        assert required.issubset(result.keys())

    def test_uk_cohort_contains_shell_and_bp(self, tmp_path):
        result = run_fairness_audit(_ALL_ROWS, output_path=tmp_path / "fd.md")
        companies = result["uk_stats"]["companies"]
        assert "shell" in companies
        assert "bp"    in companies

    def test_eu_cohort_contains_orsted_and_total(self, tmp_path):
        result = run_fairness_audit(_ALL_ROWS, output_path=tmp_path / "fd.md")
        companies = result["eu_stats"]["companies"]
        assert "orsted"        in companies
        assert "totalenergies" in companies

    def test_output_file_written(self, tmp_path):
        path = tmp_path / "fd.md"
        run_fairness_audit(_ALL_ROWS, output_path=path)
        assert path.exists()
        content = path.read_text()
        assert len(content) > 100

    def test_output_mentions_neutrality_result(self, tmp_path):
        path = tmp_path / "fd.md"
        run_fairness_audit(_ALL_ROWS, output_path=path)
        content = path.read_text()
        assert "NEUTRALITY" in content or "BIAS" in content

    def test_empty_results_no_crash(self, tmp_path):
        """Empty list → INCONCLUSIVE, no exception."""
        result = run_fairness_audit([], output_path=tmp_path / "empty.md")
        assert "INCONCLUSIVE" in result["neutrality_status"]

    def test_uk_only_no_crash(self, tmp_path):
        """Only UK companies → INCONCLUSIVE (no EU cohort)."""
        result = run_fairness_audit(
            [_SHELL_ROW, _BP_ROW], output_path=tmp_path / "uk_only.md"
        )
        assert "INCONCLUSIVE" in result["neutrality_status"]

    def test_custom_region_map_applied(self, tmp_path):
        """Custom region_map re-partitions correctly."""
        custom_map = {"shell": "EU", "bp": "UK", "orsted": "EU", "totalenergies": "UK"}
        result = run_fairness_audit(
            _ALL_ROWS, output_path=tmp_path / "custom.md", region_map=custom_map,
        )
        uk = result["uk_stats"]["companies"]
        eu = result["eu_stats"]["companies"]
        assert "bp"           in uk
        assert "totalenergies" in uk
        assert "shell"         in eu
        assert "orsted"        in eu

    def test_ratio_is_finite_or_none(self, tmp_path):
        """id_ri_ratio is a finite float or None (not Inf or NaN)."""
        result = run_fairness_audit(_ALL_ROWS, output_path=tmp_path / "r.md")
        ratio = result["id_ri_ratio"]
        if ratio is not None:
            assert math.isfinite(ratio)
