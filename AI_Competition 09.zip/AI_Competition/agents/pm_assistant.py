# MIT License — see LICENSE file
"""
AuditLens PM Assistant — Strict-RAG Fiduciary Chat Agent
==========================================================
Provides an interactive conversational interface allowing Portfolio Managers
to interrogate MAD Protocol findings in natural language.

Design principles:
  • **Strict-RAG:** The LLM is constrained ONLY to the pre-computed AuditLens
    JSON context injected into the system prompt. Out-of-scope questions are
    explicitly refused.
  • **Token minification:** Raw CSV records are stripped before injection;
    only core analytical fields (I_d, wacc_bps, risk_flag, cross_checks,
    hedging_phrases) are serialised, keeping the context window tight.
  • **Hallucination prevention:** The system prompt mandates verbatim citation
    of source_citation / hedging_phrases when explaining any WACC or I_d figure.
  • **CFA Rule 4.4 offline mode:** When ``--use-cached`` is passed, a hardcoded
    3-turn demo conversation is played back without any API call, guaranteeing
    $0 reproducibility for judges.
  • **Audit trail:** Every Q&A turn is appended to ``data/chat_audit_trail.txt``
    for fiduciary traceability.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

# Rich imports at module level so they can be patched in tests
from rich.console import Console as _Console
from rich.panel import Panel as _Panel
from rich.prompt import Prompt
from rich.rule import Rule as _Rule
from rich.text import Text as _Text

try:
    from llm_wrapper import llm_call
except ImportError:  # allow import without full project environment
    llm_call = None  # type: ignore[assignment]

logger = logging.getLogger("PM_ASSISTANT")

_DATA_DIR   = Path(__file__).parent.parent / "data"
_AUDIT_FILE = _DATA_DIR / "chat_audit_trail.txt"

# ── Token minification ────────────────────────────────────────────────────────

_CONTEXT_KEYS = {
    "company_name", "display_name", "id_val", "risk_flag", "risk_level",
    "wacc_bps", "integrity_score", "delta_ri_pct", "delta_sentiment",
    "disclosure_density", "arb_flag", "sentiment_source",
}

_CORP_KEYS = {
    "display_name", "delta_narrative_sentiment", "sentiment_2015",
    "sentiment_2021", "sentiment_2024", "hedging_phrases_2024",
    "transition_phrases_2024", "reasoning_2024", "max_ai_variance",
    "high_ambiguity_flag", "dual_model_active", "source", "source_url",
}

_SCEPTIC_KEYS = {
    "integrity_discount", "risk_flag", "risk_level", "explanation",
    "cross_checks", "valuation_impact_bps", "valuation_action",
}

_PORTFOLIO_KEYS = {
    "company_name", "display_name", "baseline_weight_pct",
    "optimized_weight_pct", "delta_weight_pct", "delta_capital_usd",
    "wacc_bps", "tilt_multiplier", "risk_flag",
}


def minify_context(
    scan_results:   List[Dict],
    portfolio_data: Optional[Dict] = None,
    report_data:    Optional[Dict] = None,
) -> dict:
    """
    Strip heavy raw_records and unused fields from context before LLM injection.

    Keeps only the analytical fields the PM Assistant needs to answer
    fiduciary questions. This prevents context-window overflow and avoids
    sending raw CSV rows to the LLM.

    Parameters
    ----------
    scan_results   : list  Raw sector-scan rows from ``_sector_scan_company``.
    portfolio_data : dict  Output from ``portfolio_optimizer``.
    report_data    : dict  Optional per-company MAD Protocol report JSON.

    Returns
    -------
    dict  Minified context safe for system-prompt injection.
    """
    minified_scan = []
    for r in scan_results:
        row = {k: v for k, v in r.items() if k in _CONTEXT_KEYS}
        minified_scan.append(row)

    context: Dict = {"scan_results": minified_scan}

    if portfolio_data:
        context["portfolio"] = {
            "aum_usd":          portfolio_data.get("aum_usd"),
            "n_assets":         portfolio_data.get("n_assets"),
            "weight_sum_check": portfolio_data.get("weight_sum_check"),
            "positions": [
                {k: v for k, v in p.items() if k in _PORTFOLIO_KEYS}
                for p in portfolio_data.get("positions", [])
            ],
        }

    if report_data:
        corp = report_data.get("layers", {}).get("corporate_agent", {})
        sept = report_data.get("layers", {}).get("sceptic_agent", {})
        context["shell_report"] = {
            "corporate": {k: v for k, v in corp.items() if k in _CORP_KEYS},
            "sceptic":   {k: v for k, v in sept.items() if k in _SCEPTIC_KEYS},
        }

    return context


def _build_system_prompt(context: dict) -> str:
    """Build the strict-RAG system prompt with minified JSON context."""
    ctx_json = json.dumps(context, indent=2, ensure_ascii=False, default=str)
    return (
        "You are a Fiduciary ESG Assistant embedded within the AuditLens MAD Protocol.\n\n"
        "STRICT CONSTRAINTS (read carefully before responding):\n"
        "1. You MUST answer using ONLY the provided AuditLens JSON context below.\n"
        "2. If a question cannot be answered from the context, respond:\n"
        "   'This question falls outside the AuditLens audit scope. "
        "I can only answer questions grounded in the provided MAD Protocol findings.'\n"
        "3. ALWAYS cite the exact 'source_citation' or verbatim 'hedging_phrases' "
        "when explaining any WACC penalty or I_d score.\n"
        "4. NEVER fabricate data, NEVER speculate beyond the JSON context.\n"
        "5. Keep answers concise (≤200 words), fiduciary in tone, and cite evidence.\n\n"
        "=== AUDITLENS CONTEXT (MAD PROTOCOL OUTPUT) ===\n"
        f"{ctx_json}\n"
        "=== END CONTEXT ==="
    )


# ── Demo conversation (CFA Rule 4.4 cached playback) ─────────────────────────

_DEMO_TURNS = [
    (
        "Why did Shell's optimized weight increase?",
        (
            "Under the **refreshed sector CSVs** (team ESG workbook → `data/energy_sector/`), "
            "Shell shows **declining total energy consumption** on the mapped 2015→2024 nodes "
            "(ΔResource ≈ **−15.5%**) with **positive** ΔSentiment. That puts Shell on the "
            "**authentic-transition branch**: I_d ≈ **−3.73** (negative) and a **WACC green "
            "premium of −50 bps**.\n\n"
            "The optimiser therefore **adds** about **+1.83%** weight (≈ **+$1.83M** on a "
            "$100M AUM baseline) versus the 25% equal-weight benchmark — WACC signal "
            "**-50 bps** green premium and tilt `max(0.1, 1.0 - (-50)/500) = 1.10×`.\n\n"
            "*(Figures from the latest `portfolio_optimization.json` after `--sector-scan "
            "--use-cached`; CSV cites internal workbook rows with Phase 2 filing cross-walk "
            "pending.)*"
        ),
    ),
    (
        "Why was Ørsted allocated more capital?",
        (
            "Ørsted remains the **deepest negative I_d** name in the scan (≈ **−10.02**): "
            "ΔResource ≈ **−8.8%** on total energy consumption with strong positive ΔSentiment, "
            "so the denominator is negative and I_d stays **firmly negative**.\n\n"
            "It receives the same **−50 bps** green premium and **1.10×** tilt as Shell/BP in "
            "this demo snapshot, with an overweight of about **+1.83%** (≈ **+$1.83M**). "
            "Jurisdictional Arbitrage = **0** (EU-CSRD framing in the audit CSV).\n\n"
            "*(Source chain: `orsted_public_audit_2024.csv` + pre-seeded `narrative_sentiment` "
            "rows for cached runs.)*"
        ),
    ),
    (
        "What is the total capital redirected from high-risk to authentic leaders?",
        (
            "In the **four-name** sector scan, **TotalEnergies** is the lone **HIGH-RISK** "
            "obfuscator on the refreshed inputs (I_d ≈ **+8.71**, **+100 bps** penalty, "
            "**0.80×** tilt). Its weight falls by about **−5.49%** (≈ **−$5.49M**).\n\n"
            "**Ørsted, Shell, and BP** each gain ≈ **+$1.83M** (~**+1.83%**), funding the "
            "divestment from Total on a **$100M** long-only book. Sum of Δ_capital rounds to "
            "**~$0** (no external cash).\n\n"
            "*(Derived from `data/portfolio_optimization.json` — AuditLens MAD Protocol v1.0.)*"
        ),
    ),
]


def _playback_demo(audit_trail: List[str]) -> None:
    """Render the 3-turn cached demo conversation without any API call."""
    console = _Console(highlight=False)
    console.print(_Panel(
        _Text(
            "  ⚡ CACHED PLAYBACK MODE (CFA Rule 4.4) — No API key required.\n"
            "  Replaying 3-turn demo conversation. Run without --use-cached\n"
            "  for live interrogation of the current audit findings.",
            style="bold yellow",
        ),
        title="[bold white on dark_orange]  PM ASSISTANT — DEMO MODE  [/bold white on dark_orange]",
        border_style="yellow",
        padding=(0, 1),
    ))

    for i, (question, answer) in enumerate(_DEMO_TURNS, 1):
        console.print(_Rule(f" Demo Turn {i}/{len(_DEMO_TURNS)} ", style="dim yellow"))
        console.print(f"[bold blue]PM >[/bold blue] {question}\n")
        console.print(_Panel(
            f"[dim yellow][Cached Playback][/dim yellow] {answer}",
            title="[bold green]  Fiduciary ESG Assistant  [/bold green]",
            border_style="green",
            padding=(0, 1),
        ))
        audit_trail.append(f"[DEMO] PM: {question}")
        audit_trail.append(f"[DEMO] ASSISTANT: {answer}")

    console.print(_Panel(
        _Text(
            "  Demo complete. To interrogate live audit data, run:\n"
            "  python run_auditlens.py --sector-scan --chat",
            style="dim white",
        ),
        border_style="dim yellow",
        padding=(0, 1),
    ))


# ── Live chat loop ────────────────────────────────────────────────────────────

def run_chat_loop(
    context_data: dict,
    use_cached:   bool = False,
    audit_path:   Path = _AUDIT_FILE,
) -> None:
    """
    Launch the interactive PM Assistant chat loop.

    Parameters
    ----------
    context_data : dict  Minified context from ``minify_context()``.
    use_cached   : bool  If True, plays back the hardcoded demo (no API call).
    audit_path   : Path  Destination for the chat audit trail.
    """
    console = _Console(highlight=False)
    audit_trail: List[str] = [
        f"=== AuditLens PM Assistant Session — {datetime.now(tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} ===",
        f"Mode: {'DEMO (cached playback)' if use_cached else 'LIVE'}",
        "",
    ]

    console.print(_Rule(" ◈  LAUNCHING FIDUCIARY PM ASSISTANT  ◈ ", style="bold green"))
    console.print(_Panel(
        _Text(
            "  Strict-RAG Fiduciary ESG Assistant — AuditLens MAD Protocol v1.0\n"
            "  Context: pre-computed audit findings (I_d, WACC, hedging phrases)\n"
            "  Constraints: answers grounded exclusively in provided JSON context\n"
            "  Type 'exit' or 'quit' to end session. Ctrl+C also exits cleanly.",
            style="white",
        ),
        title="[bold white]  🤖  PM ASSISTANT  [/bold white]",
        border_style="bold green",
        padding=(0, 1),
    ))

    # ── Cached demo mode ──────────────────────────────────────────────────────
    if use_cached:
        _playback_demo(audit_trail)
        _write_audit_trail(audit_trail, audit_path)
        return

    # ── Live mode ─────────────────────────────────────────────────────────────
    system_prompt = _build_system_prompt(context_data)

    if llm_call is None:
        console.print(_Panel(
            _Text(
                "  llm_wrapper import failed. Ensure AuditLens is run from the\n"
                "  repository root. Use --use-cached for demo mode.",
                style="red",
            ),
            border_style="red",
        ))
        return

    messages: List[dict] = []
    console.print("[dim]Session started. Questions are answered exclusively from AuditLens findings.[/dim]\n")

    while True:
        try:
            question = Prompt.ask("[bold blue]PM >[/bold blue]")
        except KeyboardInterrupt:
            console.print("\n[dim]Session interrupted. Writing audit trail...[/dim]")
            break

        q_lower = question.strip().lower()
        if q_lower in {"exit", "quit", "q", ":q"}:
            console.print("[dim]Session ended by PM. Writing audit trail...[/dim]")
            break
        if not question.strip():
            continue

        audit_trail.append(f"PM: {question}")
        messages.append({"role": "user", "content": question})

        # Build full prompt for caching (system + conversation history)
        full_prompt = (
            system_prompt + "\n\n"
            + "\n".join(
                f"{'PM' if m['role']=='user' else 'ASSISTANT'}: {m['content']}"
                for m in messages
            )
        )

        try:
            answer = llm_call(
                prompt=full_prompt,
                model="gpt-4o-mini",
                provider="openai",
                use_cached=False,  # live chat always calls live API
                temperature=0.0,
                label=f"PMAssistant_turn_{len(messages)}",
            )
        except (RuntimeError, EnvironmentError, OSError, ConnectionError, TimeoutError) as exc:
            answer = (
                f"[Assistant offline] {type(exc).__name__}: {exc}\n"
                "Use --use-cached for demo mode (CFA Rule 4.4)."
            )
        except Exception as exc:
            answer = (
                f"[Assistant error] {type(exc).__name__}: {exc}\n"
                "Check pip install -r requirements.txt or use --use-cached."
            )

        messages.append({"role": "assistant", "content": answer})
        audit_trail.append(f"ASSISTANT: {answer}")

        console.print(_Panel(
            answer,
            title="[bold green]  Fiduciary ESG Assistant  [/bold green]",
            border_style="green",
            padding=(0, 1),
        ))

    _write_audit_trail(audit_trail, audit_path)
    console.print(_Panel(
        _Text(f"  📋  Chat audit trail → {audit_path}", style="bold green"),
        title="[bold white]Session Complete[/bold white]",
        border_style="dim green",
        padding=(0, 1),
    ))


def _write_audit_trail(audit_trail: List[str], audit_path: Path) -> None:
    """Append the chat session transcript to the audit trail file."""
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with open(audit_path, "a", encoding="utf-8") as fh:
        fh.write("\n".join(audit_trail))
        fh.write("\n\n")
    logger.info("PM_ASSISTANT  Audit trail appended → %s", audit_path)
