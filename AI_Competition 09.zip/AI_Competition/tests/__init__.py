# MIT License — see LICENSE file
"""
AuditLens Test Suite
====================
Comprehensive pytest coverage for the MAD Protocol components.

Modules tested:
  test_sceptic_agent  — I_d formula correctness, edge cases, risk classification
  test_data_loader    — CSV schema validation, CFA Rule 4.6, derived calculations
  test_llm_wrapper    — Cache I/O, CFA Rule 4.4 fallback, XAI schema validation

All tests run 100% offline (zero API calls) via unittest.mock.
"""
