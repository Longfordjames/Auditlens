# MIT License — see LICENSE file
"""
tests/test_provenance_logger.py
================================
Unit tests for the Provenance Ledger Generator.

Coverage:
  • JSON output schema: required top-level keys present.
  • Entry schema:       all required fields in every entry.
  • source_url mapping: at least one entry resolves to a non-empty URL.
  • Empty raw_records:  graceful degradation (no KeyError, entries still written).
  • Missing raw_records key: no crash.
  • Multi-company batch: entries from all companies appear in one ledger.
  • Output file written: JSON is valid and loadable.
  • Entry count:         total_entries field matches len(entries).

All tests are 100% offline — no API calls, no live data, no network.
"""

import json
from pathlib import Path

import pytest

from exporters.provenance_logger import (
    PROVENANCE_LEDGER_SCHEMA_VERSION,
    _build_company_entries,
    _scan_result_to_report,
    generate_provenance_ledger,
)


# ── Minimal report fixture ────────────────────────────────────────────────────

def _csv_row(metric, value, year, citation, url) -> dict:
    return {
        "metric":           metric,
        "value":            value,
        "unit":             "TJ",
        "year":             year,
        "source_citation":  citation,
        "source_url":       url,
    }


def _make_report(company="shell", with_records=True, with_hedging=True):
    raw = (
        [
            _csv_row("Upstream Natural Gas Fuel Consumption", "1130000", 2015,
                     "Shell Sustainability Report 2015, p.42",
                     "https://reports.shell.com/sustainability-report/2015/"),
            _csv_row("Upstream Natural Gas Fuel Consumption", "12030000", 2024,
                     "Shell Annual Report 2024, p.78",
                     "https://reports.shell.com/annual-report/2024/"),
            _csv_row("General ESG Disclosure Score", "74.0", 2024,
                     "Shell Annual Report FY2024, Appendix IV",
                     "https://reports.shell.com/annual-report/2024/"),
            _csv_row("Jurisdictional Arbitrage Flag", "1", 2024,
                     "Companies House UK Filing, CH No. 04366849",
                     "https://find-and-update.company-information.service.gov.uk/company/04366849"),
        ]
        if with_records else []
    )
    return {
        "system": {"company": company, "display_name": company.upper()},
        "layers": {
            "corporate_agent": {
                "source":       "Shell Annual Report 2024 p.3",
                "source_url":   "https://reports.shell.com/annual-report/2024/",
                "hedging_phrases_2024": (
                    ["while ensuring we supply the energy the world needs today",
                     "balancing short-term security with long-term goals"]
                    if with_hedging else []
                ),
                "transition_phrases_2024": ["net-zero by 2050"],
                "score_openai_2024":    0.72,
                "score_anthropic_2024": 0.65,
                "score_openai_2015":    0.18,
                "score_anthropic_2015": 0.20,
            },
            "auditor_agent": {
                "delta_resource_intensity": 9.646,
                "disclosure_density":       0.74,
                "jurisdictional_arbitrage": 1,
                "raw_records":              raw,
            },
            "sceptic_agent": {
                "integrity_discount":    0.076,
                "risk_flag":             "HIGH-RISK STRATEGIC OBFUSCATION",
                "valuation_impact_bps":  150,
                "valuation_action":      "DOWNGRADE: Increase discount rate by +150bps",
                "formula_inputs": {
                    "delta_narrative_sentiment": 0.47,
                    "delta_resource_intensity":  9.646,
                    "disclosure_density":        0.74,
                    "denominator":               7.138,
                },
            },
        },
        "verdict": {
            "integrity_discount":    0.076,
            "risk_flag":             "HIGH-RISK STRATEGIC OBFUSCATION",
            "valuation_impact_bps":  150,
            "valuation_action":      "DOWNGRADE",
        },
        "raw_records": raw,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Output JSON schema
# ═══════════════════════════════════════════════════════════════════════════════

class TestOutputSchema:
    """Top-level ledger keys must all be present."""

    REQUIRED_TOP = {"generated_at", "schema_version", "total_entries",
                    "cfa_rule_46_statement", "entries"}

    def test_top_level_keys_present(self, tmp_path):
        rpt = _make_report()
        path = generate_provenance_ledger(rpt, output_dir=tmp_path)
        data = json.loads(path.read_text())
        assert self.REQUIRED_TOP.issubset(data.keys())

    def test_entries_is_list(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        assert isinstance(data["entries"], list)

    def test_total_entries_matches_list_len(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        assert data["total_entries"] == len(data["entries"])

    def test_schema_version_matches_module_constant(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        assert data["schema_version"] == PROVENANCE_LEDGER_SCHEMA_VERSION

    def test_output_is_valid_json(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        # Should not raise
        data = json.loads(path.read_text())
        assert data is not None


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Entry schema
# ═══════════════════════════════════════════════════════════════════════════════

class TestEntrySchema:
    """Every entry must have all required fields."""

    REQUIRED_ENTRY = {
        "company_name", "display_name", "conclusion_id", "conclusion_text",
        "analytical_value", "dependency_type", "csv_metric", "csv_year",
        "csv_value", "source_citation", "source_url",
    }

    def test_all_entries_have_required_fields(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        for entry in data["entries"]:
            missing = self.REQUIRED_ENTRY - set(entry.keys())
            assert not missing, f"Entry {entry.get('conclusion_id')} missing: {missing}"

    def test_conclusion_ids_are_unique(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        ids = [e["conclusion_id"] for e in data["entries"]]
        assert len(ids) == len(set(ids)), "Duplicate conclusion_ids found"

    def test_dependency_types_are_valid(self, tmp_path):
        valid = {"METRIC", "FORMULA", "LEXICAL", "SENTIMENT"}
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        for entry in data["entries"]:
            assert entry["dependency_type"] in valid, (
                f"Unknown dependency_type: {entry['dependency_type']}"
            )


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Source URL mapping (CFA Rule 4.6)
# ═══════════════════════════════════════════════════════════════════════════════

class TestSourceURLMapping:
    """At least one METRIC entry must resolve to a non-empty source_url."""

    def test_at_least_one_entry_has_source_url(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        urls = [e["source_url"] for e in data["entries"] if e["source_url"]]
        assert len(urls) > 0, "No entry has a non-empty source_url"

    def test_fuel_base_entry_has_url(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        fuel_entries = [e for e in data["entries"] if "fuel_base" in e["conclusion_id"]]
        assert len(fuel_entries) > 0
        assert any(e["source_url"] for e in fuel_entries)

    def test_arb_entry_has_companies_house_url(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        arb_entries = [e for e in data["entries"] if "jurisdictional_arbitrage" in e["conclusion_id"]]
        assert len(arb_entries) > 0
        assert any("company" in e["source_url"].lower() or "shell" in e["source_url"].lower()
                   for e in arb_entries)

    def test_lexical_entry_has_source_url(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        lex_entries = [e for e in data["entries"] if e["dependency_type"] == "LEXICAL"
                       and "MISSING" not in e["conclusion_id"] and "NONE" not in e["conclusion_id"]]
        assert len(lex_entries) > 0
        assert any(e["source_url"] for e in lex_entries)


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Graceful degradation — empty / missing raw_records
# ═══════════════════════════════════════════════════════════════════════════════

class TestGracefulDegradation:
    """Empty or missing raw_records must not raise KeyError or crash."""

    def test_empty_raw_records_no_crash(self, tmp_path):
        """Empty raw_records → ledger still written, entries have WARNING stubs."""
        rpt = _make_report(with_records=False)
        path = generate_provenance_ledger(rpt, output_dir=tmp_path)
        data = json.loads(path.read_text())
        assert data["total_entries"] > 0     # formula + sentiment entries still present

    def test_missing_raw_records_key_no_crash(self, tmp_path):
        """Report dict with no raw_records key at all → no KeyError."""
        rpt = _make_report()
        del rpt["raw_records"]
        rpt["layers"]["auditor_agent"].pop("raw_records", None)
        path = generate_provenance_ledger(rpt, output_dir=tmp_path)
        data = json.loads(path.read_text())
        assert isinstance(data["entries"], list)

    def test_empty_hedging_phrases_no_crash(self, tmp_path):
        """No hedging phrases → NONE stub entry, no crash."""
        rpt = _make_report(with_hedging=False)
        path = generate_provenance_ledger(rpt, output_dir=tmp_path)
        data = json.loads(path.read_text())
        none_entries = [e for e in data["entries"] if "NONE" in e.get("conclusion_id", "")]
        assert len(none_entries) >= 1

    def test_empty_report_list_no_crash(self, tmp_path):
        """Passing an empty list → writes a ledger with 0 entries."""
        path = generate_provenance_ledger([], output_dir=tmp_path)
        data = json.loads(path.read_text())
        assert data["total_entries"] == 0
        assert data["entries"] == []


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Multi-company batch
# ═══════════════════════════════════════════════════════════════════════════════

class TestMultiCompanyBatch:
    """Entries from all companies must appear in a single ledger."""

    def test_two_companies_both_present(self, tmp_path):
        shell = _make_report("shell")
        orsted = _make_report("orsted")
        path = generate_provenance_ledger([shell, orsted], output_dir=tmp_path)
        data = json.loads(path.read_text())
        companies = {e["company_name"] for e in data["entries"]}
        assert "shell" in companies
        assert "orsted" in companies

    def test_total_entries_sums_both(self, tmp_path):
        """Total entries ≈ sum of both companies' individual entry counts."""
        shell_entries  = _build_company_entries(_make_report("shell"))
        orsted_entries = _build_company_entries(_make_report("orsted"))
        path = generate_provenance_ledger(
            [_make_report("shell"), _make_report("orsted")], output_dir=tmp_path
        )
        data = json.loads(path.read_text())
        assert data["total_entries"] == len(shell_entries) + len(orsted_entries)


# ═══════════════════════════════════════════════════════════════════════════════
# 6. Specific conclusion entries
# ═══════════════════════════════════════════════════════════════════════════════

class TestSpecificEntries:
    """Key conclusions must be traceable."""

    def test_id_formula_entry_exists(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        ids = [e["conclusion_id"] for e in data["entries"]]
        assert "shell:id_formula" in ids

    def test_wacc_penalty_entry_exists(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        ids = [e["conclusion_id"] for e in data["entries"]]
        assert "shell:wacc_penalty" in ids

    def test_sentiment_entries_present(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        sent = [e for e in data["entries"] if e["dependency_type"] == "SENTIMENT"]
        assert len(sent) >= 2   # 2015 + 2024 nodes

    def test_hedging_phrase_verbatim_in_value(self, tmp_path):
        path = generate_provenance_ledger(_make_report(), output_dir=tmp_path)
        data = json.loads(path.read_text())
        lex = [e for e in data["entries"]
               if e["dependency_type"] == "LEXICAL" and "NONE" not in e["conclusion_id"]]
        assert any("supply" in e["analytical_value"] or "energy" in e["analytical_value"]
                   for e in lex)


# ═══════════════════════════════════════════════════════════════════════════════
# 7. Sector-scan style rows (no ``layers`` key)
# ═══════════════════════════════════════════════════════════════════════════════

def _make_scan_result_row(company="shell"):
    """Minimal Integrity Leaderboard row as produced by ``_sector_scan_company``."""
    rpt = _make_report(company)
    aud = rpt["layers"]["auditor_agent"]
    corp = rpt["layers"]["corporate_agent"]
    scep = rpt["layers"]["sceptic_agent"]
    ver = rpt["verdict"]
    delta_ri = aud["delta_resource_intensity"]
    return {
        "company_name": company,
        "display_name": rpt["system"]["display_name"],
        "sentiment_2024": 0.72,
        "delta_sentiment": 0.47,
        "delta_ri": delta_ri,
        "delta_ri_pct": round(delta_ri * 100, 1),
        "disclosure_density": aud["disclosure_density"],
        "id_val": ver["integrity_discount"],
        "risk_flag": ver["risk_flag"],
        "risk_level": "HIGH",
        "wacc_bps": ver["valuation_impact_bps"],
        "valuation_action": scep.get("valuation_action", ""),
        "integrity_score": 0.5,
        "sentiment_source": "LLM Dual-Model",
        "arb_flag": aud["jurisdictional_arbitrage"],
        "raw_records": aud["raw_records"],
        "corporate_agent": corp,
        "formula_inputs": scep.get("formula_inputs", {}),
    }


class TestScanResultsLedgerPath:
    """``generate_provenance_ledger`` accepts sector-scan result lists."""

    def test_scan_results_list_produces_urls(self, tmp_path):
        row = _make_scan_result_row("shell")
        path = generate_provenance_ledger([row], output_dir=tmp_path)
        data = json.loads(path.read_text())
        urls = [e["source_url"] for e in data["entries"] if e.get("source_url")]
        assert any(u.startswith("http") for u in urls)

    def test_scan_results_missing_optional_keys_no_keyerror(self, tmp_path):
        sparse = {"company_name": "acme", "display_name": "ACME"}
        path = generate_provenance_ledger([sparse], output_dir=tmp_path)
        data = json.loads(path.read_text())
        assert isinstance(data["entries"], list)
        assert data["total_entries"] >= 1

    def test_scan_result_to_report_roundtrip(self):
        row = _make_scan_result_row()
        mini = _scan_result_to_report(row)
        assert "layers" in mini
        assert mini["layers"]["auditor_agent"]["raw_records"] == row["raw_records"]
