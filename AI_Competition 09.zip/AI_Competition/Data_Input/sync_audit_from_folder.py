#!/usr/bin/env python3
# MIT License — see LICENSE file
"""
Data_Input auto-sync: Excel (primary) + PDF fallback + narrative excerpt YAML.

Reads config/mapping.json for metric aliases, Data_Input/manifest.yaml for
per-company paths and PDF rules, writes:

  Data_Input/{company}_public_audit_2024.csv
  Data_Input/narratives/{company}_excerpts.yaml   (when PDF text available)

Does not modify api_cache.json. After changing narratives, regenerate LLM cache
in live mode (see Data_Input/README.md).

Usage:
  python3 Data_Input/sync_audit_from_folder.py [--company SLUG|all]
      [--dry-run] [--verbose] [--write-sector] [--validate-only]
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import importlib.util
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Repository root (parent of Data_Input/)
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from config.audit_profile import get_event_study

_EXCEL_SPEC = importlib.util.spec_from_file_location(
    "data_input_excel_io", Path(__file__).resolve().parent / "excel_io.py"
)
_excel_mod = importlib.util.module_from_spec(_EXCEL_SPEC)
assert _EXCEL_SPEC.loader is not None
_EXCEL_SPEC.loader.exec_module(_excel_mod)
find_header_row = _excel_mod.find_header_row
read_excel_grid = _excel_mod.read_excel_grid
DATA_INPUT = REPO_ROOT / "Data_Input"
MANIFEST_PATH = DATA_INPUT / "manifest.yaml"
MAPPING_PATH = REPO_ROOT / "config" / "mapping.json"
SECTOR_DIR = REPO_ROOT / "data" / "energy_sector"

INTERNAL_ORDER = [
    "Upstream_Fuel_Consumption",
    "Scope_3_Emissions",
    "ESG_Disclosure_Score",
    "Transition_Capex",
    "Jurisdictional_Arbitrage",
]

# When multiple sheet rows fuzzy-match the same internal key, keep the first row
# (e.g. "Total energy consumption" before "Total energy consumption - Non-Renewable …").
FIRST_WIN_INTERNALS = frozenset({"Upstream_Fuel_Consumption", "Scope_3_Emissions"})


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def load_mapping_aliases() -> Dict[str, List[str]]:
    with open(MAPPING_PATH, encoding="utf-8") as fh:
        data = json.load(fh)
    out: Dict[str, List[str]] = {}
    for key, spec in data.get("metrics", {}).items():
        aliases = list(spec.get("aliases") or [])
        aliases.append(key.replace("_", " "))
        out[key] = aliases
    return out


def merge_company_alias_map(
    entry: Dict[str, Any], base: Dict[str, List[str]]
) -> Dict[str, List[str]]:
    merged = {k: list(v) for k, v in base.items()}
    for internal, aliases in (entry.get("extra_aliases") or {}).items():
        merged.setdefault(internal, [])
        for a in aliases:
            if a not in merged[internal]:
                merged[internal].append(a)
    return merged


def load_manifest() -> Dict[str, Any]:
    try:
        import yaml  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "PyYAML is required. Install with: pip install pyyaml"
        ) from exc
    if not MANIFEST_PATH.exists():
        raise FileNotFoundError(f"Missing manifest: {MANIFEST_PATH}")
    with open(MANIFEST_PATH, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def match_internal_key(label: str, alias_map: Dict[str, List[str]]) -> Optional[str]:
    nl = _norm(label)
    if not nl:
        return None
    best: Optional[str] = None
    best_len = 0
    for internal, aliases in alias_map.items():
        for a in aliases:
            an = _norm(a)
            if not an:
                continue
            if an == nl:
                return internal
            if an in nl or nl in an:
                if len(an) > best_len:
                    best = internal
                    best_len = len(an)
    return best


def resolve_workbook_path(entry: Dict[str, Any]) -> Path:
    wb = entry.get("workbook") or ""
    root = REPO_ROOT
    return (root / wb).resolve()


def cell_float(val: Any) -> Optional[float]:
    if val is None or val == "":
        return None
    if isinstance(val, (int, float)):
        if isinstance(val, float) and val != val:
            return None
        return float(val)
    s = str(val).strip().replace(",", "")
    if s == "" or s.lower() in ("n/a", "na", "-", "none"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def extract_pdf_text(pdf_path: Path, page_start: int, page_end: int) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise RuntimeError("pypdf is required. pip install pypdf") from exc
    reader = PdfReader(str(pdf_path))
    n = len(reader.pages)
    a = max(1, page_start)
    b = min(n, page_end)
    parts: List[str] = []
    for i in range(a - 1, b):
        parts.append(reader.pages[i].extract_text() or "")
    return "\n".join(parts)


def pdf_fallback_value(
    rule: Dict[str, Any],
    pdf_sources: Dict[str, Any],
    verbose: bool,
) -> Optional[Tuple[float, str, str]]:
    """Return (value, unit, citation_fragment) or None."""
    key = rule.get("pdf_key")
    if not key or key not in pdf_sources:
        return None
    spec = pdf_sources[key]
    rel = spec.get("path") or ""
    pdf_path = (REPO_ROOT / rel).resolve()
    if not pdf_path.exists():
        if verbose:
            print(f"  [pdf] skip fallback — missing file {pdf_path}", file=sys.stderr)
        return None
    pages = rule.get("pages") or [1, 1]
    ps, pe = int(pages[0]), int(pages[-1])
    text = extract_pdf_text(pdf_path, ps, pe)
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    anchors = [a.lower() for a in (rule.get("anchor_substrings") or [])]
    pat = re.compile(rule.get("regex") or r"([0-9][0-9.,]*)", re.I)
    scale = float(rule.get("scale") or 1)
    unit = str(rule.get("unit") or "")
    cite = str(rule.get("citation_note") or "PDF fallback")

    for ln in lines:
        low = ln.lower()
        if anchors and not all(a in low for a in anchors):
            continue
        m = pat.search(ln.replace(",", ""))
        if m:
            try:
                val = float(m.group(1)) * scale
                return val, unit, f"{cite}; matched line excerpt: {ln[:120]}"
            except (ValueError, IndexError):
                continue
    return None


def pick_narrative_paragraphs(
    text: str,
    min_chars: int,
    max_chars: int,
    max_blocks: int = 2,
) -> List[str]:
    raw = [p.strip() for p in re.split(r"\n\s*\n+", text) if p.strip()]
    scored = sorted(raw, key=len, reverse=True)
    out: List[str] = []
    for p in scored:
        if len(p) < min_chars:
            continue
        out.append(p[:max_chars])
        if len(out) >= max_blocks:
            break
    return out


def _fiscal_year_for_metric(
    entry: Dict[str, Any],
    internal: str,
    audit_yr: int,
    year_columns: Dict[int, int],
) -> int:
    ovr = (entry.get("metric_fiscal_year_overrides") or {}).get(internal, {})
    if not ovr:
        return int(year_columns[audit_yr])
    if audit_yr in ovr:
        return int(ovr[audit_yr])
    sk = str(audit_yr)
    if sk in ovr:
        return int(ovr[sk])
    return int(year_columns[audit_yr])


def build_excel_metric_map(
    entry: Dict[str, Any],
    alias_map: Dict[str, List[str]],
    defaults: Dict[str, Any],
    verbose: bool,
) -> Tuple[Dict[Tuple[str, int], Dict[str, Any]], Dict[str, Any]]:
    """Return ((internal_key, audit_year) -> cell dict, workbook context for injectors)."""
    path = resolve_workbook_path(entry)
    if not path.exists():
        raise FileNotFoundError(f"Workbook not found: {path}")

    sheet = entry["sheet"]
    rows = read_excel_grid(path, sheet)
    ex = defaults.get("excel", {})
    mcol = int(ex.get("metric_column_index", 1))
    ucol = int(ex.get("unit_column_index", 3))
    scan = int(ex.get("max_header_scan_rows", 8))

    hrow, year_to_col = find_header_row(rows, scan)
    if not year_to_col:
        raise ValueError(f"No year columns found in first {scan} rows of {path.name}")

    year_columns = {int(k): int(v) for k, v in (entry.get("year_columns") or {}).items()}
    out: Dict[Tuple[str, int], Dict[str, Any]] = {}
    skip_transition_rows = bool(entry.get("transition_capex_pct"))
    skip_esg_rows = bool(entry.get("esg_composite"))

    for r in rows[hrow + 1 :]:
        if not r or len(r) <= mcol:
            continue
        label = r[mcol]
        if label is None or str(label).strip() == "":
            continue
        internal = match_internal_key(str(label), alias_map)
        if not internal:
            continue
        if internal == "Transition_Capex" and skip_transition_rows:
            continue
        if internal == "ESG_Disclosure_Score" and skip_esg_rows:
            continue
        unit_cell = r[ucol] if len(r) > ucol else ""
        unit_s = str(unit_cell).strip() if unit_cell is not None else ""

        for audit_yr in year_columns:
            fy = _fiscal_year_for_metric(entry, internal, audit_yr, year_columns)
            if fy not in year_to_col:
                if verbose:
                    print(
                        f"  [xlsx] skip {internal} yr={audit_yr}: no column FY{fy}",
                        file=sys.stderr,
                    )
                continue
            ci = year_to_col[fy]
            val = cell_float(r[ci]) if len(r) > ci else None
            if val is None:
                continue
            key = (internal, audit_yr)
            if internal in FIRST_WIN_INTERNALS and key in out:
                continue
            out[key] = {
                "value": val,
                "unit": unit_s,
                "excel_label": str(label).strip(),
            }

    ctx = {
        "rows": rows,
        "hrow": hrow,
        "year_to_col": year_to_col,
        "mcol": mcol,
        "ucol": ucol,
        "year_columns": year_columns,
    }
    return out, ctx


def resolve_manifest_company_targets(manifest: Dict[str, Any], company: str) -> List[str]:
    companies = manifest.get("companies") or {}
    keys = sorted(companies.keys())
    if not keys:
        return []
    if company == "all":
        return keys
    if company in companies:
        return [company]
    return []


def validate_company_excel(
    company: str,
    manifest: Dict[str, Any],
    alias_map: Dict[str, List[str]],
    verbose: bool,
) -> Tuple[int, List[str]]:
    """Check workbook path, sheet, FY header columns, and build_excel_metric_map. No writes."""
    errors: List[str] = []
    defaults = manifest.get("defaults") or {}
    companies = manifest.get("companies") or {}
    if company not in companies:
        return 1, [f"unknown company {company!r}"]
    entry = companies[company]
    merged_aliases = merge_company_alias_map(entry, alias_map)
    out_metrics: Dict[str, str] = entry.get("output_metrics") or {}
    for internal in INTERNAL_ORDER:
        if not out_metrics.get(internal):
            errors.append(f"missing output_metrics.{internal}")

    year_columns_raw = entry.get("year_columns") or {}
    if not year_columns_raw:
        errors.append("missing year_columns")
        return 1, errors
    year_columns_i = {int(k): int(v) for k, v in year_columns_raw.items()}

    path = resolve_workbook_path(entry)
    if not path.exists():
        errors.append(f"workbook not found: {path}")
        return 1, errors

    sheet = entry.get("sheet") or ""
    if not sheet:
        errors.append("missing sheet in manifest")
        return 1, errors

    try:
        rows = read_excel_grid(path, sheet)
    except ValueError as exc:
        errors.append(str(exc))
        return 1, errors

    ex = defaults.get("excel", {})
    scan = int(ex.get("max_header_scan_rows", 8))
    _hrow, year_to_col = find_header_row(rows, scan)
    if not year_to_col:
        errors.append(f"no fiscal year columns in first {scan} rows of {path.name}")

    audit_years = list(
        entry.get("audit_years") or defaults.get("audit_years") or [2015, 2021, 2024]
    )
    scalar_def = dict(defaults.get("scalar_years") or {})
    scalar_ent = entry.get("scalar_years") or {}
    if isinstance(scalar_ent, dict):
        scalar_def.update(scalar_ent)
    for k, dflt in (
        ("esg", 2024),
        ("transition_capex", 2024),
        ("jurisdictional_arbitrage", 2024),
    ):
        scalar_def.setdefault(k, dflt)
    scalar_years = {
        k: int(scalar_def[k])
        for k in ("esg", "transition_capex", "jurisdictional_arbitrage")
    }

    required_fy: set = set()
    for ay in audit_years:
        ay_i = int(ay)
        if ay_i not in year_columns_i:
            errors.append(f"year_columns missing audit year {ay_i}")
            continue
        for internal in ("Upstream_Fuel_Consumption", "Scope_3_Emissions"):
            try:
                fy = _fiscal_year_for_metric(entry, internal, ay_i, year_columns_i)
                required_fy.add(int(fy))
            except KeyError:
                errors.append(
                    f"cannot resolve fiscal year for {internal} audit year {ay_i}"
                )

    for internal, sk in (
        ("ESG_Disclosure_Score", "esg"),
        ("Transition_Capex", "transition_capex"),
        ("Jurisdictional_Arbitrage", "jurisdictional_arbitrage"),
    ):
        ay_i = scalar_years[sk]
        if ay_i not in year_columns_i:
            errors.append(f"year_columns missing audit year {ay_i} for scalar {sk}")
            continue
        try:
            fy = _fiscal_year_for_metric(entry, internal, ay_i, year_columns_i)
            required_fy.add(int(fy))
        except KeyError:
            errors.append(
                f"cannot resolve fiscal year for {internal} scalar year {ay_i}"
            )

    for fy in sorted(required_fy):
        if fy not in year_to_col:
            errors.append(
                f"workbook header missing fiscal year column {fy} (manifest year_columns mapping)"
            )

    try:
        build_excel_metric_map(entry, merged_aliases, defaults, verbose)
    except Exception as exc:
        errors.append(f"Excel metric build failed: {exc}")

    return (1 if errors else 0), errors


def inject_transition_capex_pct(
    excel_map: Dict[Tuple[str, int], Dict[str, Any]],
    ctx: Dict[str, Any],
    entry: Dict[str, Any],
) -> None:
    spec = entry.get("transition_capex_pct") or {}
    label = (spec.get("excel_label") or "").strip()
    if not label:
        return
    base_ay = int(spec.get("base_audit_year", 2021))
    curr_ay = int(spec.get("current_audit_year", 2024))
    rows = ctx["rows"]
    hrow = ctx["hrow"]
    year_to_col = ctx["year_to_col"]
    mcol = ctx["mcol"]
    ucol = ctx["ucol"]
    year_columns = ctx["year_columns"]
    fy_b = _fiscal_year_for_metric(
        entry, "Transition_Capex", base_ay, year_columns
    )
    fy_c = _fiscal_year_for_metric(
        entry, "Transition_Capex", curr_ay, year_columns
    )
    if fy_b not in year_to_col or fy_c not in year_to_col:
        return
    ci_b = year_to_col[fy_b]
    ci_c = year_to_col[fy_c]
    for r in rows[hrow + 1 :]:
        if not r or len(r) <= mcol:
            continue
        if str(r[mcol]).strip() != label:
            continue
        vb = cell_float(r[ci_b]) if len(r) > ci_b else None
        vc = cell_float(r[ci_c]) if len(r) > ci_c else None
        if vb is None or vc is None or abs(vb) < 1e-12:
            return
        pct = (vc - vb) / vb * 100.0
        unit_cell = r[ucol] if len(r) > ucol else ""
        unit_s = str(unit_cell).strip() if unit_cell is not None else ""
        excel_map[("Transition_Capex", curr_ay)] = {
            "value": pct,
            "unit": unit_s or "percent vs 2021 base",
            "excel_label": f"{label} (% change FY{fy_b}→FY{fy_c})",
        }
        return


def inject_esg_composite(
    excel_map: Dict[Tuple[str, int], Dict[str, Any]],
    ctx: Dict[str, Any],
    entry: Dict[str, Any],
) -> None:
    spec = entry.get("esg_composite") or {}
    components = spec.get("components") or []
    if not components:
        return
    scale = float(spec.get("scale", 100))
    cap = spec.get("cap_at")
    rows = ctx["rows"]
    hrow = ctx["hrow"]
    year_to_col = ctx["year_to_col"]
    mcol = ctx["mcol"]
    ucol = ctx["ucol"]
    year_columns = ctx["year_columns"]
    for ay in spec.get("audit_years") or [2024]:
        ay_i = int(ay)
        key = ("ESG_Disclosure_Score", ay_i)
        if key in excel_map:
            continue
        fy = _fiscal_year_for_metric(entry, "ESG_Disclosure_Score", ay_i, year_columns)
        if fy not in year_to_col:
            continue
        ci = year_to_col[fy]
        total = 0.0
        labels_used: List[str] = []
        unit_s = ""
        for comp in components:
            lab = comp if isinstance(comp, str) else (comp.get("row_label") or "")
            lab = str(lab).strip()
            if not lab:
                continue
            for r in rows[hrow + 1 :]:
                if not r or len(r) <= mcol:
                    continue
                if str(r[mcol]).strip() != lab:
                    continue
                v = cell_float(r[ci]) if len(r) > ci else None
                if v is None:
                    break
                total += v
                labels_used.append(lab)
                uc = r[ucol] if len(r) > ucol else ""
                if uc is not None and str(uc).strip():
                    unit_s = str(uc).strip()
                break
        if len(labels_used) != len(components):
            continue
        raw = total * scale
        if cap is not None:
            raw = min(float(cap), raw)
        excel_map[key] = {
            "value": raw,
            "unit": unit_s or "score (0-100)",
            "excel_label": " + ".join(labels_used) + f" (×{scale:g} composite)",
        }


def apply_scope3_transform(
    internal: str,
    val: float,
    unit_s: str,
    entry: Dict[str, Any],
) -> Tuple[float, str]:
    if internal != "Scope_3_Emissions":
        return val, unit_s
    mult = float(entry.get("scope3_excel_multiplier") or 1)
    ulow = (unit_s or "").lower()
    # Workbooks often store million tCO2e (e.g. 1281); some store full metric tons.
    already_full_tonnes = abs(val) >= 1_000_000
    if mult != 1 and not already_full_tonnes and (
        "million" in ulow or "mt" in ulow or abs(val) < 500_000
    ):
        return val * mult, "metric tons CO2e"
    return val, unit_s or "metric tons CO2e"


def format_csv_value(internal: str, val: float) -> str:
    if internal == "Jurisdictional_Arbitrage":
        return str(int(val))
    if internal == "Transition_Capex":
        r = round(val, 4)
        return str(int(r)) if abs(r - int(r)) < 1e-9 else str(r)
    if internal == "ESG_Disclosure_Score":
        return str(val) if val != int(val) else str(int(val))
    if internal == "Scope_3_Emissions":
        return str(int(round(val)))
    if internal == "Upstream_Fuel_Consumption":
        return str(int(val)) if abs(val - round(val)) < 0.01 else str(val)
    return str(val)


def sector_narrative_rows(company: str) -> List[Dict[str, str]]:
    path = SECTOR_DIR / f"{company}_public_audit_2024.csv"
    if not path.exists():
        return []
    rows: List[Dict[str, str]] = []
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            if (row.get("metric") or "").strip() == "narrative_sentiment":
                rows.append(dict(row))
    return rows


def sync_company(
    company: str,
    manifest: Dict[str, Any],
    alias_map: Dict[str, List[str]],
    dry_run: bool,
    verbose: bool,
    write_sector: bool,
) -> int:
    defaults = manifest.get("defaults") or {}
    companies = manifest.get("companies") or {}
    if company not in companies:
        print(f"[skip] unknown company {company!r}", file=sys.stderr)
        return 1

    entry = companies[company]
    alias_map = merge_company_alias_map(entry, alias_map)
    out_metrics: Dict[str, str] = entry.get("output_metrics") or {}
    year_columns = entry.get("year_columns") or {}
    audit_years = entry.get("audit_years") or defaults.get("audit_years") or [2015, 2021, 2024]
    scalar_def = dict(defaults.get("scalar_years") or {})
    scalar_ent = entry.get("scalar_years") or {}
    if isinstance(scalar_ent, dict):
        scalar_def.update(scalar_ent)
    for k, dflt in (
        ("esg", 2024),
        ("transition_capex", 2024),
        ("jurisdictional_arbitrage", 2024),
    ):
        scalar_def.setdefault(k, dflt)
    scalar_years = {k: int(scalar_def[k]) for k in ("esg", "transition_capex", "jurisdictional_arbitrage")}

    try:
        excel_map, wb_ctx = build_excel_metric_map(entry, alias_map, defaults, verbose)
    except Exception as exc:
        print(f"[error] {company} Excel: {exc}", file=sys.stderr)
        return 1

    inject_transition_capex_pct(excel_map, wb_ctx, entry)
    inject_esg_composite(excel_map, wb_ctx, entry)

    pdf_sources = entry.get("pdf_sources") or {}
    pdf_fallback_rules = list(entry.get("pdf_fallback") or [])
    static_fallback_rules = list(entry.get("static_fallback") or [])

    rows_out: List[Dict[str, str]] = []
    missing: List[str] = []

    wb_disp = (entry.get("excel_citation") or {}).get("workbook_display", entry.get("workbook", ""))
    sh_disp = (entry.get("excel_citation") or {}).get("sheet_display", entry.get("sheet", ""))
    default_url = entry.get("default_source_url") or ""

    for internal in INTERNAL_ORDER:
        csv_metric = out_metrics.get(internal)
        if not csv_metric:
            continue
        if internal in ("Upstream_Fuel_Consumption", "Scope_3_Emissions"):
            years_to_emit = list(audit_years)
        elif internal == "ESG_Disclosure_Score":
            years_to_emit = [scalar_years["esg"]]
        elif internal == "Transition_Capex":
            years_to_emit = [scalar_years["transition_capex"]]
        elif internal == "Jurisdictional_Arbitrage":
            years_to_emit = [scalar_years["jurisdictional_arbitrage"]]
        else:
            years_to_emit = [2024]

        for ay in years_to_emit:
            key = (internal, ay)
            val: Optional[float] = None
            unit_s = ""
            cite_parts: List[str] = []

            if key in excel_map:
                raw = excel_map[key]
                val = raw["value"]
                unit_s = raw["unit"]
                val, unit_s = apply_scope3_transform(internal, val, unit_s, entry)
                fy = year_columns.get(ay, ay)
                cite_parts.append(
                    f"Internal ESG workbook ({wb_disp}, sheet {sh_disp!r}), "
                    f"row matched to {raw['excel_label']!r} — FY{fy} column"
                )
            else:
                for rule in pdf_fallback_rules:
                    if rule.get("internal_key") != internal:
                        continue
                    allowed = rule.get("audit_years")
                    if allowed is not None and ay not in allowed:
                        continue
                    fb = pdf_fallback_value(rule, pdf_sources, verbose)
                    if fb:
                        val, unit_s, cnote = fb
                        cite_parts.append(cnote)
                        pub = (pdf_sources.get(rule.get("pdf_key")) or {}).get("public_url", "")
                        if pub:
                            cite_parts.append(f"Public URL: {pub}")
                        break

            if val is None:
                for rule in static_fallback_rules:
                    if rule.get("internal_key") != internal:
                        continue
                    allowed = rule.get("audit_years")
                    if allowed is not None:
                        allowed_i = [int(x) for x in allowed]
                        if ay not in allowed_i:
                            continue
                    try:
                        val = float(rule["value"])
                    except (KeyError, TypeError, ValueError):
                        continue
                    unit_s = str(rule.get("unit") or _default_unit(internal))
                    cite_parts.append(str(rule.get("citation_note") or "Manifest static fallback"))
                    break

            if val is None:
                missing.append(f"{csv_metric} ({ay})")
                continue

            citation = "; ".join(cite_parts) if cite_parts else "Auto-sync (see manifest)"
            url = default_url
            if internal == "Scope_3_Emissions" and ay == 2024:
                for rule in pdf_fallback_rules:
                    if rule.get("internal_key") != internal:
                        continue
                    pk = rule.get("pdf_key")
                    if pk and pk in pdf_sources:
                        url = pdf_sources[pk].get("public_url") or url
                        break

            rows_out.append(
                {
                    "metric": csv_metric,
                    "value": format_csv_value(internal, val),
                    "unit": unit_s or _default_unit(internal),
                    "year": str(ay),
                    "source_citation": citation,
                    "source_url": url,
                }
            )

    for nr in sector_narrative_rows(company):
        rows_out.append(nr)

    out_csv = DATA_INPUT / f"{company}_public_audit_2024.csv"
    if dry_run:
        print(f"[dry-run] would write {out_csv} ({len(rows_out)} rows)")
        if missing:
            print(f"[dry-run] missing: {missing}")
    else:
        DATA_INPUT.mkdir(parents=True, exist_ok=True)
        with open(out_csv, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=["metric", "value", "unit", "year", "source_citation", "source_url"])
            w.writeheader()
            w.writerows(rows_out)
        print(f"Wrote {out_csv} ({len(rows_out)} rows)")
        if missing:
            print(f"WARNING: missing metrics (not written): {missing}", file=sys.stderr)

    if write_sector and not dry_run:
        dest = SECTOR_DIR / f"{company}_public_audit_2024.csv"
        SECTOR_DIR.mkdir(parents=True, exist_ok=True)
        with open(dest, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=["metric", "value", "unit", "year", "source_citation", "source_url"])
            w.writeheader()
            w.writerows(rows_out)
        print(f"Wrote sector copy {dest}")

    narr_cfg: Dict[str, Any] = dict(entry.get("narratives") or {})
    auto_narr = bool(entry.get("auto_narratives") or defaults.get("auto_narratives"))
    if auto_narr:
        ev_st = get_event_study(company)
        pdf_map_raw = entry.get("auto_narrative_pdf_keys") or {}
        pdf_map = {int(k): str(v) for k, v in pdf_map_raw.items()}
        ps_def = int(
            entry.get("auto_narrative_page_start")
            or defaults.get("auto_narrative_page_start")
            or 1
        )
        pe_def = int(
            entry.get("auto_narrative_page_end")
            or defaults.get("auto_narrative_page_end")
            or 12
        )
        need_years = [int(ev_st["baseline_year"]), int(ev_st["current_year"])]
        mid_ev = ev_st.get("mid_year")
        if mid_ev is not None:
            need_years.insert(1, int(mid_ev))
        auto_title = (entry.get("auto_narrative_source_title") or "").strip() or (
            f"{company} public filing (auto_narratives)"
        )
        for y in need_years:
            sk = str(y)
            existing = narr_cfg.get(sk)
            has_pdf = isinstance(existing, dict) and bool(existing.get("pdf_key"))
            if has_pdf:
                continue
            pk = pdf_map.get(y)
            if not pk:
                if verbose:
                    print(
                        f"  [auto_narratives] skip {company} {y}: "
                        f"add auto_narrative_pdf_keys.{y} in manifest",
                        file=sys.stderr,
                    )
                continue
            print(
                f"  [auto_narratives] {company} {y}: using pdf_key={pk} "
                f"pages {ps_def}-{pe_def} (changes CorporateAgent prompts / cache keys — "
                f"Rule 4.4: run scripts/rekey_corporate_cache.py or live refresh)",
                file=sys.stderr,
            )
            narr_cfg[sk] = {
                "pdf_key": pk,
                "page_start": ps_def,
                "page_end": pe_def,
                "source_title": auto_title,
                "public_url": (pdf_sources.get(pk) or {}).get("public_url") or "",
            }

    narr_defaults = defaults.get("narrative", {})
    min_c = int(narr_defaults.get("min_paragraph_chars", 80))
    max_c = int(narr_defaults.get("max_paragraph_chars", 1100))
    yaml_blocks: Dict[str, Any] = {}
    for yr_key, nc in narr_cfg.items():
        try:
            y = int(yr_key)
        except (TypeError, ValueError):
            continue
        pk = nc.get("pdf_key")
        if not pk or pk not in pdf_sources:
            if verbose:
                print(f"  [narrative] skip {company} {y}: no pdf_key or missing source", file=sys.stderr)
            continue
        rel = pdf_sources[pk].get("path") or ""
        pdf_path = (REPO_ROOT / rel).resolve()
        if not pdf_path.exists():
            if verbose:
                print(f"  [narrative] skip {y}: PDF not found {pdf_path}", file=sys.stderr)
            continue
        ps, pe = int(nc.get("page_start", 1)), int(nc.get("page_end", 1))
        text = extract_pdf_text(pdf_path, ps, pe)
        paras = pick_narrative_paragraphs(text, min_c, max_c)
        if not paras:
            continue
        title = nc.get("source_title") or pk
        pub = nc.get("public_url") or pdf_sources[pk].get("public_url") or ""
        parts = [f'[SOURCE: {title}, PDF pp.{ps}-{pe}]']
        for p in paras:
            parts.append(f'"{p}"')
        yaml_blocks[f"excerpts_{y}"] = "\n\n".join(parts)

    if yaml_blocks:
        import yaml  # type: ignore

        def _multiline_str(dumper: Any, data: str) -> Any:
            if "\n" in data:
                return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
            return dumper.represent_scalar("tag:yaml.org,2002:str", data)

        yaml.add_representer(str, _multiline_str)

        narr_dir = DATA_INPUT / "narratives"
        if not dry_run:
            narr_dir.mkdir(parents=True, exist_ok=True)
            out_y = narr_dir / f"{company}_excerpts.yaml"
            payload = {"company": company, **yaml_blocks}
            if entry.get("default_source_url"):
                payload["source_url"] = entry["default_source_url"]
            with open(out_y, "w", encoding="utf-8") as fh:
                yaml.dump(
                    payload,
                    fh,
                    default_flow_style=False,
                    allow_unicode=True,
                    sort_keys=False,
                )
            print(f"Wrote {out_y}")
        else:
            print(f"[dry-run] would write narratives/{company}_excerpts.yaml blocks: {list(yaml_blocks)}")

    print(
        "\nNOTE: If narrative excerpts changed, regenerate data/api_cache.json "
        "(run run_auditlens.py once without --use-cached for affected companies).",
        file=sys.stderr,
    )
    return 1 if missing else 0


def _default_unit(internal: str) -> str:
    if internal == "Upstream_Fuel_Consumption":
        return "million MWh"
    if internal == "Scope_3_Emissions":
        return "metric tons CO2e"
    if internal == "ESG_Disclosure_Score":
        return "score (0-100)"
    if internal == "Transition_Capex":
        return "percent vs 2021 base"
    if internal == "Jurisdictional_Arbitrage":
        return "binary (0=compliant)"
    return ""


def main() -> int:
    parser = argparse.ArgumentParser(description="Sync Data_Input audit CSVs from Excel + PDF manifest.")
    parser.add_argument(
        "--company",
        default="all",
        help="Manifest company slug or 'all' (default: every company listed in manifest.yaml).",
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument(
        "--write-sector",
        action="store_true",
        help="Also copy CSV to data/energy_sector/ (default: Data_Input only).",
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Check workbook, sheet, FY columns, and Excel metric map; do not write CSV/PDF/YAML.",
    )
    args = parser.parse_args()

    manifest = load_manifest()
    alias_map = load_mapping_aliases()
    targets = resolve_manifest_company_targets(manifest, args.company)
    if not targets:
        print(
            f"Unknown company {args.company!r} or empty manifest companies section.",
            file=sys.stderr,
        )
        return 1
    code = 0
    if args.validate_only:
        for c in targets:
            rc, errs = validate_company_excel(c, manifest, alias_map, args.verbose)
            for e in errs:
                print(f"[validate] {c}: {e}", file=sys.stderr)
            if rc == 0 and args.verbose:
                print(f"[validate] {c}: OK", file=sys.stderr)
            code = max(code, rc)
        return code
    for c in targets:
        rc = sync_company(
            c, manifest, alias_map, args.dry_run, args.verbose, args.write_sector
        )
        code = max(code, rc)
    return code


if __name__ == "__main__":
    sys.exit(main())
