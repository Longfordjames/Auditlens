# MIT License — see LICENSE file
"""
tests/test_portfolio_optimizer.py
==================================
Unit tests for the PortfolioOptimizer module.

Coverage:
  • Weight normalisation:     optimised weights ALWAYS sum to 100%.
  • Long-only constraint:     no weight is ever ≤ 0.
  • Tilt multiplier math:     exact formula validation for key WACC levels.
  • AUM reallocation:         Δ_capital values are consistent with Δ_weight.
  • Empty-scan guard:         returns [] without crashing.
  • Single-asset edge case:   one company → 100% weight.
  • Division-by-zero guard:   all-zero raw weights fall back gracefully.

All tests are 100% offline — no API calls, no file I/O in production paths.
"""

import json
import math
import pytest
from pathlib import Path
from unittest.mock import patch

from portfolio_optimizer import (
    calculate_optimized_weights,
    run_portfolio_optimization,
    INSTITUTIONAL_AUM_USD,
    _MIN_TILT_MULTIPLIER,
    _TILT_DENOMINATOR,
)


# ── Shared fixtures ───────────────────────────────────────────────────────────

def _make_row(company: str, wacc_bps: int, risk_level: str = "HIGH",
              risk_flag: str = "HIGH-RISK STRATEGIC OBFUSCATION",
              display: str = None, id_val: float = 0.05) -> dict:
    """Minimal scan result row for testing."""
    return {
        "company_name":  company,
        "display_name":  display or company.upper(),
        "wacc_bps":      wacc_bps,
        "risk_level":    risk_level,
        "risk_flag":     risk_flag,
        "id_val":        id_val,
        "integrity_score": 0.5,
    }


_SHELL_ROW   = _make_row("shell",        150, "HIGH",   id_val=+0.076)
_ORSTED_ROW  = _make_row("orsted",       -50, "LOW",    risk_flag="AUTHENTIC TRANSITION LEADER", id_val=-0.805)
_BP_ROW      = _make_row("bp",           100, "HIGH",   id_val=+1.835)
_TOTAL_ROW   = _make_row("totalenergies",100, "HIGH",   id_val=+1.990)
_FOUR_ROWS   = [_SHELL_ROW, _ORSTED_ROW, _BP_ROW, _TOTAL_ROW]


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Weight normalisation
# ═══════════════════════════════════════════════════════════════════════════════

class TestWeightNormalisation:
    """Optimised weights must always sum to exactly 100 %."""

    def test_four_companies_sum_to_100(self):
        """Standard 4-company sector scan → weights sum to 100."""
        positions = calculate_optimized_weights(_FOUR_ROWS)
        total = sum(p["optimized_weight_pct"] for p in positions)
        assert abs(total - 100.0) < 1e-4

    def test_two_companies_sum_to_100(self):
        """2-company subset → weights sum to 100."""
        rows = [_SHELL_ROW, _ORSTED_ROW]
        positions = calculate_optimized_weights(rows)
        assert abs(sum(p["optimized_weight_pct"] for p in positions) - 100.0) < 1e-4

    def test_single_company_is_100pct(self):
        """Single company → 100% weight."""
        positions = calculate_optimized_weights([_SHELL_ROW])
        assert abs(positions[0]["optimized_weight_pct"] - 100.0) < 1e-4

    def test_identical_wacc_equal_weights(self):
        """All companies at 0 bps → equal weights."""
        rows = [_make_row(f"co{i}", 0) for i in range(4)]
        positions = calculate_optimized_weights(rows)
        for p in positions:
            assert abs(p["optimized_weight_pct"] - 25.0) < 1e-4

    def test_run_portfolio_optimization_weight_sum_check_field(self, tmp_path):
        """run_portfolio_optimization returns weight_sum_check ≈ 100."""
        result = run_portfolio_optimization(_FOUR_ROWS, output_path=tmp_path / "out.json")
        assert abs(result["weight_sum_check"] - 100.0) < 1e-3


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Long-only constraint — no shorting
# ═══════════════════════════════════════════════════════════════════════════════

class TestLongOnlyConstraint:
    """Optimised weights must always be strictly positive."""

    def test_no_negative_weights(self):
        """No position has a negative weight."""
        positions = calculate_optimized_weights(_FOUR_ROWS)
        for p in positions:
            assert p["optimized_weight_pct"] > 0, f"{p['company_name']} weight ≤ 0"

    def test_extremely_high_wacc_still_positive(self):
        """wacc_bps=1000 → tilt=0.1 (floor) → weight still > 0."""
        rows = [_make_row("extreme", 1000), _make_row("normal", 0)]
        positions = calculate_optimized_weights(rows)
        for p in positions:
            assert p["optimized_weight_pct"] > 0

    def test_min_tilt_multiplier_applied_at_floor(self):
        """wacc_bps ≥ 500 → tilt_multiplier = MIN_TILT_MULTIPLIER."""
        rows = [_make_row("high", 500)]
        positions = calculate_optimized_weights(rows)
        assert abs(positions[0]["tilt_multiplier"] - _MIN_TILT_MULTIPLIER) < 1e-9


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Tilt multiplier arithmetic
# ═══════════════════════════════════════════════════════════════════════════════

class TestTiltMultiplierArithmetic:
    """Exact formula: tilt = max(0.1, 1.0 − wacc_bps/500)."""

    def test_zero_bps_is_1x(self):
        """0 bps → 1.0× (no tilt)."""
        rows = [_make_row("neutral", 0)]
        p = calculate_optimized_weights(rows)[0]
        assert abs(p["tilt_multiplier"] - 1.0) < 1e-9

    def test_shell_150bps_is_0_70x(self):
        """Shell +150 bps → 1.0 − 0.30 = 0.70×."""
        rows = [_make_row("shell", 150)]
        p = calculate_optimized_weights(rows)[0]
        assert abs(p["tilt_multiplier"] - 0.70) < 1e-9

    def test_orsted_minus50bps_is_1_10x(self):
        """Ørsted −50 bps → 1.0 − (−0.10) = 1.10×."""
        rows = [_make_row("orsted", -50)]
        p = calculate_optimized_weights(rows)[0]
        assert abs(p["tilt_multiplier"] - 1.10) < 1e-9

    def test_100bps_is_0_80x(self):
        """+100 bps → 0.80×."""
        rows = [_make_row("bp", 100)]
        p = calculate_optimized_weights(rows)[0]
        assert abs(p["tilt_multiplier"] - 0.80) < 1e-9

    def test_floor_at_very_high_bps(self):
        """wacc_bps = 1000 → formula gives −1.0 → floor to 0.1."""
        rows = [_make_row("xtr", 1000)]
        p = calculate_optimized_weights(rows)[0]
        assert abs(p["tilt_multiplier"] - _MIN_TILT_MULTIPLIER) < 1e-9


# ═══════════════════════════════════════════════════════════════════════════════
# 4. AUM reallocation consistency
# ═══════════════════════════════════════════════════════════════════════════════

class TestAUMReallocation:
    """Δ_capital must equal Δ_weight/100 × AUM."""

    def test_delta_capital_matches_delta_weight(self):
        """For every position: Δ_capital = Δ_weight_pct/100 × AUM (within $1 rounding)."""
        aum = 100_000_000.0
        positions = calculate_optimized_weights(_FOUR_ROWS, aum_usd=aum)
        for p in positions:
            expected = (p["delta_weight_pct"] / 100.0) * aum
            assert abs(p["delta_capital_usd"] - expected) < 1.0

    def test_delta_capital_sum_near_zero(self):
        """Sum of capital reallocation ≈ 0 (long-only, no external flows)."""
        aum = 100_000_000.0
        positions = calculate_optimized_weights(_FOUR_ROWS, aum_usd=aum)
        total_delta = sum(p["delta_capital_usd"] for p in positions)
        assert abs(total_delta) < 1.0   # < $1 rounding

    def test_orsted_overweighted_vs_shell(self):
        """Ørsted (−50 bps, 1.1×) should have higher weight than Shell (+150 bps, 0.7×)."""
        positions = {
            p["company_name"]: p
            for p in calculate_optimized_weights([_SHELL_ROW, _ORSTED_ROW])
        }
        assert positions["orsted"]["optimized_weight_pct"] > positions["shell"]["optimized_weight_pct"]

    def test_orsted_is_positive_delta_capital(self):
        """Ørsted gets capital allocated to it (positive Δ)."""
        positions = {
            p["company_name"]: p
            for p in calculate_optimized_weights([_SHELL_ROW, _ORSTED_ROW])
        }
        assert positions["orsted"]["delta_capital_usd"] > 0

    def test_shell_is_negative_delta_capital(self):
        """Shell is divested (negative Δ)."""
        positions = {
            p["company_name"]: p
            for p in calculate_optimized_weights([_SHELL_ROW, _ORSTED_ROW])
        }
        assert positions["shell"]["delta_capital_usd"] < 0


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Empty-scan & edge-case guards
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeCaseGuards:
    """Degenerate inputs must not crash."""

    def test_empty_scan_returns_empty_list(self):
        """Empty scan_results → [] (no crash, no division by zero)."""
        result = calculate_optimized_weights([])
        assert result == []

    def test_run_portfolio_optimization_empty(self, tmp_path):
        """run_portfolio_optimization([]) → note in output, no crash."""
        result = run_portfolio_optimization([], output_path=tmp_path / "empty.json")
        assert result["n_assets"] == 0
        assert result["positions"] == []

    def test_run_portfolio_optimization_writes_json(self, tmp_path):
        """Output JSON is valid and weight_sum_check ≈ 100."""
        out = tmp_path / "portfolio.json"
        run_portfolio_optimization(_FOUR_ROWS, output_path=out)
        assert out.exists()
        data = json.loads(out.read_text())
        assert abs(data["weight_sum_check"] - 100.0) < 1e-3

    def test_n_assets_field_correct(self, tmp_path):
        """n_assets in output matches number of positions."""
        result = run_portfolio_optimization(_FOUR_ROWS, output_path=tmp_path / "n.json")
        assert result["n_assets"] == len(_FOUR_ROWS)
        assert len(result["positions"]) == len(_FOUR_ROWS)

    def test_all_weights_finite(self):
        """All optimized weights are finite (no Inf, no NaN)."""
        positions = calculate_optimized_weights(_FOUR_ROWS)
        for p in positions:
            assert math.isfinite(p["optimized_weight_pct"])

    def test_single_extreme_high_wacc(self):
        """Single company at 10000 bps → floor kicks in → 100% weight (only asset)."""
        positions = calculate_optimized_weights([_make_row("x", 10_000)])
        assert abs(positions[0]["optimized_weight_pct"] - 100.0) < 1e-4
