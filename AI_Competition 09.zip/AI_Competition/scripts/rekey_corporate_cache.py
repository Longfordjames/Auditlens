#!/usr/bin/env python3
# MIT License — see LICENSE file
"""
Re-key CorporateAgent sentiment entries in data/api_cache.json after narrative edits.

Cache keys are SHA-256(prompt + model + temperature). When Data_Input/narratives/* or
manifest excerpts change, old keys miss while labels (e.g. CorporateAgent_openai_shell_2024)
stay stable. This script copies each labeled entry to the key implied by the **current**
built prompts (same labels), preserving responses under Rule 4.4 without live API calls.

Usage (from repo root):
  python3 scripts/rekey_corporate_cache.py
  python3 scripts/rekey_corporate_cache.py --dry-run
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from agents import corporate_agent as ca  # noqa: E402
from config.audit_profile import get_event_study  # noqa: E402
from llm_wrapper import ANTHROPIC_MODEL, _cache_key  # noqa: E402


def _sentiment_years(company: str) -> list[int]:
    ev = get_event_study(company)
    y_curr = int(ev["current_year"])
    y_base = int(ev["baseline_year"])
    y_mid = ev.get("mid_year")
    years = [y_curr]
    if y_mid is not None:
        years.append(int(y_mid))
    years.append(y_base)
    return years


def main() -> int:
    parser = argparse.ArgumentParser(description="Re-key CorporateAgent cache entries by label.")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print planned moves without writing api_cache.json",
    )
    args = parser.parse_args()

    cache_path = REPO_ROOT / "data" / "api_cache.json"
    if not cache_path.is_file():
        print(f"Missing cache: {cache_path}", file=sys.stderr)
        return 1

    with open(cache_path, encoding="utf-8") as fh:
        cache: dict = json.load(fh)

    label_to_key: dict[str, str] = {}
    for key, entry in cache.items():
        if isinstance(entry, dict) and entry.get("label"):
            lab = str(entry["label"])
            label_to_key.setdefault(lab, key)

    moves: list[tuple[str, str, str]] = []

    for company in sorted(ca.COMPANY_NARRATIVES.keys()):
        narrative = ca.COMPANY_NARRATIVES[company]
        display = narrative["display_name"]
        for y in _sentiment_years(company):
            ex_key = f"excerpts_{y}"
            if ex_key not in narrative:
                continue
            excerpts = str(narrative[ex_key])
            prompt = ca._SENTIMENT_PROMPT_TEMPLATE.format(
                company_name=display,
                excerpts=excerpts,
            )
            specs = [
                ("gpt-4o-mini", f"CorporateAgent_openai_{company}_{y}"),
                (ANTHROPIC_MODEL, f"CorporateAgent_anthropic_{company}_{y}"),
            ]
            for model, label in specs:
                old_k = label_to_key.get(label)
                if not old_k or old_k not in cache:
                    continue
                new_k = _cache_key(prompt, model, 0.0)
                if new_k == old_k:
                    continue
                moves.append((old_k, new_k, label))

    if not moves:
        print("No re-keys needed (prompt hashes already match labels).")
        return 0

    for old_k, new_k, label in moves:
        print(f"{label}: {old_k[:12]}… -> {new_k[:12]}…")

    if args.dry_run:
        print(f"[dry-run] {len(moves)} entries would be copied to new keys.")
        return 0

    for old_k, new_k, label in moves:
        entry = cache.get(old_k)
        if not isinstance(entry, dict):
            continue
        cache[new_k] = dict(entry)
        if old_k != new_k and old_k in cache:
            del cache[old_k]

    with open(cache_path, "w", encoding="utf-8") as fh:
        json.dump(cache, fh, indent=2, ensure_ascii=False)
    print(f"Wrote {cache_path} ({len(moves)} re-keys).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
