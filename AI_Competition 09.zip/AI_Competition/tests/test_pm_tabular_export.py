# MIT License — see LICENSE file
"""Tests for exporters/pm_tabular_export.py."""

import csv
from pathlib import Path

from exporters.pm_tabular_export import write_pm_csv_bundle


def _minimal_report() -> dict:
    return {
        "system": {
            "company": "acme",
            "display_name": "Acme PLC",
        },
        "layers": {
            "corporate_agent": {
                "has_2021_node": True,
                "dual_model_active": True,
                "score_openai_2015": 0.1,
                "score_anthropic_2015": 0.12,
                "ai_variance_2015": 0.02,
                "score_openai_2021": 0.4,
                "score_anthropic_2021": 0.5,
                "ai_variance_2021": 0.1,
                "score_openai_2024": 0.7,
                "score_anthropic_2024": 0.65,
                "ai_variance_2024": 0.05,
                "max_ai_variance": 0.1,
                "high_ambiguity_flag": True,
            },
            "auditor_agent": {
                "delta_scope3_pct": 0.0,
                "jurisdictional_arbitrage": 0,
            },
            "sceptic_agent": {
                "integrity_discount": 0.01,
                "risk_level": "MEDIUM",
                "risk_flag": "MODERATE",
                "formula_inputs": {
                    "delta_narrative_sentiment": 0.2,
                    "delta_resource_intensity": 1.5,
                    "disclosure_density": 0.8,
                    "denominator": 1.2,
                },
                "cross_checks": [
                    {
                        "rule": "Rule A",
                        "triggered": True,
                        "detail": "Detail line",
                        "citation": "AR p.1",
                    },
                ],
                "valuation_impact_bps": 50,
                "implied_wacc_modifier": 0.005,
                "valuation_action": "Hold",
                "trajectory": {
                    "available": True,
                    "event_label": "E",
                    "inflection_flag": "OK",
                    "sentiment_slope_pre": 0.01,
                    "sentiment_slope_post": 0.02,
                    "ri_slope_pre": 100.0,
                    "ri_slope_post": 200.0,
                    "event_driven_greenwashing": False,
                },
            },
        },
        "verdict": {},
        "valuation_analysis": {
            "base_wacc_pct": 8.0,
            "adjusted_wacc_pct": 8.5,
            "haircut_pct": 1.0,
        },
    }


def test_write_pm_csv_bundle_creates_expected_files(tmp_path: Path) -> None:
    report = _minimal_report()
    llm_rows = [
        {
            "status": "CACHE_HIT",
            "provider": "openai",
            "year": "2024",
            "model": "gpt-4o-mini",
            "temperature": 0.0,
            "key_prefix": "abcd12345678",
            "label": "CorporateAgent_openai_acme_2024",
        },
        {
            "status": "CACHE_WRITE",
            "provider": "openai",
            "year": "2024",
            "model": "gpt-4o-mini",
            "temperature": 0.0,
            "key_prefix": "abcd12345678",
            "label": "x",
        },
    ]
    paths = write_pm_csv_bundle(report, tmp_path, llm_events=llm_rows)

    assert "llm_trace" in paths
    assert paths["llm_trace"].name == "acme_pm_sheet_llm_trace.csv"
    with open(paths["llm_trace"], newline="", encoding="utf-8") as fh:
        r = list(csv.DictReader(fh))
    assert len(r) == 1
    assert r[0]["status"] == "CACHE_HIT"

    with open(paths["cross_checks"], newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    assert len(rows) == 1
    assert rows[0]["rule"] == "Rule A"
    assert rows[0]["detail"] == "Detail line"

    with open(paths["dual_model"], newline="", encoding="utf-8") as fh:
        drows = list(csv.DictReader(fh))
    assert len(drows) == 3
    assert drows[0]["year"] == "2015"

    assert "trajectory" in paths
    with open(paths["wacc"], newline="", encoding="utf-8") as fh:
        wrows = list(csv.reader(fh))
    assert any("illustrative_base_wacc_pct" in row[0] for row in wrows[1:])
