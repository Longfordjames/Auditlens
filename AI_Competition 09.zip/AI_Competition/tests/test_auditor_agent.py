# MIT License — see LICENSE file
"""Unit tests for auditor_agent traceability matrix (Location + citations)."""

import csv
import io

import pytest
from rich.console import Console


def test_excel_col_letter():
    from agents import auditor_agent as aa

    assert aa._excel_col_letter(1) == "A"
    assert aa._excel_col_letter(2) == "B"
    assert aa._excel_col_letter(26) == "Z"
    assert aa._excel_col_letter(27) == "AA"


def test_traceability_matrix_location_uses_basename_and_cell(tmp_path, monkeypatch):
    """Location shows basename plus ``Row:`` / ``Column:`` for the ``value`` cell."""
    import data_loader as dl
    from agents.auditor_agent import COMPANY_CONFIG, build_traceability_matrix

    rows = [
        {
            "metric": "Total energy consumption",
            "value": "251",
            "unit": "million MWh",
            "year": "2015",
            "source_citation": "Shell Sustainability Report 2015, p.42 — Upstream",
            "source_url": "https://example.com/2015",
        },
        {
            "metric": "Total energy consumption",
            "value": "212",
            "unit": "million MWh",
            "year": "2024",
            "source_citation": "Shell Annual Report 2024, p.78 — Energy",
            "source_url": "https://example.com/2024",
        },
        {
            "metric": "Total Scope 3 GHG Emissions",
            "value": "1080000",
            "unit": "metric tons CO2e",
            "year": "2015",
            "source_citation": "Test SR 2015, p.48 — GHG",
            "source_url": "https://example.com/s315",
        },
        {
            "metric": "Total Scope 3 GHG Emissions",
            "value": "1080000",
            "unit": "metric tons CO2e",
            "year": "2024",
            "source_citation": "Test SR 2024, p.61 — GHG",
            "source_url": "https://example.com/s324",
        },
        {
            "metric": "General ESG Disclosure Score",
            "value": "74.0",
            "unit": "score (0-100)",
            "year": "2024",
            "source_citation": "Test AR FY2024, p.10 — ESG",
            "source_url": "https://example.com/esg",
        },
        {
            "metric": "Transition Capex Contraction",
            "value": "-55.7",
            "unit": "percent vs 2021 baseline",
            "year": "2024",
            "source_citation": "Test AR 2024, p.99 — Capex",
            "source_url": "https://example.com/capex",
        },
        {
            "metric": "Jurisdictional Arbitrage Flag",
            "value": "0",
            "unit": "binary (0=no flag)",
            "year": "2024",
            "source_citation": "Companies House UK Filing 2022, p.1 — Incorporation",
            "source_url": "https://example.com/ch",
        },
    ]
    fieldnames = [
        "metric", "value", "unit", "year", "source_citation", "source_url",
    ]
    path = tmp_path / "shell_public_audit_2024.csv"
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

    monkeypatch.setattr(dl, "get_csv_path", lambda _: path)
    records = dl.load_audit_data("shell")
    table = build_traceability_matrix(records, COMPANY_CONFIG["shell"])

    buf = io.StringIO()
    Console(file=buf, width=160, force_terminal=True).print(table)
    text = buf.getvalue()
    collapsed = " ".join(text.split())
    assert "Col 'value'" not in text
    assert "Row: 2" in text
    assert "Column: 2" in text
    assert "p.42" in collapsed and "Upstream" in collapsed


def test_citation_cell_bolds_page_prefix():
    from agents.auditor_agent import _citation_cell_text

    t = _citation_cell_text("Report Name 2015, p.42 — Section detail here")
    plain = t.plain
    assert "Report Name 2015, p.42" in plain
    assert "Section detail" in plain


def test_traceability_location_text_two_line_cell():
    from agents.auditor_agent import _traceability_location_text

    rec = {
        "_csv_row_index": 2,
        "_csv_source_basename": "shell_public_audit_2024.csv",
        "_csv_fieldnames": (
            "metric", "value", "unit", "year", "source_citation", "source_url",
        ),
    }
    plain = _traceability_location_text(rec).plain
    assert "shell_public_audit_2024.csv" in plain
    assert "Row: 2" in plain
    assert "Column: 2" in plain
