# MIT License — see LICENSE file
"""Integration-style test for run_audit_pipeline (Pillar D programmatic hook)."""

from __future__ import annotations

import json
from pathlib import Path

from run_auditlens import run_audit_pipeline


def test_run_audit_pipeline_returns_report_and_writes_json(tmp_path: Path) -> None:
    """Uses cached LLM data; writes artifacts under tmp_path."""
    out = run_audit_pipeline(
        "shell",
        use_cached=True,
        output_dir=tmp_path,
        run_stress=False,
        run_simulate=False,
        verbose_llm=False,
        export_pm_csv=False,
        strict_artifacts=False,
    )
    assert "report" in out
    assert out["report"]["system"]["company"] == "shell"
    assert "artifact_paths" in out
    jp = Path(out["artifact_paths"]["json"])
    assert jp.exists()
    on_disk = json.loads(jp.read_text(encoding="utf-8"))
    assert on_disk["system"]["company"] == "shell"
    assert on_disk["verdict"]["integrity_discount"] == out["report"]["verdict"]["integrity_discount"]
