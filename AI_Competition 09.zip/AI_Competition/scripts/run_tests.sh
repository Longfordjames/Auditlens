#!/usr/bin/env bash
# MIT License — see LICENSE file
# =============================================================================
# AuditLens CI/CD Test Runner
# =============================================================================
# Runs the full pytest suite with rich-formatted PASS/FAIL summary.
# All tests execute 100% offline — zero API calls, zero cost.
#
# Usage:
#   bash scripts/run_tests.sh            # from any directory
#   chmod +x scripts/run_tests.sh && ./scripts/run_tests.sh
#
# Requires: Python 3.9+, pytest (auto-installed if missing), rich
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

cd "${PROJECT_ROOT}"

# ── Terminal width separator ──────────────────────────────────────────────────
SEP="════════════════════════════════════════════════════════════════════════"

echo ""
echo "${SEP}"
echo "  AuditLens QA Suite — Production-Grade Verification"
echo "  Team Alpha 1 | Durham University | CFA AI Challenge 2025-26"
echo "${SEP}"
echo ""
echo "  Project root : ${PROJECT_ROOT}"
echo "  Test path    : ${PROJECT_ROOT}/tests/"
echo "  Portable run : python3 -m pytest tests/ -q   (no bash required)"
echo ""

# ── Install pytest if missing ─────────────────────────────────────────────────
if ! python3 -m pytest --version >/dev/null 2>&1; then
    echo "  [SETUP] pytest not found — installing..."
    python3 -m pip install pytest --quiet
    echo "  [SETUP] pytest installed."
fi

PYTEST_VERSION=$(python3 -m pytest --version 2>&1 | head -1)
echo "  ${PYTEST_VERSION}"
echo ""

# ── Run the test suite ────────────────────────────────────────────────────────
echo "${SEP}"
echo "  Running: python3 -m pytest -v tests/ --tb=short"
echo "${SEP}"
echo ""

# Capture exit code without triggering set -e
python3 -m pytest -v tests/ --tb=short 2>&1
EXIT_CODE=$?

echo ""
echo "${SEP}"

# ── Rich-formatted summary ────────────────────────────────────────────────────
if [ "${EXIT_CODE}" -eq 0 ]; then
    python3 - <<'PYEOF'
from rich.console import Console
from rich.panel   import Panel
from rich.text    import Text

c   = Console()
msg = Text()
msg.append("  ✓  ALL TESTS PASSED\n",   style="bold green")
msg.append("  AuditLens QA Suite — Production-Grade Verification Complete\n",
           style="green")
msg.append("  Zero API calls  |  100% Offline  |  CFA Rule 4.4 Compliant\n",
           style="dim green")
msg.append("  Full tests/ package verified offline",
           style="dim green")
c.print(Panel(
    msg,
    title="[bold white on green]  AUDITLENS CI/CD — PASS  [/bold white on green]",
    border_style="bold green",
    padding=(0, 1),
))
PYEOF
else
    python3 - <<'PYEOF'
from rich.console import Console
from rich.panel   import Panel
from rich.text    import Text

c   = Console()
msg = Text()
msg.append("  ✗  TEST FAILURES DETECTED\n",  style="bold red")
msg.append("  See verbose output above for failure details.\n", style="red")
msg.append("  Run for full tracebacks:\n",  style="dim red")
msg.append("    python3 -m pytest -v tests/ --tb=long\n", style="cyan")
c.print(Panel(
    msg,
    title="[bold white on red]  AUDITLENS CI/CD — FAIL  [/bold white on red]",
    border_style="bold red",
    padding=(0, 1),
))
PYEOF
    exit 1
fi
