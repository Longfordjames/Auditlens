# MIT License — see LICENSE file
"""Tests for Data_Input/sync_audit_from_folder.py and narrative YAML overrides."""

from __future__ import annotations

import csv
import importlib.util
import json
import shutil
from copy import deepcopy
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]


def _load_sync_module():
    path = REPO / "Data_Input" / "sync_audit_from_folder.py"
    spec = importlib.util.spec_from_file_location("sync_audit_from_folder", path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="module")
def sync_mod():
    return _load_sync_module()


def test_match_internal_key_exact(sync_mod):
    am = sync_mod.load_mapping_aliases()
    assert sync_mod.match_internal_key("Total energy consumption", am) == "Upstream_Fuel_Consumption"
    assert sync_mod.match_internal_key("Scope 3 Indirect Emissions", am) == "Scope_3_Emissions"


def test_apply_scope3_transform(sync_mod):
    v, u = sync_mod.apply_scope3_transform(
        "Scope_3_Emissions",
        1281.0,
        "million tCO2e",
        {"scope3_excel_multiplier": 1_000_000},
    )
    assert v == 1_281_000_000
    assert "metric tons" in u
    v2, _ = sync_mod.apply_scope3_transform(
        "Scope_3_Emissions",
        9_043_000.0,
        "metric tons CO2e",
        {"scope3_excel_multiplier": 1_000_000},
    )
    assert v2 == 9_043_000.0


def test_find_header_row(sync_mod):
    rows = [
        ("a", "b", 2019, 2020, 2021),
        ("x", "metric", 1, 2, 3),
    ]
    hi, cmap = sync_mod.find_header_row(rows, max_scan=2)
    assert 2020 in cmap
    assert hi == 0


def test_pdf_fallback_regex(sync_mod, tmp_path: Path, monkeypatch):
    pdf_path = tmp_path / "t.pdf"
    try:
        from pypdf import PdfWriter
    except ImportError:
        pytest.skip("pypdf not installed")

    writer = PdfWriter()
    writer.add_blank_page(width=200, height=200)
    with open(pdf_path, "wb") as fh:
        writer.write(fh)

    def fake_extract(path, ps, pe):
        return "Climate\nScope 3(5) GHG emissions at 342 Mt CO2e in 2024\nfooter"

    monkeypatch.setattr(sync_mod, "extract_pdf_text", fake_extract)

    pdf_sources = {
        "doc": {"path": str(pdf_path.relative_to(tmp_path)), "public_url": "https://example.com/a.pdf"}
    }
    rule = {
        "pdf_key": "doc",
        "pages": [1, 1],
        "anchor_substrings": ["Scope 3", "342"],
        "regex": r"([0-9]+)\s*Mt",
        "scale": 1_000_000,
        "unit": "metric tons CO2e",
        "citation_note": "test",
    }
    monkeypatch.setattr(sync_mod, "REPO_ROOT", tmp_path)
    pdf_sources["doc"]["path"] = "t.pdf"
    out = sync_mod.pdf_fallback_value(rule, pdf_sources, verbose=False)
    assert out is not None
    val, unit, _ = out
    assert val == 342_000_000
    assert "metric" in unit


def test_corporate_agent_yaml_override(tmp_path: Path):
    pytest.importorskip("yaml")
    from agents import corporate_agent as ca

    nd = tmp_path / "narratives"
    nd.mkdir(parents=True)
    ypath = nd / "shell_excerpts.yaml"
    ypath.write_text(
        "excerpts_2024: |\n  [SOURCE: Test Override, p.1]\n  \"UNIQUE_EXCERPT_TOKEN_12345\"\n",
        encoding="utf-8",
    )
    shell_orig = deepcopy(ca.COMPANY_NARRATIVES["shell"])
    try:
        ca._merge_data_input_narrative_overrides(nd)
        assert "UNIQUE_EXCERPT_TOKEN_12345" in ca.COMPANY_NARRATIVES["shell"]["excerpts_2024"]
    finally:
        ca.COMPANY_NARRATIVES["shell"] = shell_orig


def test_end_to_end_mini_workbook(sync_mod, tmp_path: Path, monkeypatch):
    openpyxl = pytest.importorskip("openpyxl")
    yaml = pytest.importorskip("yaml")

    root = tmp_path
    (root / "config").mkdir(parents=True)
    shutil.copy(REPO / "config" / "mapping.json", root / "config" / "mapping.json")

    di = root / "Data_Input"
    di.mkdir(parents=True)
    wb_path = di / "Mini_ESG.xlsx"
    ws_data = [
        ("", "Metric", "", "Unit", 2020, 2021, 2024),
        ("", "Total energy consumption", "", "million MWh", 100.0, 110.0, 120.0),
        ("", "Scope 3 Indirect Emissions", "", "million tCO2e", 50.0, 48.0, 40.0),
        ("", "DE&I index", "", "score", 0, 0, 81.0),
        ("", "Transition Capex Contraction", "", "%", 0, 0, -10.0),
        ("", "Jurisdictional Arbitrage Flag", "", "flag", 0, 0, 0),
    ]
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "ESG"
    for row in ws_data:
        ws.append(list(row))
    wb.save(wb_path)
    wb.close()

    manifest = {
        "version": 1,
        "defaults": {
            "audit_years": [2015, 2021, 2024],
            "excel": {
                "metric_column_index": 1,
                "unit_column_index": 3,
                "max_header_scan_rows": 8,
            },
            "narrative": {"max_paragraph_chars": 500, "min_paragraph_chars": 10},
        },
        "companies": {
            "acme": {
                "workbook": "Data_Input/Mini_ESG.xlsx",
                "sheet": "ESG",
                "year_columns": {2015: 2020, 2021: 2021, 2024: 2024},
                "output_metrics": {
                    "Upstream_Fuel_Consumption": "Total energy consumption",
                    "Scope_3_Emissions": "Total Scope 3 GHG Emissions",
                    "ESG_Disclosure_Score": "General ESG Disclosure Score",
                    "Transition_Capex": "Transition Capex Contraction",
                    "Jurisdictional_Arbitrage": "Jurisdictional Arbitrage Flag",
                },
                "excel_citation": {
                    "workbook_display": "Mini_ESG.xlsx",
                    "sheet_display": "ESG",
                },
                "default_source_url": "https://example.com/public",
                "scope3_excel_multiplier": 1_000_000,
                "pdf_sources": {},
                "pdf_fallback": [],
                "narratives": {},
            }
        },
    }
    with open(di / "manifest.yaml", "w", encoding="utf-8") as fh:
        yaml.dump(manifest, fh)

    monkeypatch.setattr(sync_mod, "REPO_ROOT", root)
    monkeypatch.setattr(sync_mod, "DATA_INPUT", di)
    monkeypatch.setattr(sync_mod, "MANIFEST_PATH", di / "manifest.yaml")
    monkeypatch.setattr(sync_mod, "MAPPING_PATH", root / "config" / "mapping.json")
    monkeypatch.setattr(sync_mod, "SECTOR_DIR", root / "data" / "energy_sector")

    alias_map = sync_mod.load_mapping_aliases()
    loaded = sync_mod.load_manifest()
    rc = sync_mod.sync_company(
        "acme", loaded, alias_map, dry_run=False, verbose=False, write_sector=False
    )
    assert rc == 0

    out_csv = di / "acme_public_audit_2024.csv"
    assert out_csv.exists()
    with open(out_csv, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    metrics = {(r["metric"], int(r["year"])): r["value"] for r in rows}
    assert metrics[("Total energy consumption", 2024)] == "120"
    assert metrics[("Total Scope 3 GHG Emissions", 2024)] == str(int(40 * 1_000_000))


def test_validate_only_acme_ok(sync_mod, tmp_path: Path, monkeypatch):
    openpyxl = pytest.importorskip("openpyxl")
    yaml = pytest.importorskip("yaml")

    root = tmp_path
    (root / "config").mkdir(parents=True)
    shutil.copy(REPO / "config" / "mapping.json", root / "config" / "mapping.json")

    di = root / "Data_Input"
    di.mkdir(parents=True)
    wb_path = di / "Mini_ESG.xlsx"
    ws_data = [
        ("", "Metric", "", "Unit", 2020, 2021, 2024),
        ("", "Total energy consumption", "", "million MWh", 100.0, 110.0, 120.0),
        ("", "Scope 3 Indirect Emissions", "", "million tCO2e", 50.0, 48.0, 40.0),
        ("", "DE&I index", "", "score", 0, 0, 81.0),
        ("", "Transition Capex Contraction", "", "%", 0, 0, -10.0),
        ("", "Jurisdictional Arbitrage Flag", "", "flag", 0, 0, 0),
    ]
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "ESG"
    for row in ws_data:
        ws.append(list(row))
    wb.save(wb_path)
    wb.close()

    manifest = {
        "version": 1,
        "defaults": {
            "audit_years": [2015, 2021, 2024],
            "excel": {
                "metric_column_index": 1,
                "unit_column_index": 3,
                "max_header_scan_rows": 8,
            },
            "scalar_years": {
                "esg": 2024,
                "transition_capex": 2024,
                "jurisdictional_arbitrage": 2024,
            },
            "narrative": {"max_paragraph_chars": 500, "min_paragraph_chars": 10},
        },
        "companies": {
            "acme": {
                "workbook": "Data_Input/Mini_ESG.xlsx",
                "sheet": "ESG",
                "year_columns": {2015: 2020, 2021: 2021, 2024: 2024},
                "output_metrics": {
                    "Upstream_Fuel_Consumption": "Total energy consumption",
                    "Scope_3_Emissions": "Total Scope 3 GHG Emissions",
                    "ESG_Disclosure_Score": "General ESG Disclosure Score",
                    "Transition_Capex": "Transition Capex Contraction",
                    "Jurisdictional_Arbitrage": "Jurisdictional Arbitrage Flag",
                },
                "excel_citation": {
                    "workbook_display": "Mini_ESG.xlsx",
                    "sheet_display": "ESG",
                },
                "default_source_url": "https://example.com/public",
                "scope3_excel_multiplier": 1_000_000,
                "pdf_sources": {},
                "pdf_fallback": [],
                "narratives": {},
            }
        },
    }
    with open(di / "manifest.yaml", "w", encoding="utf-8") as fh:
        yaml.dump(manifest, fh)

    monkeypatch.setattr(sync_mod, "REPO_ROOT", root)
    monkeypatch.setattr(sync_mod, "DATA_INPUT", di)
    monkeypatch.setattr(sync_mod, "MANIFEST_PATH", di / "manifest.yaml")
    monkeypatch.setattr(sync_mod, "MAPPING_PATH", root / "config" / "mapping.json")

    loaded = sync_mod.load_manifest()
    alias_map = sync_mod.load_mapping_aliases()
    rc, errs = sync_mod.validate_company_excel("acme", loaded, alias_map, verbose=False)
    assert rc == 0
    assert errs == []


def test_validate_only_missing_workbook(sync_mod, tmp_path: Path, monkeypatch):
    yaml = pytest.importorskip("yaml")

    root = tmp_path
    (root / "config").mkdir(parents=True)
    shutil.copy(REPO / "config" / "mapping.json", root / "config" / "mapping.json")
    di = root / "Data_Input"
    di.mkdir(parents=True)
    manifest = {
        "defaults": {"audit_years": [2015, 2021, 2024], "scalar_years": {}},
        "companies": {
            "ghost": {
                "workbook": "Data_Input/Nope.xlsx",
                "sheet": "ESG",
                "year_columns": {2015: 2020, 2021: 2021, 2024: 2024},
                "output_metrics": {
                    "Upstream_Fuel_Consumption": "Total energy consumption",
                    "Scope_3_Emissions": "Total Scope 3 GHG Emissions",
                    "ESG_Disclosure_Score": "General ESG Disclosure Score",
                    "Transition_Capex": "Transition Capex Contraction",
                    "Jurisdictional_Arbitrage": "Jurisdictional Arbitrage Flag",
                },
            }
        },
    }
    with open(di / "manifest.yaml", "w", encoding="utf-8") as fh:
        yaml.dump(manifest, fh)

    monkeypatch.setattr(sync_mod, "REPO_ROOT", root)
    monkeypatch.setattr(sync_mod, "DATA_INPUT", di)
    monkeypatch.setattr(sync_mod, "MANIFEST_PATH", di / "manifest.yaml")
    monkeypatch.setattr(sync_mod, "MAPPING_PATH", root / "config" / "mapping.json")

    loaded = sync_mod.load_manifest()
    alias_map = sync_mod.load_mapping_aliases()
    rc, errs = sync_mod.validate_company_excel("ghost", loaded, alias_map, verbose=False)
    assert rc == 1
    assert any("workbook not found" in e for e in errs)
