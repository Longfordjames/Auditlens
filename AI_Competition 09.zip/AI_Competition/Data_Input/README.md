# Data_Input — PM audit CSV drop zone

## Workflow

1. **Drop** your Excel workbooks, PDF mirrors, and (for auto-sync) keep [`manifest.yaml`](manifest.yaml) aligned with paths—see [`portfolio.template.yaml`](portfolio.template.yaml) for a copy-paste stub. Optionally **bootstrap** stubs from workbooks:  
   `python3 Data_Input/bootstrap_manifest.py --dry-run`  
   `python3 Data_Input/bootstrap_manifest.py --file Data_Input/MyCo.xlsx --company-slug myco --map 2015:2020,2021:2021,2024:2024`  
   Use `--use-mapping-labels` to seed `output_metrics` from the first alias in [`config/mapping.json`](../config/mapping.json). `--append-to Data_Input/manifest.yaml` merges new companies (review the diff in git; YAML comments are not preserved).
2. **Validate** quickly (no CSV writes):  
   `python3 Data_Input/sync_audit_from_folder.py --validate-only --company shell`  
3. **Sync** from the repo root:  
   `python3 Data_Input/run_sync.py`  
   This runs `sync_audit_from_folder.py` with `--company all --write-sector` so CSVs land in `Data_Input/` **and** `data/energy_sector/` (sector scan sees the same roster).  
   Or run the pipeline with ingest: `python3 run_auditlens.py --ingest-data-input --company all --use-cached` (see main repo README / `run_auditlens.py --help`).
4. **Analyse**:  
   `python3 run_auditlens.py --company shell --use-cached`  
   or `python3 run_auditlens.py --sector-scan --use-cached`

[`config/audit_profile.py`](../config/audit_profile.py) reads `manifest.yaml` for **iod_endpoints** (ΔRI/Scope3 years), **scalar_years** (ESG / transition / arb row years), and **event_study** (narrative + trajectory timeline). Defaults are under `defaults:` in `manifest.yaml`.

Set **`defaults.dynamic_iod_years: true`** (or per-company `dynamic_iod_years`) to drive ΔResource / ΔScope3 and the auditor traceability matrix fuel+scope3 endpoints from **min(year)→max(year)** in the loaded CSV (excluding `narrative_sentiment` rows). Requires at least two distinct years. When `false`, **`iod_endpoints.resource_and_scope3`** is used as today.

**Sector scan:** [`TEMPLATE_public_audit_2024.csv`](TEMPLATE_public_audit_2024.csv) is **not** treated as an issuer; it is omitted from `scan_energy_sector_companies()` so `--sector-scan` skips the template stub.

---

Place company audit files here to override the shipped `data/energy_sector/` defaults without editing the repository baseline.

## File naming

- One CSV per issuer: `{company}_public_audit_2024.csv`
- Examples: `shell_public_audit_2024.csv`, `bp_public_audit_2024.csv`, `orsted_public_audit_2024.csv`, `totalenergies_public_audit_2024.csv`
- `company` must match the `--company` / sector-scan identifier (lowercase).

## Required columns (exact headers)

`metric`, `value`, `unit`, `year`, `source_citation`, `source_url`

Every numeric row must cite a **public** source (report title, year, page or section) and a **URL** to that filing or the issuer’s public sustainability hub. Phase 2 can tighten page-level citations when annual reports are added.

## Auto-sync from Excel + PDF (`sync_audit_from_folder.py`)

The script rebuilds `Data_Input/{company}_public_audit_2024.csv` from:

1. **Excel (primary)** — workbook + sheet + FY columns listed in [`manifest.yaml`](manifest.yaml). Row labels are matched to internal metrics via [`config/mapping.json`](../config/mapping.json) aliases.
2. **PDF (fallback)** — if a metric/year cell is missing, optional `pdf_fallback` rules extract a value with regex + anchors from a local mirror under `reports/` (you must set `public_url` in the manifest; the script does not guess URLs).
3. **Narratives** — when `narratives.{year}.pdf_key` points at an existing file, the script writes `narratives/{company}_excerpts.yaml`. [`agents/corporate_agent.py`](../agents/corporate_agent.py) loads that YAML at import time and overrides built-in excerpts.

```bash
pip install pyyaml pypdf   # also in requirements.txt
python3 Data_Input/sync_audit_from_folder.py --company all
python3 Data_Input/sync_audit_from_folder.py --dry-run --verbose
python3 Data_Input/sync_audit_from_folder.py --write-sector   # also copy CSVs into data/energy_sector/
```

Workbook paths in `manifest.yaml` are relative to the **repository root** (not only inside `Data_Input/`). Copy or symlink annual workbooks into the repo paths declared in the manifest, or edit the manifest to match your layout.

**LLM cache:** Changing `narratives/*_excerpts.yaml` changes CorporateAgent prompts and therefore `data/api_cache.json` keys. Regenerate cache with a **live** run (no `--use-cached`) for affected companies, run `python3 scripts/rekey_corporate_cache.py`, or restore the committed cache from git.

**Optional `auto_narratives`:** In `manifest.yaml`, set `defaults.auto_narratives: true` or per-company `auto_narratives: true`, and provide `auto_narrative_pdf_keys` mapping each **event_study** year (baseline / mid / current) to a `pdf_sources` key. Sync will fill missing `narratives.{year}` entries using `extract_pdf_text` + `pick_narrative_paragraphs` (default pages from `defaults.auto_narrative_page_start` / `auto_narrative_page_end`, typically 1–12). This alters prompts → **rekey or live** under Rule 4.4 (see `scripts/README.md`).

## Excel workbooks (manual CSV path)

You can still Save As → **CSV UTF-8** using [`TEMPLATE_public_audit_2024.csv`](TEMPLATE_public_audit_2024.csv) instead of using the sync script.

## Optional evidence PDFs

Store supporting PDFs under `Data_Input/reports/` for traceability and for **`sync_audit_from_folder.py`** fallback / narrative extraction. The main AuditLens pipeline still reads **numeric metrics from CSV only**; PDFs are used by the sync script when configured in `manifest.yaml`.

### TotalEnergies — suggested mirror filenames ↔ public URLs

Use the same filenames in CSV `source_citation` “Local mirror” notes if you drop copies locally (optional; defaults remain issuer HTTPS links).

| Suggested local filename | Public document (English) |
|--------------------------|---------------------------|
| `registration_document_2015.pdf` | [TOTAL S.A. Registration Document 2015](https://totalenergies.com/sites/g/files/nytnzq111/files/atoms/files/registration_document_2015.pdf) |
| `TotalEnergies_URD_2022_EN.pdf` | [Universal Registration Document 2022](https://totalenergies.com/sites/g/files/nytnzq121/files/documents/2023-03/TotalEnergies_URD_2022_EN.pdf) |
| `totalenergies_universal-registration-document-2023_2023_en_pdf.pdf` | [Universal Registration Document 2023](https://totalenergies.com/system/files/documents/2024-03/totalenergies_universal-registration-document-2023_2023_en_pdf.pdf) |
| `totalenergies_universal-registration-document-2024_2025_en.pdf` | [Universal Registration Document 2024](https://totalenergies.com/system/files/documents/totalenergies_universal-registration-document-2024_2025_en.pdf) |
| `totalenergies_universal-registration-document-2025_2026_en.pdf` | [Universal Registration Document 2025](https://totalenergies.com/system/files/documents/totalenergies_universal-registration-document-2025_2026_en.pdf) |

Index of annual / regulated filings: [Annual financial reports](https://totalenergies.com/investors/publications-and-regulated-information/regulated-information/annual-financial-reports).

## Loader precedence

1. `Data_Input/{company}_public_audit_2024.csv` if the file exists  
2. `data/energy_sector/{company}_public_audit_2024.csv`  
3. `data/{company}_public_audit_2024.csv` (legacy)

Override the folder with:

`python3 run_auditlens.py --input-dir /path/to/folder --company shell --use-cached`

## Narrative sentiment (cached runs)

Rows with `metric` = `narrative_sentiment` supply pre-seeded multi-year sentiment when using `--use-cached`. If you omit them, behaviour depends on the rest of the pipeline; for competition demos, keep the same three years as the template sector files unless you regenerate LLM cache intentionally.
