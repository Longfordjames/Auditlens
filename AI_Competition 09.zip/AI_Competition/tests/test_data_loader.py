# MIT License — see LICENSE file
"""
tests/test_data_loader.py
==========================
Unit tests for data_loader.py — CSV ingestion, CFA Rule 4.6 schema validation,
derived calculations, and error handling.

All tests run offline using pytest's tmp_path fixture to create temporary
CSV files — no network access, no dependency on production data files.

Coverage areas:
  • Schema validation:   required columns, missing columns, empty CSV
  • FileNotFoundError:   missing CSV path
  • Provenance columns:  source_citation and source_url always present
  • ΔResource Intensity: positive (Shell) and negative (Ørsted) cases
  • Disclosure Density:  normalisation to [0, 1]
  • ΔScope 3:            flat (Shell), declining (Ørsted)
  • get_metric():        success, KeyError on missing metric
  • get_csv_path():      correct filenames for each company
"""

import csv
import pytest
from pathlib import Path


# ── Shared helper ─────────────────────────────────────────────────────────────

_REQUIRED_COLUMNS = ["metric", "value", "unit", "year", "source_citation", "source_url"]

_BASE_ROWS = [
    {
        "metric":          "Test Fuel Metric",
        "value":           "1130000",
        "unit":            "TJ",
        "year":            "2015",
        "source_citation": "Test Source 2015, p.42",
        "source_url":      "https://example.com/2015",
    },
    {
        "metric":          "Test Fuel Metric",
        "value":           "12030000",
        "unit":            "TJ",
        "year":            "2024",
        "source_citation": "Test Source 2024, p.78",
        "source_url":      "https://example.com/2024",
    },
    {
        "metric":          "General ESG Disclosure Score",
        "value":           "74.0",
        "unit":            "score (0-100)",
        "year":            "2024",
        "source_citation": "Test AR FY2024, App.IV",
        "source_url":      "https://example.com/ar2024",
    },
    {
        "metric":          "Total Scope 3 GHG Emissions",
        "value":           "1080000",
        "unit":            "metric tons CO2e",
        "year":            "2015",
        "source_citation": "Test SR 2015, p.48",
        "source_url":      "https://example.com/sr2015",
    },
    {
        "metric":          "Total Scope 3 GHG Emissions",
        "value":           "1080000",
        "unit":            "metric tons CO2e",
        "year":            "2024",
        "source_citation": "Test SR 2024, p.61",
        "source_url":      "https://example.com/sr2024",
    },
]


def _write_csv(path: Path, rows: list, fieldnames: list = None) -> Path:
    """Write a CSV file at the given path and return it."""
    if fieldnames is None:
        fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return path


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Schema Validation (CFA Rule 4.6 Compliance)
# ═══════════════════════════════════════════════════════════════════════════════

class TestSchemaValidation:
    """load_audit_data() must reject CSVs that lack mandatory provenance columns."""

    def test_valid_csv_loads_successfully(self, tmp_path, monkeypatch):
        """Full schema CSV with all required columns loads without error."""
        import data_loader as dl
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", _BASE_ROWS)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        records = dl.load_audit_data("x")
        assert len(records) == len(_BASE_ROWS)

    def test_all_rows_have_source_citation(self, tmp_path, monkeypatch):
        """Every loaded record contains source_citation (CFA Rule 4.6)."""
        import data_loader as dl
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", _BASE_ROWS)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        records = dl.load_audit_data("x")
        assert all("source_citation" in r and r["source_citation"] for r in records)

    def test_all_rows_have_source_url(self, tmp_path, monkeypatch):
        """Every loaded record contains source_url (CFA Rule 4.6)."""
        import data_loader as dl
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", _BASE_ROWS)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        records = dl.load_audit_data("x")
        assert all("source_url" in r and r["source_url"] for r in records)

    def test_csv_traceability_metadata_on_each_row(self, tmp_path, monkeypatch):
        """Each row carries field order and basename for A1-style terminal Location."""
        import data_loader as dl
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", _BASE_ROWS)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        records = dl.load_audit_data("x")
        expected_fn = tuple(_REQUIRED_COLUMNS)
        for i, r in enumerate(records):
            assert r["_csv_source_basename"] == "x_public_audit_2024.csv"
            assert r["_csv_fieldnames"] == expected_fn
            assert r["_csv_row_index"] == i + 2

    def test_missing_source_citation_raises_value_error(self, tmp_path, monkeypatch):
        """Missing 'source_citation' column raises ValueError — CFA Rule 4.6."""
        import data_loader as dl
        cols  = [c for c in _REQUIRED_COLUMNS if c != "source_citation"]
        rows  = [{k: v for k, v in r.items() if k != "source_citation"} for r in _BASE_ROWS]
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", rows, fieldnames=cols)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        with pytest.raises(ValueError, match="source_citation"):
            dl.load_audit_data("x")

    def test_missing_source_url_raises_value_error(self, tmp_path, monkeypatch):
        """Missing 'source_url' column raises ValueError — CFA Rule 4.6."""
        import data_loader as dl
        cols  = [c for c in _REQUIRED_COLUMNS if c != "source_url"]
        rows  = [{k: v for k, v in r.items() if k != "source_url"} for r in _BASE_ROWS]
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", rows, fieldnames=cols)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        with pytest.raises(ValueError, match="source_url"):
            dl.load_audit_data("x")

    def test_missing_metric_column_raises_value_error(self, tmp_path, monkeypatch):
        """Missing 'metric' column raises ValueError."""
        import data_loader as dl
        cols  = [c for c in _REQUIRED_COLUMNS if c != "metric"]
        rows  = [{k: v for k, v in r.items() if k != "metric"} for r in _BASE_ROWS]
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", rows, fieldnames=cols)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        with pytest.raises(ValueError):
            dl.load_audit_data("x")

    def test_missing_year_column_raises_value_error(self, tmp_path, monkeypatch):
        """Missing 'year' column raises ValueError."""
        import data_loader as dl
        cols  = [c for c in _REQUIRED_COLUMNS if c != "year"]
        rows  = [{k: v for k, v in r.items() if k != "year"} for r in _BASE_ROWS]
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", rows, fieldnames=cols)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        with pytest.raises(ValueError):
            dl.load_audit_data("x")

    def test_multiple_missing_columns_error_mentions_both(self, tmp_path, monkeypatch):
        """ValueError for multiple missing columns mentions all absent fields."""
        import data_loader as dl
        cols = ["metric", "value", "unit", "year"]   # missing source_citation, source_url
        rows = [{"metric": r["metric"], "value": r["value"],
                 "unit": r["unit"], "year": r["year"]} for r in _BASE_ROWS]
        csv_file = _write_csv(tmp_path / "x_public_audit_2024.csv", rows, fieldnames=cols)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        with pytest.raises(ValueError) as exc_info:
            dl.load_audit_data("x")
        error_msg = str(exc_info.value)
        assert "source_citation" in error_msg or "source_url" in error_msg


# ═══════════════════════════════════════════════════════════════════════════════
# 2. File-Level Error Handling
# ═══════════════════════════════════════════════════════════════════════════════

class TestFileErrors:
    """FileNotFoundError and edge cases."""

    def test_missing_csv_raises_file_not_found(self, tmp_path, monkeypatch):
        """Non-existent CSV path raises FileNotFoundError."""
        import data_loader as dl
        monkeypatch.setattr(dl, "get_csv_path", lambda _: tmp_path / "ghost.csv")
        with pytest.raises(FileNotFoundError):
            dl.load_audit_data("ghost")

    def test_file_not_found_error_message_contains_path(self, tmp_path, monkeypatch):
        """FileNotFoundError message includes the expected file path."""
        import data_loader as dl
        nonexistent = tmp_path / "ghost_public_audit_2024.csv"
        monkeypatch.setattr(dl, "get_csv_path", lambda _: nonexistent)
        with pytest.raises(FileNotFoundError) as exc_info:
            dl.load_audit_data("ghost")
        assert "ghost" in str(exc_info.value).lower() or str(nonexistent) in str(exc_info.value)

    def test_get_csv_path_shell(self):
        """get_csv_path('shell') returns shell_public_audit_2024.csv from sector or Data_Input."""
        from data_loader import get_csv_path
        p = get_csv_path("shell")
        assert p.name == "shell_public_audit_2024.csv"
        assert p.parent.name in ("data", "energy_sector", "Data_Input")

    def test_get_csv_path_orsted(self):
        """get_csv_path('orsted') returns path ending in orsted_public_audit_2024.csv."""
        from data_loader import get_csv_path
        p = get_csv_path("orsted")
        assert p.name == "orsted_public_audit_2024.csv"

    def test_get_csv_path_custom_company(self):
        """get_csv_path supports arbitrary company names."""
        from data_loader import get_csv_path
        p = get_csv_path("bp")
        assert p.name == "bp_public_audit_2024.csv"

    def test_input_dir_overrides_sector_when_file_present(self, tmp_path, monkeypatch):
        """Data_Input (or overridden input dir) wins over data/energy_sector/."""
        import data_loader as dl

        sector_stub = tmp_path / "energy_sector"
        sector_stub.mkdir()
        input_dir = tmp_path / "pm_drop"
        input_dir.mkdir()
        prefer = input_dir / "acme_public_audit_2024.csv"
        fallback = sector_stub / "acme_public_audit_2024.csv"
        row = {
            "metric": "m", "value": "1", "unit": "u", "year": "2024",
            "source_citation": "c", "source_url": "https://example.com",
        }
        _write_csv(prefer, [row])
        _write_csv(fallback, [{**row, "value": "2"}])

        monkeypatch.setattr(dl, "_DATA_DIR", tmp_path)
        monkeypatch.setattr(dl, "_SECTOR_DIR", sector_stub)
        monkeypatch.setattr(dl, "_DEFAULT_INPUT_DIR", input_dir)
        monkeypatch.setattr(dl, "_INPUT_DIR_OVERRIDE", None)

        assert dl.get_csv_path("acme") == prefer
        recs = dl.load_audit_data("acme")
        assert recs[0]["value"] == "1"


# ═══════════════════════════════════════════════════════════════════════════════
# 3. get_metric() — Provenance Retrieval
# ═══════════════════════════════════════════════════════════════════════════════

class TestGetMetric:
    """get_metric() lookup and error cases."""

    def test_get_metric_success(self):
        """get_metric returns correct row when metric+year match."""
        from data_loader import get_metric
        records = [
            {"metric": "Gas TJ", "value": "1000", "unit": "TJ", "year": "2015",
             "source_citation": "S", "source_url": "U"},
        ]
        row = get_metric(records, "Gas TJ", 2015)
        assert row["value"] == "1000"

    def test_get_metric_raises_on_wrong_year(self):
        """get_metric raises KeyError when year doesn't match."""
        from data_loader import get_metric
        records = [
            {"metric": "Gas TJ", "value": "1000", "unit": "TJ", "year": "2015",
             "source_citation": "S", "source_url": "U"},
        ]
        with pytest.raises(KeyError):
            get_metric(records, "Gas TJ", 2024)

    def test_get_metric_raises_on_wrong_name(self):
        """get_metric raises KeyError when metric name doesn't match."""
        from data_loader import get_metric
        records = [
            {"metric": "Gas TJ", "value": "1000", "unit": "TJ", "year": "2015",
             "source_citation": "S", "source_url": "U"},
        ]
        with pytest.raises(KeyError):
            get_metric(records, "Coal TJ", 2015)

    def test_get_metric_strips_whitespace(self):
        """get_metric matches despite leading/trailing whitespace in CSV."""
        from data_loader import get_metric
        records = [
            {"metric": "  Gas TJ  ", "value": "500", "unit": "TJ", "year": "2024",
             "source_citation": "S", "source_url": "U"},
        ]
        row = get_metric(records, "Gas TJ", 2024)
        assert row["value"] == "500"

    def test_get_metric_returns_source_url(self):
        """get_metric result contains source_url (CFA Rule 4.6 provenance)."""
        from data_loader import get_metric
        expected_url = "https://reports.shell.com/2024/"
        records = [
            {"metric": "Gas", "value": "100", "unit": "TJ", "year": "2024",
             "source_citation": "AR 2024", "source_url": expected_url},
        ]
        row = get_metric(records, "Gas", 2024)
        assert row["source_url"] == expected_url


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Derived Calculations — Arithmetic Correctness
# ═══════════════════════════════════════════════════════════════════════════════

def _fuel_records(base: float, curr: float, metric: str = "Test Fuel") -> list:
    """Build minimal fuel consumption records for arithmetic tests."""
    def _row(yr, val):
        return {"metric": metric, "value": str(val), "unit": "TJ",
                "year": str(yr), "source_citation": "S", "source_url": "U"}
    return [_row(2015, base), _row(2024, curr)]


class TestResourceIntensityDelta:
    """compute_resource_intensity_delta() arithmetic."""

    def test_shell_positive_surge(self):
        """Shell: 1.13M → 12.03M TJ → ΔRI ≈ +9.646 (positive)."""
        from data_loader import compute_resource_intensity_delta
        records  = _fuel_records(1_130_000, 12_030_000)
        delta    = compute_resource_intensity_delta(records, fuel_metric="Test Fuel")
        expected = (12_030_000 - 1_130_000) / 1_130_000
        assert abs(delta - expected) < 1e-6
        assert delta > 0

    def test_orsted_negative_reduction(self):
        """Ørsted: 120K → 15K TJ → ΔRI ≈ -0.875 (negative)."""
        from data_loader import compute_resource_intensity_delta
        records  = _fuel_records(120_000, 15_000)
        delta    = compute_resource_intensity_delta(records, fuel_metric="Test Fuel")
        expected = (15_000 - 120_000) / 120_000
        assert abs(delta - expected) < 1e-6
        assert delta < 0

    def test_flat_resource_returns_zero(self):
        """Unchanged consumption → ΔRI = 0.0."""
        from data_loader import compute_resource_intensity_delta
        records = _fuel_records(500_000, 500_000)
        delta   = compute_resource_intensity_delta(records, fuel_metric="Test Fuel")
        assert abs(delta) < 1e-9

    def test_custom_fuel_metric_name(self):
        """fuel_metric parameter selects the correct CSV column name."""
        from data_loader import compute_resource_intensity_delta
        records = _fuel_records(100, 150, metric="Coal TJ")
        delta   = compute_resource_intensity_delta(records, fuel_metric="Coal TJ")
        assert abs(delta - 0.5) < 1e-9  # (150-100)/100 = 0.5


class TestDisclosureDensity:
    """get_disclosure_density() normalisation."""

    def _esg_records(self, score: float) -> list:
        return [{
            "metric": "General ESG Disclosure Score", "value": str(score),
            "unit": "score (0-100)", "year": "2024",
            "source_citation": "S", "source_url": "U",
        }]

    def test_shell_74_normalises_to_0_74(self):
        """Shell ESG score 74.0 → density = 0.74."""
        from data_loader import get_disclosure_density
        density = get_disclosure_density(self._esg_records(74.0))
        assert abs(density - 0.74) < 1e-9

    def test_orsted_88_normalises_to_0_88(self):
        """Ørsted ESG score 88.0 → density = 0.88."""
        from data_loader import get_disclosure_density
        density = get_disclosure_density(self._esg_records(88.0))
        assert abs(density - 0.88) < 1e-9

    def test_max_score_100_normalises_to_1(self):
        """ESG score 100 → density = 1.0."""
        from data_loader import get_disclosure_density
        density = get_disclosure_density(self._esg_records(100.0))
        assert abs(density - 1.0) < 1e-9

    def test_min_score_0_normalises_to_0(self):
        """ESG score 0 → density = 0.0."""
        from data_loader import get_disclosure_density
        density = get_disclosure_density(self._esg_records(0.0))
        assert abs(density - 0.0) < 1e-9


class TestScope3Delta:
    """compute_scope3_delta() percentage change."""

    def _s3_records(self, base: float, curr: float) -> list:
        def _r(yr, val):
            return {"metric": "Total Scope 3 GHG Emissions", "value": str(val),
                    "unit": "t", "year": str(yr), "source_citation": "S", "source_url": "U"}
        return [_r(2015, base), _r(2024, curr)]

    def test_shell_flat_scope3_returns_zero(self):
        """Shell: 1.08M → 1.08M → ΔScope3 = 0.0%."""
        from data_loader import compute_scope3_delta
        delta = compute_scope3_delta(self._s3_records(1_080_000, 1_080_000))
        assert abs(delta) < 1e-9

    def test_orsted_declining_scope3_negative(self):
        """Ørsted: 2.5M → 1.1M → ΔScope3 ≈ -56%."""
        from data_loader import compute_scope3_delta
        delta    = compute_scope3_delta(self._s3_records(2_500_000, 1_100_000))
        expected = ((1_100_000 - 2_500_000) / 2_500_000) * 100
        assert abs(delta - expected) < 1e-6
        assert delta < 0

    def test_increasing_scope3_positive(self):
        """Rising Scope 3 returns positive percentage."""
        from data_loader import compute_scope3_delta
        delta = compute_scope3_delta(self._s3_records(1_000_000, 1_500_000))
        assert delta > 0
        assert abs(delta - 50.0) < 1e-6   # 50% increase


class TestSafeNumericParsing:
    """Defensive CSV cell parsing — no crash on blank/malformed values."""

    def test_safe_float_blank_and_malformed(self):
        import data_loader as dl
        assert dl._safe_float("", 0.0) == 0.0
        assert dl._safe_float("  ", 0.0) == 0.0
        assert dl._safe_float("not-a-number", 1.5) == 1.5
        assert dl._safe_float("12.5", 0.0) == 12.5

    def test_get_metric_skips_bad_year_row(self, tmp_path, monkeypatch):
        import data_loader as dl
        rows = [
            {"metric": "X", "value": "1", "unit": "u", "year": "bad",
             "source_citation": "c", "source_url": "http://e"},
            {"metric": "X", "value": "2", "unit": "u", "year": "2024",
             "source_citation": "c", "source_url": "http://e"},
        ]
        csv_file = _write_csv(tmp_path / "y_public_audit_2024.csv", rows)
        monkeypatch.setattr(dl, "get_csv_path", lambda _: csv_file)
        recs = dl.load_audit_data("y")
        hit = dl.get_metric(recs, "X", 2024)
        assert hit["value"] == "2"


def test_discover_audit_years_from_records_excludes_narrative():
    import data_loader as dl

    recs = [
        {"metric": "Fuel", "year": "2024"},
        {"metric": "narrative_sentiment", "year": "2015"},
        {"metric": "Scope 3", "year": "2020"},
    ]
    assert dl.discover_audit_years_from_records(recs) == [2020, 2024]


def test_scan_energy_sector_companies_excludes_template_stub(tmp_path, monkeypatch):
    import data_loader as dl

    sector = tmp_path / "energy_sector"
    sector.mkdir()
    inp = tmp_path / "input"
    inp.mkdir()
    (sector / "shell_public_audit_2024.csv").write_text("m,v,u,y,c,u\n", encoding="utf-8")
    (inp / "TEMPLATE_public_audit_2024.csv").write_text("m,v,u,y,c,u\n", encoding="utf-8")

    monkeypatch.setattr(dl, "_SECTOR_DIR", sector)
    monkeypatch.setattr(dl, "_DEFAULT_INPUT_DIR", inp)
    monkeypatch.setattr(dl, "_INPUT_DIR_OVERRIDE", None)

    names = dl.scan_energy_sector_companies()
    assert "shell" in names
    assert "TEMPLATE" not in names
    assert "template" not in {n.lower() for n in names}


def test_split_sector_input_excludes_template(tmp_path, monkeypatch):
    import data_loader as dl

    sector = tmp_path / "energy_sector"
    sector.mkdir()
    inp = tmp_path / "input"
    inp.mkdir()
    (inp / "TEMPLATE_public_audit_2024.csv").write_text("x", encoding="utf-8")

    monkeypatch.setattr(dl, "_SECTOR_DIR", sector)
    monkeypatch.setattr(dl, "_DEFAULT_INPUT_DIR", inp)
    monkeypatch.setattr(dl, "_INPUT_DIR_OVERRIDE", None)

    only_sec, only_inp, both = dl.split_sector_input_company_sets()
    assert only_inp == []
    assert both == []
