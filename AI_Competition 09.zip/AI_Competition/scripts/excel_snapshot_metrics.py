#!/usr/bin/env python3
# MIT License — see LICENSE file
"""
Optional helper: print selected FY columns from the team ESG workbooks.

Requires: pip install openpyxl (see requirements.txt)

This does not write audit CSVs; it is a reproducibility aid for judges/PMs who
want to eyeball raw workbook cells alongside data/energy_sector/*.csv.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]

DEFAULT_TARGETS = (
    ("shell", ROOT / "Copy of Shell & Total Data Sources_CFA Alpha 1.xlsx", "ESG Data(test)"),
    ("bp", ROOT / "BP_ESG_Report.xlsx", "ESG Data"),
    ("orsted", ROOT / "ESG_Orested_Report.xlsx", "ESG Data "),
    ("totalenergies", ROOT / "TotalEnergies_ESG_Report.xlsx", "ESG Data(competition)"),
)

METRIC_SUBSTRINGS = (
    "total energy consumption",
    "scope 3 indirect",
    "green capex",
    "low-carbon transition capex",
    "jurisdictional",
)


def dump_sheet(label: str, xlsx: Path, sheet_name: str) -> None:
    if not xlsx.exists():
        print(f"[skip] {label}: missing {xlsx.name}")
        return
    wb = load_workbook(xlsx, read_only=True, data_only=True)
    if sheet_name not in wb.sheetnames:
        print(f"[skip] {label}: sheet {sheet_name!r} not in {wb.sheetnames}")
        wb.close()
        return
    ws = wb[sheet_name]
    rows = list(ws.iter_rows(values_only=True))
    hdr = rows[0]
    year_cols = [c for c in hdr if isinstance(c, int)]
    print(f"\n=== {label}  ({xlsx.name} :: {sheet_name}) ===")
    for r in rows[1:]:
        if not r or not r[1]:
            continue
        m = str(r[1]).strip().lower()
        if not any(s in m for s in METRIC_SUBSTRINGS):
            continue
        vals = {y: r[hdr.index(y)] for y in year_cols if y in hdr}
        print(f"  {r[1]} | unit={r[3]} | {vals}")
    wb.close()


def main() -> None:
    p = argparse.ArgumentParser(description="Snapshot key ESG workbook metrics.")
    p.add_argument(
        "--only",
        choices=["shell", "bp", "orsted", "totalenergies", "all"],
        default="all",
    )
    args = p.parse_args()
    for key, path, sheet in DEFAULT_TARGETS:
        if args.only != "all" and args.only != key:
            continue
        dump_sheet(key, path, sheet)


if __name__ == "__main__":
    main()
