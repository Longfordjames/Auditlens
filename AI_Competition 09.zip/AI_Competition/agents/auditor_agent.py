# MIT License — see LICENSE file
"""
AuditorAgent — Layer 2 (Ground-Truth OSINT)
=============================================
Ingests the researcher-curated Public Audit ESG Dataset for the specified company
and extracts operational realities.

Supports sector-wide ingestion via ``COMPANY_CONFIG`` (Shell, Ørsted, BP,
TotalEnergies) AND dynamic schema resolution for any new company via fuzzy
matching against ``config/mapping.json``.

Universal schema alignment:
  • Known companies: use exact metric names from COMPANY_CONFIG (zero ambiguity)
  • Unknown companies: call ``_auto_detect_config()`` which uses ``difflib`` +
    ``mapping.json`` aliases to resolve disparate column names automatically.
    E.g. BP's "Hydrocarbon Production Energy Consumption (TJ)" is matched to
    the internal key ``Upstream_Fuel_Consumption`` without any code change.

Every metric is read directly from the CSV alongside its source_citation and
source_url — fulfilling .cursorrules §2 and CFA Rule 4.6.

The AuditorAgent is deliberately non-neural — no generative inference, no
hallucination risk.
"""

import difflib
import json
import logging
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.audit_profile import (
    config_from_manifest,
    merge_auditor_config,
    merge_auditor_config_auto,
    try_dynamic_fuel_years,
)
from data_loader import (
    compute_resource_intensity_delta,
    compute_scope3_delta,
    get_disclosure_density,
    get_metric,
    load_audit_data,
)

_YELLOW = "\033[33m"
_GREEN  = "\033[32m"
_RED    = "\033[31m"
_RESET  = "\033[0m"
_BOLD   = "\033[1m"

logger = logging.getLogger("AUDITOR_AGENT")


# ── Company configuration registry ───────────────────────────────────────────
# Maps company identifiers to the exact metric names used in their respective
# CSV files and the years of relevant events (e.g. arbitrage relocation year).

# ── Schema mapping cache (loaded once) ───────────────────────────────────────
_MAPPING_PATH = Path(__file__).parent.parent / "config" / "mapping.json"
_SCHEMA_MAP: Optional[dict] = None


def _load_schema_mapping() -> dict:
    """
    Load ``config/mapping.json`` on first call and cache for the process lifetime.

    Returns the full mapping dict; returns empty dict gracefully if the file
    is missing (no crash — fuzzy matching then falls back to direct difflib only).

    Returns
    -------
    dict  Parsed mapping.json contents, or {} on failure.
    """
    global _SCHEMA_MAP
    if _SCHEMA_MAP is None:
        try:
            with open(_MAPPING_PATH, encoding="utf-8") as fh:
                _SCHEMA_MAP = json.load(fh)
            logger.debug("Loaded schema mapping from %s", _MAPPING_PATH)
        except (FileNotFoundError, json.JSONDecodeError) as exc:
            logger.warning("Schema mapping unavailable (%s) — fuzzy-only mode.", exc)
            _SCHEMA_MAP = {}
    return _SCHEMA_MAP


def _fuzzy_resolve_metric(
    available_names: List[str],
    target:          str,
    internal_key:    str = "",
    threshold:       float = 0.75,
) -> Optional[str]:
    """
    Resolve a target metric name to the closest match in ``available_names``.

    Resolution order:
      1. Exact string match (fastest path).
      2. Alias lookup via ``config/mapping.json`` for the given ``internal_key``.
      3. ``difflib.get_close_matches`` on all aliases vs available names.
      4. Direct ``difflib.get_close_matches`` on target vs available names.

    Parameters
    ----------
    available_names : List[str]  Metric names actually present in the CSV.
    target          : str        The metric name to resolve (may be an alias).
    internal_key    : str        MAD Protocol internal key (e.g. "Upstream_Fuel_Consumption").
    threshold       : float      Minimum similarity ratio for difflib (default 0.75).

    Returns
    -------
    Optional[str]  The matched CSV metric name, or None if no match found.
    """
    # Step 1 — exact match
    if target in available_names:
        return target

    mapping   = _load_schema_mapping()
    metric_meta = mapping.get("metrics", {}).get(internal_key, {})
    aliases   = metric_meta.get("aliases", [])

    # Step 2 — exact alias match
    for alias in aliases:
        if alias in available_names:
            logger.debug(
                "  SCHEMA MATCH  '%s' → '%s'  via alias  [internal: %s]",
                target, alias, internal_key,
            )
            return alias

    # Step 3 — difflib fuzzy on aliases
    for alias in aliases:
        matches = difflib.get_close_matches(alias, available_names, n=1, cutoff=threshold)
        if matches:
            logger.debug(
                "  FUZZY MATCH   '%s' ≈ '%s'  (%.0f%% similarity)  [internal: %s]",
                alias, matches[0], threshold * 100, internal_key,
            )
            return matches[0]

    # Step 4 — direct difflib on the target itself
    matches = difflib.get_close_matches(target, available_names, n=1, cutoff=threshold - 0.10)
    if matches:
        logger.debug(
            "  DIRECT FUZZY  '%s' ≈ '%s'  [fallback]",
            target, matches[0],
        )
        return matches[0]

    return None


def _auto_detect_config(
    records:      List[Dict],
    company_name: str = "unknown",
) -> Dict[str, Any]:
    """
    Auto-detect COMPANY_CONFIG for a company not in the static registry.

    Uses ``config/mapping.json`` aliases + ``difflib`` to find the closest
    CSV column name for each required internal metric key. This allows the
    MAD Protocol to ingest any oil-major ESG CSV without code changes,
    demonstrating sector-wide scalability to CFA judges.

    Parameters
    ----------
    records      : List[Dict]  All records loaded from the company's CSV.
    company_name : str         Company identifier (for display/logging only).

    Returns
    -------
    Dict[str, Any]
        A COMPANY_CONFIG-compatible dict with resolved metric names.
    """
    available = list({r["metric"].strip() for r in records
                      if r.get("metric", "").strip().lower() != "narrative_sentiment"})
    mapping   = _load_schema_mapping()

    def resolve(internal_key: str, fallback: str) -> str:
        aliases = mapping.get("metrics", {}).get(internal_key, {}).get("aliases", [])
        # exact alias
        for a in aliases:
            if a in available:
                return a
        # fuzzy alias
        for a in aliases:
            m = difflib.get_close_matches(a, available, n=1, cutoff=0.75)
            if m:
                logger.debug(
                    "  AUTO-DETECT   '%s' → '%s'  [%s for %s]",
                    a, m[0], internal_key, company_name,
                )
                return m[0]
        return fallback

    # Detect jurisdictional arbitrage year from CSV (year where value == 1)
    arb_metric = resolve("Jurisdictional_Arbitrage", "Jurisdictional Arbitrage Flag")
    arb_year   = 2024
    for r in records:
        if r.get("metric", "").strip() == arb_metric:
            try:
                if float(r["value"]) == 1:
                    arb_year = int(r["year"])
                    break
            except (ValueError, KeyError):
                pass

    display_name = (
        company_name.replace("_", " ").title() + " (auto-detected)"
    )

    return {
        "display_name":  display_name,
        "fuel_metric":   resolve("Upstream_Fuel_Consumption",
                                 "Upstream Natural Gas Fuel Consumption"),
        "scope3_metric": resolve("Scope_3_Emissions",
                                 "Total Scope 3 GHG Emissions"),
        "esg_metric":    resolve("ESG_Disclosure_Score",
                                 "General ESG Disclosure Score"),
        "capex_metric":  resolve("Transition_Capex",
                                 "Transition Capex Contraction"),
        "arb_metric":    arb_metric,
        "arb_year":      arb_year,
        "fuel_years":    (2015, 2024),
        "_auto_detected": True,
    }


# ── Company configuration registry ───────────────────────────────────────────
# Static exact-match configs for known companies (zero fuzzy overhead).
# For unknown companies the AuditorAgent calls _auto_detect_config() at runtime.

COMPANY_CONFIG: Dict[str, Dict[str, Any]] = {
    "shell": {
        "display_name":  "Shell PLC (LSE: SHEL)",
        "fuel_metric":   "Total energy consumption",
        "scope3_metric": "Total Scope 3 GHG Emissions",
        "esg_metric":    "General ESG Disclosure Score",
        "capex_metric":  "Transition Capex Contraction",
        "arb_metric":    "Jurisdictional Arbitrage Flag",
        "arb_year":      2024,
        "fuel_years":    (2015, 2024),
    },
    "orsted": {
        "display_name":  "Ørsted A/S (CPH: ORSTED)",
        "fuel_metric":   "Total energy consumption",
        "scope3_metric": "Total Scope 3 GHG Emissions",
        "esg_metric":    "General ESG Disclosure Score",
        "capex_metric":  "Transition Capex Growth",
        "arb_metric":    "Jurisdictional Arbitrage Flag",
        "arb_year":      2024,
        "fuel_years":    (2015, 2024),
    },
    # ── New sector companies (exact metric names from their CSVs) ─────────────
    "bp": {
        "display_name":  "BP plc (LSE: BP.L)",
        "fuel_metric":   "Total energy consumption",
        "scope3_metric": "Total Scope 3 GHG Footprint",
        "esg_metric":    "ESG Performance Score",
        "capex_metric":  "Green Capital Allocation Share (%)",
        "arb_metric":    "Regulatory Jurisdiction Flag",
        "arb_year":      2024,
        "fuel_years":    (2015, 2024),
    },
    "totalenergies": {
        "display_name":  "TotalEnergies SE (PARIS: TTE)",
        "fuel_metric":   "Total energy consumption",
        "scope3_metric": "Total Scope 3 GHG Emissions",
        "esg_metric":    "Sustainability Disclosure Score",
        "capex_metric":  "Renewables Investment Growth (%)",
        "arb_metric":    "Jurisdictional Arbitrage Flag",
        "arb_year":      2024,
        "fuel_years":    (2015, 2024),
    },
}


def _metric_plan(cfg: Dict[str, Any]) -> List[Tuple[str, int]]:
    """Ordered (metric_name, year) pairs for the fiduciary traceability matrix."""
    base_yr, curr_yr = cfg["fuel_years"]
    esg_y = int(cfg.get("esg_year", 2024))
    cap_y = int(cfg.get("capex_year", 2024))
    arb_y = int(cfg.get("arb_year", 2024))
    return [
        (cfg["fuel_metric"],   base_yr),
        (cfg["fuel_metric"],   curr_yr),
        (cfg["scope3_metric"], base_yr),
        (cfg["scope3_metric"], curr_yr),
        (cfg["esg_metric"],    esg_y),
        (cfg["capex_metric"],  cap_y),
        (cfg["arb_metric"],    arb_y),
    ]


def _abbrev_metric(name: str, max_len: int = 36) -> str:
    n = (name or "").strip()
    if len(n) <= max_len:
        return n
    return n[: max_len - 1] + "…"


_CANONICAL_FIELDNAMES = (
    "metric", "value", "unit", "year", "source_citation", "source_url",
)


def _excel_col_letter(i1: int) -> str:
    """1-based column index to Excel-style letter(s) (1→A, 2→B, …)."""
    if i1 < 1:
        return "?"
    letters = ""
    n = i1
    while n:
        n, r = divmod(n - 1, 26)
        letters = chr(65 + r) + letters
    return letters


def _value_column_index(fieldnames: Tuple[str, ...]) -> int:
    """1-based index of the ``value`` column header in the CSV."""
    for i, name in enumerate(fieldnames):
        if name == "value":
            return i + 1
    for i, name in enumerate(fieldnames):
        if (name or "").lower() == "value":
            return i + 1
    try:
        return _CANONICAL_FIELDNAMES.index("value") + 1
    except ValueError:
        return 2


def _traceability_location_text(rec: Dict[str, Any]) -> "Text":
    """
    File basename (line 1) and numeric Row/Column for the observed ``value`` cell (line 2).

    Row matches physical CSV line (header = 1); Column is 1-based index of ``value`` in headers.
    """
    from rich.text import Text

    row_ix = rec.get("_csv_row_index", "?")
    base = rec.get("_csv_source_basename") or "audit.csv"
    fnames = rec.get("_csv_fieldnames")
    if not isinstance(fnames, tuple):
        fnames = _CANONICAL_FIELDNAMES
    col_i = _value_column_index(fnames)
    loc = Text()
    loc.append(f"{base}\n", style="dim")
    loc.append(f"Row: {row_ix}  Column: {col_i}", style="bold cyan")
    return loc


_CITATION_PAGE_PREFIX = re.compile(
    r"^(.+?,\s*p\.\d+)(.*)$",
    flags=re.DOTALL,
)


def _citation_cell_text(raw: str) -> "Text":
    """
    Full citation with optional bold prefix through ``…, p.<n>`` for quick scanning.
    """
    from rich.text import Text

    s = (raw or "").strip().replace("\n", " ")
    if len(s) > 2000:
        s = s[:1999] + "…"
    m = _CITATION_PAGE_PREFIX.match(s)
    if m:
        t = Text()
        t.append(m.group(1), style="bold")
        t.append(m.group(2), style="dim")
        return t
    return Text(s, style="dim")


def build_traceability_matrix(
    records: List[Dict[str, Any]],
    cfg: Dict[str, Any],
) -> Any:
    """
    Rich ``Table`` mapping each ingested metric to its CSV file plus numeric
    Row/Column for the ``value`` field, and full public citations (CFA Rule 4.6
    glass-box terminal view). Location example: basename then ``Row: 2  Column: 2``.
    """
    from rich import box
    from rich.table import Table
    from rich.text import Text

    t = Table(
        title="🔍 Data Provenance & Traceability Matrix",
        title_style="bold cyan",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
        padding=(0, 1),
        expand=True,
    )
    t.add_column("Metric", style="white", max_width=36, no_wrap=False, ratio=2)
    t.add_column("Year", justify="center", style="white", ratio=1)
    t.add_column(
        "Value",
        style="yellow",
        max_width=40,
        overflow="fold",
        no_wrap=False,
        ratio=2,
    )
    t.add_column(
        "Location",
        overflow="fold",
        no_wrap=False,
        ratio=3,
    )
    t.add_column("Source Citation", overflow="fold", no_wrap=False, ratio=3)

    for metric_name, year in _metric_plan(cfg):
        try:
            rec = get_metric(records, metric_name, year)
        except KeyError:
            t.add_row(
                _abbrev_metric(metric_name),
                str(year),
                Text("—", style="red"),
                Text("—", style="dim red"),
                Text("ROW NOT FOUND", style="red"),
            )
            continue
        loc = _traceability_location_text(rec)
        raw_val = f"{rec.get('value', '')} {rec.get('unit', '')}".strip()
        cite = _citation_cell_text(rec.get("source_citation", ""))
        t.add_row(
            _abbrev_metric(metric_name),
            str(year),
            raw_val or "—",
            loc,
            cite,
        )
    return t


def run(
    company_name: str = "shell",
    preloaded_records: Optional[List[Dict[str, Any]]] = None,
) -> dict:
    """
    Execute the AuditorAgent for the specified company.

    Loads the company's public audit CSV, logs all key metrics with full
    source provenance, and computes the four derived quantities required
    by the ScepticAgent's I_d formula.

    Parameters
    ----------
    company_name : str
        Company identifier ("shell" or "orsted"). Default: "shell".

    Returns
    -------
    dict
        Keys:
        ``company_name``           — str,
        ``display_name``           — str,
        ``delta_resource_intensity`` — float (negative for genuine reducers),
        ``disclosure_density``     — float (ESG score / 100),
        ``delta_scope3_pct``       — float (% change in Scope 3),
        ``transition_capex_val``   — float (capex metric value),
        ``jurisdictional_arbitrage`` — int (0 = compliant, 1 = relocated),
        ``raw_records``            — list (full CSV rows for ScepticAgent).

    Raises
    ------
    KeyError
        If no CSV metrics can be resolved for the company.
    """
    from rich.console import Console

    if preloaded_records is not None:
        records_early = preloaded_records
    else:
        records_early = load_audit_data(company_name=company_name)

    mf = config_from_manifest(company_name, records_early)
    if mf is not None:
        logger.debug("MANIFEST METRICS  Company '%s' — using manifest output_metrics.", company_name)
        cfg = merge_auditor_config(company_name, mf)
    elif company_name in COMPANY_CONFIG:
        cfg = merge_auditor_config(company_name, dict(COMPANY_CONFIG[company_name]))
    else:
        logger.debug(
            "AUTO-DETECT  Company '%s' not in static registry — fuzzy schema resolution.",
            company_name,
        )
        cfg = _auto_detect_config(records_early, company_name=company_name)
        cfg = merge_auditor_config_auto(company_name, cfg)

    dyn_years = try_dynamic_fuel_years(company_name, records_early)
    if dyn_years is not None:
        cfg["fuel_years"] = dyn_years
        logger.info(
            "DYNAMIC IOD  %s — fuel_years from CSV: %s→%s",
            company_name,
            dyn_years[0],
            dyn_years[1],
        )

    display = cfg["display_name"]
    base_yr, curr_yr = cfg["fuel_years"]

    records = records_early  # already loaded above (used for auto-detect)

    Console().print(build_traceability_matrix(records, cfg))

    # ── Compute derived quantities ────────────────────────────────────────────
    delta_resource = compute_resource_intensity_delta(
        records,
        fuel_metric=cfg["fuel_metric"],
        base_year=base_yr,
        current_year=curr_yr,
    )
    disclosure_dens = get_disclosure_density(
        records,
        esg_metric=cfg["esg_metric"],
        esg_year=int(cfg.get("esg_year", 2024)),
    )
    delta_scope3    = compute_scope3_delta(
        records,
        scope3_metric=cfg["scope3_metric"],
        base_year=base_yr,
        current_year=curr_yr,
    )

    # ── Extract scalar flags ──────────────────────────────────────────────────
    capex_yr = int(cfg.get("capex_year", 2024))
    try:
        capex_rec = get_metric(records, cfg["capex_metric"], capex_yr)
        capex_val = float(capex_rec["value"])
    except KeyError:
        capex_val = 0.0

    try:
        arb_rec  = get_metric(records, cfg["arb_metric"], cfg["arb_year"])
        arb_flag = int(float(arb_rec["value"]))
    except KeyError:
        arb_flag = 0

    # ── Jurisdictional arbitrage — compact line (detail lives in matrix row) ─
    _cons = Console()
    if arb_flag == 1:
        _cons.print(
            "[bold yellow]⚠ Jurisdictional Arbitrage flag = 1 — verify CSV row + "
            "Companies House / corporate filing in Source Citation column.[/bold yellow]"
        )
    else:
        _cons.print(
            f"[dim green]✓ Jurisdictional Arbitrage flag = 0  ({display}, arb year "
            f"{cfg['arb_year']})[/dim green]"
        )

    return {
        "company_name":             company_name,
        "display_name":             display,
        "event_study":              cfg.get("event_study") or {},
        "delta_resource_intensity": delta_resource,
        "disclosure_density":       disclosure_dens,
        "delta_scope3_pct":         delta_scope3,
        "transition_capex_val":     capex_val,
        "jurisdictional_arbitrage": arb_flag,
        "raw_records":              records,
        "iod_baseline_year":        base_yr,
        "iod_current_year":         curr_yr,
        # Expose config for downstream use (sceptic_agent cross-checks)
        "capex_metric":             cfg["capex_metric"],
        "fuel_metric":              cfg["fuel_metric"],
        "scope3_metric":            cfg["scope3_metric"],
    }
