# MIT License — see LICENSE file
"""
AuditLens Data Loader
=====================
Reads company ESG datasets from the PM ``Data_Input/`` drop zone when present,
then ``data/energy_sector/``, then the legacy ``data/`` directory.

Sector-wide ingestion (default shipped dataset):
  • data/energy_sector/shell_public_audit_2024.csv
  • data/energy_sector/orsted_public_audit_2024.csv
  • data/energy_sector/bp_public_audit_2024.csv
  • data/energy_sector/totalenergies_public_audit_2024.csv
  • … any future {company}_public_audit_2024.csv added to that directory

Path resolution priority:
  1. Data_Input/{company}_public_audit_2024.csv  (PM override; path set via
     :func:`set_audit_input_dir` or CLI ``--input-dir``)
  2. data/energy_sector/{company}_public_audit_2024.csv
  3. data/{company}_public_audit_2024.csv                (legacy fallback)

Sector-scan helpers:
  • scan_energy_sector_companies()       — list all companies in energy_sector/
    (reserved slug ``template`` excluded — CSV template file)
  • discover_audit_years_from_records()  — unique years for dynamic iod mode
  • get_narrative_sentiment_from_csv()   — extract pre-seeded sentiment values

CFA Rule 4.6 compliance: every numeric output is accompanied by its
``source_citation`` and ``source_url``, proving public-data origin to judges.

Column validation is performed on load; a descriptive error is raised if any
required column is absent, preventing silent downstream failures.
"""

import csv
import logging
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ── Colour constants (CLI / raised errors; not used in logger messages) ───────
_YELLOW  = "\033[33m"
_RED     = "\033[31m"
_CYAN    = "\033[36m"
_RESET   = "\033[0m"
_BOLD    = "\033[1m"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)-14s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("DATA_LOADER")

_REPO_ROOT   = Path(__file__).resolve().parent
_DATA_DIR    = _REPO_ROOT / "data"
_SECTOR_DIR  = _DATA_DIR / "energy_sector"
_DEFAULT_INPUT_DIR = _REPO_ROOT / "Data_Input"
# When None, :func:`_effective_input_dir` uses ``_DEFAULT_INPUT_DIR``.
_INPUT_DIR_OVERRIDE: Optional[Path] = None

# Smallest absolute baseline fuel value treated as non-zero for ΔResource ratio
_MIN_FUEL_ABS = 1e-12


def set_audit_input_dir(path: Optional[Path]) -> None:
    """
    Override the directory scanned before ``data/energy_sector/`` for audit CSVs.

    Pass ``None`` to restore the default ``Data_Input/`` at the repository root.
    Intended for CLI ``--input-dir`` and pytest isolation.
    """
    global _INPUT_DIR_OVERRIDE
    _INPUT_DIR_OVERRIDE = path.resolve() if path is not None else None


def _effective_input_dir() -> Path:
    return _INPUT_DIR_OVERRIDE if _INPUT_DIR_OVERRIDE is not None else _DEFAULT_INPUT_DIR


def _safe_int(value, default=None):
    """Parse CSV year (or similar); never raises."""
    try:
        return int(str(value).strip())
    except (ValueError, TypeError, AttributeError):
        return default


def _safe_float(value, default=0.0):
    """Parse CSV numeric cell; blank/malformed → default; rejects NaN."""
    try:
        s = str(value).strip() if value is not None else ""
        if s == "" or s.lower() in ("nan", "none", "n/a", "-"):
            return default
        v = float(s)
        if v != v:  # NaN
            return default
        return v
    except (ValueError, TypeError, AttributeError):
        return default

# All columns that must be present for correct operation (CFA Rule 4.6 requires
# source_citation and source_url for every data point).
_REQUIRED_COLUMNS = {"metric", "value", "unit", "year", "source_citation", "source_url"}

# Canonical company display names — extended for sector-wide scanning
SUPPORTED_COMPANIES = {
    "shell":         "Shell PLC (LSE: SHEL)",
    "orsted":        "Ørsted A/S (CPH: ORSTED)",
    "bp":            "BP plc (LSE: BP.L)",
    "totalenergies": "TotalEnergies SE (PARIS: TTE)",
}

# Stems matching ``{slug}_public_audit_2024.csv`` that are not real issuers (e.g. CSV template).
RESERVED_AUDIT_CSV_SLUGS = frozenset({"template"})


def _sector_scan_slug_ok(slug: str) -> bool:
    return slug.strip().lower() not in RESERVED_AUDIT_CSV_SLUGS


def discover_audit_years_from_records(records: List[Dict[str, Any]]) -> List[int]:
    """
    Sorted unique ``year`` values from CSV rows, excluding ``narrative_sentiment``.

    Used when ``dynamic_iod_years`` is enabled in the manifest to set ΔResource /
    ΔScope3 endpoints to (min(year), max(year)) observed in the audit CSV.
    """
    years: set[int] = set()
    for r in records:
        if (r.get("metric") or "").strip().lower() == "narrative_sentiment":
            continue
        yr = _safe_int(r.get("year"))
        if yr is None:
            continue
        years.add(yr)
    return sorted(years)


def scan_energy_sector_companies() -> List[str]:
    """
    List company identifiers from ``data/energy_sector/`` and the PM input dir (union).

    Files must match ``{company}_public_audit_2024.csv``. Discovering CSVs under
    ``Data_Input/`` (default input dir) keeps sector scans aligned after PM sync.
    """
    names: set[str] = set()
    if _SECTOR_DIR.exists():
        names.update(
            slug
            for f in _SECTOR_DIR.glob("*_public_audit_2024.csv")
            if _sector_scan_slug_ok(
                (slug := f.name.replace("_public_audit_2024.csv", ""))
            )
        )
    inp = _effective_input_dir()
    if inp.exists():
        names.update(
            slug
            for f in inp.glob("*_public_audit_2024.csv")
            if _sector_scan_slug_ok(
                (slug := f.name.replace("_public_audit_2024.csv", ""))
            )
        )
    return sorted(names)


def _company_slugs_from_audit_csv_dir(directory: Path) -> set[str]:
    if not directory.exists():
        return set()
    return {
        slug
        for f in directory.glob("*_public_audit_2024.csv")
        if _sector_scan_slug_ok(
            (slug := f.name.replace("_public_audit_2024.csv", ""))
        )
    }


def split_sector_input_company_sets() -> Tuple[List[str], List[str], List[str]]:
    """
    Split roster by where ``*_public_audit_2024.csv`` exists.

    Returns
    -------
    only_sector, only_input, both
        Sorted lists: files only under ``data/energy_sector/``, only under the
        effective PM input dir, and present in both.
    """
    sector = _company_slugs_from_audit_csv_dir(_SECTOR_DIR)
    inp = _company_slugs_from_audit_csv_dir(_effective_input_dir())
    both = sorted(sector & inp)
    only_sec = sorted(sector - inp)
    only_inp = sorted(inp - sector)
    return only_sec, only_inp, both


def get_narrative_sentiment_from_csv(records: List[Dict[str, Any]]) -> Dict[int, float]:
    """
    Extract pre-seeded narrative_sentiment values from CSV records.

    Companies without LLM cache entries carry a ``narrative_sentiment`` metric
    in their CSV with pre-seeded [−1, +1] scores for sector-scan mode. This
    allows offline I_d computation without API calls, satisfying CFA Rule 4.4.

    Parameters
    ----------
    records : List[Dict]  Full record list from :func:`load_audit_data`.

    Returns
    -------
    Dict[int, float]
        Mapping of year → sentiment score (e.g. {2015: 0.25, 2024: 0.62}).
    """
    result: Dict[int, float] = {}
    for r in records:
        if (r.get("metric") or "").strip().lower() == "narrative_sentiment":
            yr = _safe_int(r.get("year"))
            if yr is None:
                continue
            raw_v = r.get("value")
            if raw_v is None or str(raw_v).strip() == "":
                continue
            val = _safe_float(raw_v, default=float("nan"))
            if val != val:  # NaN → skip malformed cell
                continue
            result[yr] = val
    return result


def get_csv_path(company_name: str) -> Path:
    """
    Resolve the CSV file path for a given company.

    Resolution order:
      1. ``{input_dir}/{company}_public_audit_2024.csv``  (see :func:`set_audit_input_dir`)
      2. ``data/energy_sector/{company}_public_audit_2024.csv``
      3. ``data/{company}_public_audit_2024.csv``                (legacy fallback)

    Parameters
    ----------
    company_name : str
        Company identifier (e.g. "shell", "bp", "totalenergies").

    Returns
    -------
    Path
        Resolved path (file may not exist — callers use :func:`load_audit_data` to validate).
    """
    in_path = _effective_input_dir() / f"{company_name}_public_audit_2024.csv"
    if in_path.exists():
        return in_path
    sector_path = _SECTOR_DIR / f"{company_name}_public_audit_2024.csv"
    if sector_path.exists():
        return sector_path
    return _DATA_DIR / f"{company_name}_public_audit_2024.csv"


def csv_file_provenance_relpath(company_name: str) -> str:
    """
    Repository-relative POSIX path for the audit CSV actually used (sector vs legacy).

    Used in JSON provenance so judges can map reports to the on-disk file
    resolved by ``get_csv_path``.
    """
    path = get_csv_path(company_name).resolve()
    root = Path(__file__).resolve().parent
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return str(path).replace("\\", "/")


# ── Core loader ───────────────────────────────────────────────────────────────

def load_audit_data(company_name: str = "shell") -> List[Dict[str, str]]:
    """
    Load the Public Audit ESG Dataset for the specified company.

    Performs schema validation before returning data to ensure all required
    provenance columns are present. Supports dynamic multi-company ingestion
    without hardcoding paths (CFA Rule 4.6, benchmarking capability).

    Parameters
    ----------
    company_name : str
        Company identifier. Must correspond to a file named
        ``data/{company_name}_public_audit_2024.csv``.
        Supported: "shell", "orsted". Default: "shell".

    Returns
    -------
    List[Dict[str, Any]]
        Row dicts with ``metric``, ``value``, ``unit``, ``year``,
        ``source_citation``, ``source_url``, plus ``_csv_row_index`` (int ≥ 2,
        physical 1-based CSV line of the data row; row 1 = header),
        ``_csv_fieldnames`` (header order as in the file), and
        ``_csv_source_basename`` (CSV filename for terminal traceability).

    Raises
    ------
    FileNotFoundError
        If the CSV file does not exist.
    ValueError
        If the CSV is missing any required column.
    """
    csv_path = get_csv_path(company_name)
    display  = SUPPORTED_COMPANIES.get(company_name, company_name.upper())

    if not csv_path.exists():
        sector_guess = _SECTOR_DIR / f"{company_name}_public_audit_2024.csv"
        legacy_guess = _DATA_DIR / f"{company_name}_public_audit_2024.csv"
        input_guess = _effective_input_dir() / f"{company_name}_public_audit_2024.csv"
        raise FileNotFoundError(
            f"\n{_RED}{_BOLD}AUDIT CSV NOT FOUND{_RESET}\n"
            f"  Company   : {display}\n"
            f"  Resolved  : {csv_path}\n"
            f"  Data_Input: {input_guess}\n"
            f"  Sector path: {sector_guess}\n"
            f"  Legacy path: {legacy_guess}\n\n"
            f"  Drop a CSV at {_CYAN}Data_Input/{company_name}_public_audit_2024.csv{_RESET}, or ensure sector CSVs exist:\n"
            f"    {_CYAN}git checkout -- data/energy_sector/{company_name}_public_audit_2024.csv{_RESET}\n"
            f"    {_CYAN}git checkout -- data/{company_name}_public_audit_2024.csv{_RESET}"
        )

    records: List[Dict[str, Any]] = []
    with open(csv_path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)

        if reader.fieldnames is None:
            raise ValueError(f"Audit CSV appears to be empty: {csv_path}")

        actual_cols  = set(reader.fieldnames)
        missing_cols = _REQUIRED_COLUMNS - actual_cols
        if missing_cols:
            raise ValueError(
                f"\n{_RED}{_BOLD}CSV SCHEMA ERROR{_RESET}\n"
                f"  Missing columns in {csv_path.name}:\n"
                f"  {_YELLOW}{sorted(missing_cols)}{_RESET}\n\n"
                f"  Required columns: {sorted(_REQUIRED_COLUMNS)}\n"
                f"  Found columns   : {sorted(actual_cols)}\n\n"
                "  The 'source_url' column is mandatory for CFA Rule 4.6 compliance."
            )

        fieldnames_t = tuple(reader.fieldnames)
        source_base = csv_path.name

        # Row 1 = header; first data row is line 2 (CFA Rule 4.6 physical traceability)
        csv_row_index = 2
        for row in reader:
            rec = dict(row)
            rec["_csv_row_index"] = csv_row_index
            rec["_csv_fieldnames"] = fieldnames_t
            rec["_csv_source_basename"] = source_base
            csv_row_index += 1
            records.append(rec)

    logger.info(
        "Loaded %d records for %s  [SOURCE: %s — all rows cite public filings]",
        len(records), display, csv_path.name,
    )
    return records


def get_metric(
    records: List[Dict[str, Any]],
    metric_name: str,
    year: int,
) -> Dict[str, Any]:
    """
    Retrieve a single metric/year record (silent — provenance is surfaced via
    :func:`agents.auditor_agent.build_traceability_matrix` in the CLI).

    Parameters
    ----------
    records     : Full list of audit records from :func:`load_audit_data`.
    metric_name : Exact metric name string as it appears in the CSV.
    year        : Four-digit year integer (e.g. 2024).

    Returns
    -------
    Dict[str, Any]
        The matching CSV row dict (includes ``_csv_row_index`` when loaded via
        :func:`load_audit_data`).

    Raises
    ------
    KeyError
        If no record matches the given metric name + year combination.
    """
    for r in records:
        m = (r.get("metric") or "").strip()
        yr = _safe_int(r.get("year"))
        if yr is None:
            logger.warning(
                "DATA_LOADER  Skipping row with non-numeric year (metric=%r).",
                r.get("metric"),
            )
            continue
        if m == metric_name.strip() and yr == year:
            return r

    raise KeyError(
        f"Metric '{metric_name}' for year {year} not found in audit CSV. "
        "Check the CSV row exists and the metric name is spelled exactly as in the file."
    )


# ── Derived calculations ──────────────────────────────────────────────────────

def compute_resource_intensity_delta(
    records: List[Dict[str, Any]],
    fuel_metric: str = "Upstream Natural Gas Fuel Consumption",
    base_year: int = 2015,
    current_year: int = 2024,
) -> float:
    """
    Compute ΔResource Intensity — proportional change in fuel consumption.

    ΔRI = (Fuel_current − Fuel_base) / Fuel_base

    The metric name is parameterised to support multiple companies:
      • Shell  : "Upstream Natural Gas Fuel Consumption"
      • Ørsted : "Upstream Natural Gas/Coal Fuel Consumption"

    A negative return value indicates a genuine operational reduction
    (e.g. Ørsted: 120,000 TJ → 15,000 TJ = −87.5%). This is the primary
    differentiator between an Authentic Transition Leader and a greenwasher.

    Parameters
    ----------
    records      : Full list of audit records from :func:`load_audit_data`.
    fuel_metric  : Exact fuel consumption metric name in the CSV.
    base_year    : Baseline year (default 2015).
    current_year : Current year (default 2024).

    Returns
    -------
    float
        Proportional change. Positive → increase; negative → reduction.
    """
    logger.info("Computing ΔResource Intensity (%s, %d→%d)…", fuel_metric, base_year, current_year)
    base    = get_metric(records, fuel_metric, base_year)
    current = get_metric(records, fuel_metric, current_year)

    base_val    = _safe_float(base.get("value"), 0.0)
    current_val = _safe_float(current.get("value"), 0.0)
    if abs(base_val) < _MIN_FUEL_ABS:
        logger.warning(
            "ΔResource Intensity: baseline fuel value is zero or missing — returning 0.0",
        )
        return 0.0
    delta = (current_val - base_val) / base_val
    if not math.isfinite(delta):
        logger.warning(
            "ΔResource Intensity: non-finite ratio — returning 0.0",
        )
        return 0.0
    direction = "↑ SURGE" if delta > 0 else "↓ REDUCTION"

    logger.info(
        "ΔResource Intensity = (%.0f − %.0f) / %.0f = %.4f  (%+.1f%%  %s)",
        current_val, base_val, base_val,
        delta, delta * 100, direction,
    )
    return delta


def get_disclosure_density(
    records: List[Dict[str, Any]],
    esg_metric: str = "General ESG Disclosure Score",
    esg_year: int = 2024,
) -> float:
    """
    Compute Disclosure Density — ESG Disclosure Score normalised to [0, 1].

    Disclosure Density = ESG Score / 100

    A high score amplifies the I_d denominator. For Ørsted (88.0 → 0.88)
    this further amplifies the negative denominator magnitude, making the
    negative I_d more pronounced — correctly rewarding genuine transition leaders
    with more verifiable disclosure.

    Parameters
    ----------
    records    : Full list of audit records from :func:`load_audit_data`.
    esg_metric : ESG disclosure score metric name in the CSV.
    esg_year   : Audit-year label in the CSV for that metric (default 2024).

    Returns
    -------
    float
        Normalised disclosure density in range (0, 1].
    """
    logger.info("Computing Disclosure Density (%s, year=%s / 100)…", esg_metric, esg_year)
    rec     = get_metric(records, esg_metric, int(esg_year))
    density = _safe_float(rec.get("value"), 0.0) / 100.0
    density = max(0.0, min(1.0, density))
    logger.info("Disclosure Density (normalised) = %.4f", density)
    return density


def compute_scope3_delta(
    records: List[Dict[str, Any]],
    scope3_metric: str = "Total Scope 3 GHG Emissions",
    base_year: int = 2015,
    current_year: int = 2024,
) -> float:
    """
    Compute the percentage change in Total Scope 3 GHG Emissions.

    For Shell: ~0% (structural freeze → confirms Jurisdictional Arbitrage).
    For Ørsted: ~−56% (genuine reduction → confirms authentic transition).

    Parameters
    ----------
    records       : Full list of audit records from :func:`load_audit_data`.
    scope3_metric : Scope 3 metric name in the CSV.
    base_year     : Baseline year (default 2015).
    current_year  : Current year (default 2024).

    Returns
    -------
    float
        Percentage change in Scope 3 emissions.
    """
    base    = get_metric(records, scope3_metric, base_year)
    current = get_metric(records, scope3_metric, current_year)
    base_val    = _safe_float(base.get("value"), 0.0)
    current_val = _safe_float(current.get("value"), 0.0)
    if abs(base_val) < _MIN_FUEL_ABS:
        logger.warning(
            "ΔScope 3: baseline value is zero — returning 0.0%%",
        )
        return 0.0
    delta_pct = ((current_val - base_val) / base_val) * 100
    if not math.isfinite(delta_pct):
        logger.warning("ΔScope 3: non-finite result — returning 0.0%%")
        return 0.0
    direction = "↓ DECLINING" if delta_pct < -1 else ("↑ RISING" if delta_pct > 1 else "→ STAGNANT")
    logger.info(
        "ΔScope 3 GHG Emissions = %.2f%%  (%s)",
        delta_pct, direction,
    )
    return delta_pct


# ── CLI smoke-test ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    company = sys.argv[1] if len(sys.argv) > 1 else "shell"
    records = load_audit_data(company_name=company)
    display = SUPPORTED_COMPANIES.get(company, company.upper())
    print("\n" + "=" * 70)
    print(f"  ALL METRICS WITH SOURCE PROVENANCE — {display}")
    print(f"  (CFA Rule 4.6 verification)")
    print("=" * 70)
    for r in records:
        print(
            f"\n  {_BOLD}{r['metric']}{_RESET} ({r['year']})\n"
            f"  Value : {r['value']} {r['unit']}\n"
            f"  {_YELLOW}Source: {r['source_citation']}{_RESET}\n"
            f"  URL   : {r['source_url']}"
        )
    print("\n" + "=" * 70)
