# MIT License — see LICENSE file
"""
AuditLens LLM Wrapper
=====================
Provides a caching layer around multi-provider LLM API calls so judges can
reproduce all results at zero cost using the ``--use-cached`` flag.

Dual-Model Consensus Protocol (Responsible AI / CFA Stage 3):
  • Supports OpenAI (gpt-4o-mini) AND Anthropic (claude-3-5-sonnet-20241022).
  • Both models' responses are cached under distinct SHA-256 keys.
  • The ``provider`` parameter routes calls to the correct vendor API.
  • Anthropic gracefully degrades to OpenAI-only if package/key unavailable.

CFA Rule 4.4 compliance:
  • Cached responses are stored in data/api_cache.json (committed to repo).
  • --use-cached mode reads from cache; no API key, no cost, no network call.
  • Cache key = SHA-256(model|temperature|prompt) — deterministic, collision-free.
  • Each cache entry records model name, provider, temperature, prompt preview,
    and the full response text for auditor inspection.

Approved models (CFA Rule 4.3):
  • OpenAI  : gpt-4o-mini (default)
  • Anthropic: claude-3-5-sonnet-20241022  (Dual-Model Bias Guard)
  • Open-source models via compatible API (llama, mistral, qwen, etc.)

Error handling guarantees:
  • Corrupt api_cache.json → warning + auto-backup + empty cache (no crash).
  • Missing OPENAI_API_KEY or ANTHROPIC_API_KEY → coloured advisory.
  • Anthropic package not installed → graceful fallback to OpenAI-only mode.
  • Cache miss in --use-cached mode → RuntimeError with judge-readable guidance.
"""

import hashlib
import json
import logging
import os
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

_GREEN   = "\033[32m"
_YELLOW  = "\033[33m"
_RED     = "\033[31m"
_CYAN    = "\033[36m"
_RESET   = "\033[0m"
_BOLD    = "\033[1m"

logger = logging.getLogger("LLM_WRAPPER")

CACHE_PATH = Path(__file__).parent / "data" / "api_cache.json"

# Default model — gpt-4o-mini is ~$0.00015/1K input tokens.
# A full AuditLens run (2 prompts × ~800 tokens) costs < $0.001,
# far below the CFA Rule 4.4 $20 reproducibility threshold.
DEFAULT_MODEL       = "gpt-4o-mini"
DEFAULT_TEMPERATURE = 0.0   # temperature=0.0 for fully deterministic, reproducible outputs

# Anthropic model for Dual-Model Consensus Protocol (CFA Rule 4.3 — approved)
ANTHROPIC_MODEL = "claude-3-5-sonnet-20241022"


def _year_suffix_from_label(label: str) -> str:
    """Extract a 4-digit year from the end of a cache label, if present."""
    if not label:
        return ""
    m = re.search(r"_(\d{4})$", label.strip())
    return m.group(1) if m else ""


def _append_llm_event(
    llm_events: Optional[List[dict]],
    *,
    status: str,
    label: str,
    provider: str,
    model: str,
    temperature: float,
    key: str,
) -> None:
    """Record one row for PM-style tabular terminal / CSV export."""
    if llm_events is None:
        return
    llm_events.append({
        "status":       status,
        "label":        label,
        "provider":     provider,
        "year":         _year_suffix_from_label(label),
        "model":        model,
        "temperature":  temperature,
        "key_prefix":   key[:12] if key else "",
    })


# XAI schema advisory — emitted when a cached entry predates the Glass-Box schema.
_XAI_ADVISORY_EMITTED: set = set()   # Tracks labels to avoid duplicate advisories.


# ── Cache I/O ─────────────────────────────────────────────────────────────────

def _check_xai_schema(response_text: str, expected_fields: list, label: str) -> None:
    """
    Validate that a cached response contains the XAI Glass-Box schema fields.

    If the response is missing any expected field (legacy v1 schema), emits a
    rich-formatted advisory panel guiding judges on how to regenerate the cache
    with the Glass-Box (XAI v2) format. Does NOT raise — graceful degradation.

    Parameters
    ----------
    response_text   : Raw JSON string from the cache entry.
    expected_fields : List of JSON field names required in the Glass-Box schema.
    label           : Cache entry label (used for deduplication of advisories).
    """
    # Only emit advisory once per label per session to avoid log spam
    if label in _XAI_ADVISORY_EMITTED:
        return

    try:
        data    = json.loads(response_text)
        missing = [f for f in expected_fields if f not in data]
        if not missing:
            return  # Schema is valid — no advisory needed
    except (json.JSONDecodeError, AttributeError):
        return  # Not a JSON response — skip validation

    _XAI_ADVISORY_EMITTED.add(label)

    # Emit advisory using rich — inline import to avoid circular dependencies
    try:
        from rich.console import Console as _C
        from rich.panel import Panel as _P
        from rich.text import Text as _T

        advisory = _T()
        advisory.append("⚠  LEGACY CACHE SCHEMA DETECTED\n\n", style="bold yellow")
        advisory.append(
            f"  Cache entry [{label}] is missing Glass-Box XAI fields:\n",
            style="yellow",
        )
        for f in missing:
            advisory.append(f"    • {f}\n", style="bold yellow")
        advisory.append(
            "\n  The cached response was generated before the XAI v2 schema upgrade.\n"
            "  Linguistic phrase attribution (hedging + transition evidence) is unavailable\n"
            "  until the cache is regenerated with a live API call.\n",
            style="dim white",
        )
        advisory.append("\n  To enable full Glass-Box XAI output:\n", style="white")
        advisory.append(
            "    1. Delete data/api_cache.json\n"
            "    2. Run once with a live API key to regenerate:\n"
            "         python run_auditlens.py\n"
            "    3. Then resume zero-cost cached mode (CFA Rule 4.4):\n"
            "         python run_auditlens.py --use-cached\n",
            style="cyan",
        )
        _C().print(_P(
            advisory,
            title="[bold white on dark_orange]  ⚠  GLASS-BOX XAI — LEGACY CACHE  [/bold white on dark_orange]",
            border_style="yellow",
            padding=(0, 1),
        ))
    except ImportError:
        # Fallback if rich is somehow unavailable
        logger.warning(
            "Legacy cache schema detected for [%s]. Missing fields: %s. "
            "Delete data/api_cache.json and run in live mode to regenerate Glass-Box cache.",
            label, missing,
        )


def _load_cache() -> dict:
    """
    Load the API response cache from disk.

    Returns an empty dict if the cache file does not exist.
    If the file is corrupt (invalid JSON), emits a WARNING, backs up the
    corrupted file with a timestamp suffix, and returns an empty dict so
    the caller can continue without crashing.

    Returns
    -------
    dict
        Mapping of cache keys → response dicts.
    """
    if not CACHE_PATH.exists():
        return {}

    try:
        with open(CACHE_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
            if not isinstance(data, dict):
                logger.warning(
                    "WARNING  api_cache.json root is not an object — using empty cache.",
                )
                return {}
            return data
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        # Back up the corrupt file before wiping, so nothing is lost
        timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        backup = CACHE_PATH.with_suffix(f".corrupt_{timestamp}.json")
        shutil.copy2(CACHE_PATH, backup)
        logger.warning(
            "WARNING  data/api_cache.json is corrupt (%s).\n"
            "  Backed up to: %s\n"
            "  Starting with an empty cache. Re-run without --use-cached to rebuild.\n"
            "  Alternatively, restore from version control (git checkout data/api_cache.json).",
            exc, backup,
        )
        return {}
    except OSError as exc:
        logger.warning(
            "WARNING  Cannot read data/api_cache.json (%s). Using empty cache.",
            exc,
        )
        return {}


def _save_cache(cache: dict) -> None:
    """
    Persist the cache dict to disk as formatted JSON.

    Parameters
    ----------
    cache : dict
        Full cache contents to write.
    """
    try:
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(CACHE_PATH, "w", encoding="utf-8") as fh:
            json.dump(cache, fh, indent=2, ensure_ascii=False)
    except OSError as exc:
        logger.warning("WARNING  Could not write api_cache.json: %s", exc)


def _cache_key(prompt: str, model: str, temperature: float) -> str:
    """
    Compute a deterministic, collision-resistant cache key.

    The key is SHA-256(model|temperature|prompt), encoded as a 64-char hex
    string. Including temperature in the hash ensures that responses generated
    at different temperature settings are cached separately.

    Parameters
    ----------
    prompt      : Full prompt text sent to the model.
    model       : Model identifier string (e.g. "gpt-4o-mini").
    temperature : Sampling temperature used for the API call.

    Returns
    -------
    str
        64-character lowercase hex digest.
    """
    raw = f"{model}|{temperature}|{prompt}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# ── OPENAI_API_KEY pre-flight check ──────────────────────────────────────────

def _check_anthropic_key() -> None:
    """
    Verify that ANTHROPIC_API_KEY is set before attempting an Anthropic API call.

    Raises
    ------
    EnvironmentError
        With a coloured advisory if the environment variable is absent or empty.
    """
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key:
        raise EnvironmentError(
            f"\n{_RED}{_BOLD}MISSING ANTHROPIC API KEY{_RESET}\n"
            f"  {_YELLOW}ANTHROPIC_API_KEY is not set.{_RESET}\n\n"
            "  To run Dual-Model Consensus in LIVE mode:\n"
            f"    {_CYAN}export ANTHROPIC_API_KEY=\"sk-ant-...\"  # macOS/Linux{_RESET}\n\n"
            "  To run WITHOUT an Anthropic key (single-model OpenAI mode):\n"
            f"    The system gracefully falls back to OpenAI-only.\n"
            "  To run fully cached (zero API cost, recommended for judges):\n"
            f"    {_GREEN}python run_auditlens.py --use-cached{_RESET}"
        )


def _check_api_key() -> None:
    """
    Verify that OPENAI_API_KEY is set before attempting a live API call.

    Raises
    ------
    EnvironmentError
        With a coloured, judge-friendly message describing exactly how to fix it,
        if the environment variable is absent or empty.
    """
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        raise EnvironmentError(
            f"\n{_RED}{_BOLD}MISSING API KEY{_RESET}\n"
            f"  {_YELLOW}The OPENAI_API_KEY environment variable is not set.{_RESET}\n\n"
            "  To run in LIVE mode, export your key:\n"
            f"    {_CYAN}export OPENAI_API_KEY=\"sk-...\"  # macOS / Linux{_RESET}\n"
            f"    {_CYAN}set OPENAI_API_KEY=sk-...        # Windows cmd{_RESET}\n\n"
            "  To run WITHOUT an API key (recommended for judges):\n"
            f"    {_GREEN}python run_auditlens.py --use-cached{_RESET}\n"
            "  This uses pre-cached responses in data/api_cache.json.\n"
            "  No API key required. No cost incurred. (CFA Rule 4.4)"
        )


# ── Public API ────────────────────────────────────────────────────────────────

def _map_live_api_exception(exc: Exception, vendor: str) -> None:
    """
    Convert SDK/network failures into judge-readable errors (no raw trace to console).
    Re-raises as EnvironmentError (auth) or RuntimeError (network); otherwise returns
    to allow the original exception to propagate.
    """
    name = type(exc).__name__
    msg  = str(exc).lower()
    auth_tokens = ("auth", "401", "403", "api key", "incorrect api", "invalid_api", "permission denied")
    net_tokens  = (
        "connection", "timeout", "connect", "network", "unreachable", "reset", "refused",
        "temporary failure", "name or service not known", "ssl", "certificate",
    )
    if "Authentication" in name or "Permission" in name or any(t in msg for t in auth_tokens):
        raise EnvironmentError(
            f"\n{_RED}{_BOLD}{vendor} API authentication / permission error{_RESET}\n"
            f"  {type(exc).__name__}: {exc}\n\n"
            f"  {_GREEN}python run_auditlens.py --use-cached{_RESET}  "
            "(no key required; CFA Rule 4.4)"
        ) from None
    if any(t in name.lower() for t in ("connection", "timeout", "connect")) or any(
        t in msg for t in net_tokens
    ):
        raise RuntimeError(
            f"\n{_RED}{_BOLD}{vendor} API connection or timeout{_RESET}\n"
            f"  {type(exc).__name__}: {exc}\n\n"
            f"  {_GREEN}python run_auditlens.py --use-cached{_RESET}  "
            "(offline reproduction; no network)"
        ) from None


def _call_openai(prompt: str, model: str, temperature: float) -> str:
    """
    Execute a live OpenAI API call and return the response text.

    Parameters
    ----------
    prompt      : Full prompt text.
    model       : OpenAI model ID.
    temperature : Sampling temperature (0.0 = deterministic).

    Returns
    -------
    str  Response text from the model.
    """
    _check_api_key()
    try:
        from openai import OpenAI
    except ImportError:
        raise ImportError(
            f"\n{_RED}{_BOLD}MISSING PACKAGE{_RESET}\n"
            "  The 'openai' package is required for live OpenAI calls.\n"
            f"    {_CYAN}pip install openai{_RESET}\n"
            f"  Or: {_GREEN}python run_auditlens.py --use-cached{_RESET}"
        )
    client = OpenAI()
    try:
        completion = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
        )
        return completion.choices[0].message.content or ""
    except Exception as exc:
        _map_live_api_exception(exc, "OpenAI")
        raise


def _call_anthropic(prompt: str, model: str, temperature: float) -> str:
    """
    Execute a live Anthropic API call and return the response text.

    Used by the Dual-Model Consensus Protocol for Bias Guard validation.
    Requires the ``anthropic`` package and ``ANTHROPIC_API_KEY`` env var.

    Parameters
    ----------
    prompt      : Full prompt text.
    model       : Anthropic model ID (e.g. "claude-3-5-sonnet-20241022").
    temperature : Sampling temperature (0.0 = deterministic).

    Returns
    -------
    str  Response text from the model.
    """
    _check_anthropic_key()
    try:
        from anthropic import Anthropic
    except ImportError:
        raise ImportError(
            f"\n{_RED}{_BOLD}MISSING PACKAGE{_RESET}\n"
            "  The 'anthropic' package is required for Dual-Model Consensus.\n"
            f"    {_CYAN}pip install anthropic{_RESET}\n"
            "  Without it, AuditLens gracefully falls back to OpenAI-only mode.\n"
            f"  Or: {_GREEN}python run_auditlens.py --use-cached{_RESET}"
        )
    client = Anthropic()
    try:
        message = client.messages.create(
            model=model,
            max_tokens=600,
            temperature=temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        return message.content[0].text
    except Exception as exc:
        _map_live_api_exception(exc, "Anthropic")
        raise


def llm_call(
    prompt: str,
    model: str = DEFAULT_MODEL,
    provider: str = "openai",
    use_cached: bool = False,
    temperature: float = DEFAULT_TEMPERATURE,
    label: str = "",
    expected_fields: list = None,
    emit_llm_logs: bool = True,
    llm_events: Optional[List[dict]] = None,
) -> str:
    """
    Call an approved LLM (OpenAI or Anthropic) with transparent caching.

    Execution flow:
      1. Compute SHA-256 cache key from (model, temperature, prompt).
      2. If a matching entry exists in api_cache.json → return it (optional
         XAI schema validation; graceful degradation on legacy entries).
      3. If ``use_cached=True`` and no entry exists → raise RuntimeError.
      4. Otherwise perform a live API call via the specified ``provider``,
         write the response to cache, and return.

    Dual-Model Consensus support:
      Set ``provider="anthropic"`` and ``model=ANTHROPIC_MODEL`` to call
      claude-3-5-sonnet-20241022. The cache key includes the model name, so
      OpenAI and Anthropic responses are stored and retrieved independently.

    All calls use ``temperature=0.0`` (deterministic) for reproducibility.

    Parameters
    ----------
    prompt          : Full prompt text.
    model           : CFA-approved model ID (Rule 4.3).
    provider        : "openai" (default) or "anthropic".
    use_cached      : If True, return cached response only — zero API cost.
    temperature     : Sampling temperature. Default 0.0.
    label           : Human-readable label for log messages.
    expected_fields : Optional list of XAI schema fields for validation.
    emit_llm_logs   : If False, suppress CACHE HIT / API CALL info lines (tabular UI mode).
    llm_events      : If a list, append one row per cache hit / API call / cache write.

    Returns
    -------
    str  Model response text.

    Raises
    ------
    RuntimeError    : use_cached=True with cache miss.
    EnvironmentError: Missing API key in live mode.
    ImportError     : Missing provider SDK package.
    """
    cache = _load_cache()
    key   = _cache_key(prompt, model, temperature)
    tag   = f"[{label}] " if label else ""

    # ── Cache hit ─────────────────────────────────────────────────────────────
    if key in cache:
        entry = cache.get(key)
        if not isinstance(entry, dict) or "response" not in entry:
            logger.warning(
                "CACHE WARN  Malformed entry for key %.12s… — ignoring.",
                key,
            )
        else:
            _append_llm_event(
                llm_events,
                status="CACHE_HIT",
                label=label,
                provider=provider,
                model=str(entry.get("model", model)),
                temperature=float(entry.get("temperature", temperature)),
                key=key,
            )
            if emit_llm_logs:
                logger.info(
                    "CACHE HIT  %s(model=%s, temp=%.1f, key=%.12s…)",
                    tag,
                    entry.get("model", model), entry.get("temperature", temperature),
                    key,
                )
            if expected_fields:
                _check_xai_schema(entry["response"], expected_fields, label)
            return entry["response"]

    # ── Cache miss in --use-cached mode → hard fail with guidance ─────────────
    if use_cached:
        raise RuntimeError(
            f"\n{_RED}{_BOLD}CACHE MISS — --use-cached mode{_RESET}\n"
            f"  {_YELLOW}{tag}No cached response for key {key[:16]}…{_RESET}\n\n"
            "  The pre-populated data/api_cache.json should cover all standard\n"
            "  AuditLens prompts. This error usually means:\n"
            "    (a) data/api_cache.json was deleted or corrupted, or\n"
            "    (b) a new prompt was added without running a live update.\n\n"
            "  To fix:\n"
            f"    {_CYAN}git checkout data/api_cache.json{_RESET}   "
            "← restore from version control\n"
            "  OR run once in live mode to rebuild the cache:\n"
            f"    {_CYAN}python run_auditlens.py{_RESET}   "
            "(requires OPENAI_API_KEY)"
        )

    # ── Live API call ─────────────────────────────────────────────────────────
    _append_llm_event(
        llm_events,
        status="API_CALL",
        label=label,
        provider=provider,
        model=model,
        temperature=temperature,
        key=key,
    )
    if emit_llm_logs:
        logger.info(
            "API CALL  %s(provider=%s, model=%s, temp=%.1f, len=%d)",
            tag, provider, model, temperature, len(prompt),
        )

    if provider == "anthropic":
        response_text = _call_anthropic(prompt, model, temperature)
    else:
        response_text = _call_openai(prompt, model, temperature)

    # ── Write to cache ────────────────────────────────────────────────────────
    cache[key] = {
        "label":          label or "unlabelled",
        "model":          model,
        "temperature":    temperature,
        "prompt_preview": prompt[:300] + ("…" if len(prompt) > 300 else ""),
        "response":       response_text,
    }
    _save_cache(cache)
    _append_llm_event(
        llm_events,
        status="CACHE_WRITE",
        label=label,
        provider=provider,
        model=model,
        temperature=temperature,
        key=key,
    )
    logger.debug(
        "CACHED  Response saved → data/api_cache.json (key=%.12s…)",
        key,
    )

    return response_text
