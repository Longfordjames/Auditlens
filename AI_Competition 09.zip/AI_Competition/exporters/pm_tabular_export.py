# MIT License — see LICENSE file
"""
PM-facing tabular export (CSV) mirroring Rich “sheet” views for Excel workflows.
"""
from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence


def _safe_str(v: Any) -> str:
    if v is None:
        return ""
    return str(v).replace("\r\n", " ").replace("\n", " ").strip()


def write_pm_csv_bundle(
    report: Mapping[str, Any],
    output_dir: Path,
    *,
    llm_events: Optional[Sequence[Mapping[str, Any]]] = None,
) -> Dict[str, Path]:
    """
    Write CSV files next to the JSON report (open in Excel).

    Returns
    -------
    dict
        Map logical sheet name → written path.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    sys_info = report.get("system") or {}
    company = _safe_str(sys_info.get("company")) or "company"
    display = _safe_str(sys_info.get("display_name"))
    layers = report.get("layers") or {}
    corp = layers.get("corporate_agent") or {}
    aud = layers.get("auditor_agent") or {}
    scep = layers.get("sceptic_agent") or {}
    verdict = report.get("verdict") or {}
    val = report.get("valuation_analysis")

    written: Dict[str, Path] = {}

    # ── LLM trace (optional; same rows as terminal table) ─────────────────────
    if llm_events:
        p = output_dir / f"{company}_pm_sheet_llm_trace.csv"
        rows = [e for e in llm_events if e.get("status") in ("CACHE_HIT", "API_CALL")]
        with open(p, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(
                fh,
                fieldnames=["status", "provider", "year", "model", "temperature", "key_prefix", "label"],
                extrasaction="ignore",
            )
            w.writeheader()
            for e in rows:
                w.writerow({k: e.get(k, "") for k in w.fieldnames})
        written["llm_trace"] = p

    # ── Executive / I_d inputs ────────────────────────────────────────────────
    p = output_dir / f"{company}_pm_sheet_executive.csv"
    fi = scep.get("formula_inputs") or {}
    with open(p, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["field", "value"])
        w.writerow(["display_name", display])
        w.writerow(["integrity_discount_I_d", scep.get("integrity_discount", "")])
        w.writerow(["risk_level", scep.get("risk_level", "")])
        w.writerow(["risk_flag", scep.get("risk_flag", "")])
        w.writerow(["delta_narrative_sentiment", fi.get("delta_narrative_sentiment", "")])
        w.writerow(["delta_resource_intensity", fi.get("delta_resource_intensity", "")])
        w.writerow(["disclosure_density", fi.get("disclosure_density", "")])
        w.writerow(["denominator", fi.get("denominator", "")])
        w.writerow(["delta_scope3_pct", aud.get("delta_scope3_pct", "")])
        w.writerow(["jurisdictional_arbitrage", aud.get("jurisdictional_arbitrage", "")])
        w.writerow(["valuation_impact_bps", scep.get("valuation_impact_bps", "")])
        w.writerow(["implied_wacc_modifier", scep.get("implied_wacc_modifier", "")])
        w.writerow(["max_ai_variance", scep.get("max_ai_variance", corp.get("max_ai_variance", ""))])
        w.writerow(["high_ambiguity_flag", scep.get("high_ambiguity_flag", corp.get("high_ambiguity_flag", ""))])
        w.writerow(["dual_model_active", scep.get("dual_model_active", corp.get("dual_model_active", ""))])
    written["executive"] = p

    # ── Cross-checks ──────────────────────────────────────────────────────────
    p = output_dir / f"{company}_pm_sheet_cross_checks.csv"
    checks: List[Dict[str, Any]] = list(scep.get("cross_checks") or [])
    with open(p, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(
            fh,
            fieldnames=["rule", "triggered", "detail", "citation"],
            extrasaction="ignore",
        )
        w.writeheader()
        for c in checks:
            w.writerow({
                "rule":      _safe_str(c.get("rule")),
                "triggered": c.get("triggered", ""),
                "detail":    _safe_str(c.get("detail")),
                "citation":  _safe_str(c.get("citation")),
            })
    written["cross_checks"] = p

    # ── Dual-model by year ────────────────────────────────────────────────────
    p = output_dir / f"{company}_pm_sheet_dual_model.csv"
    years_rows: List[tuple] = [
        (2015, "score_openai_2015", "score_anthropic_2015", "ai_variance_2015"),
        (2021, "score_openai_2021", "score_anthropic_2021", "ai_variance_2021"),
        (2024, "score_openai_2024", "score_anthropic_2024", "ai_variance_2024"),
    ]
    with open(p, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["year", "openai", "anthropic", "variance"])
        for yr, ko, ka, kv in years_rows:
            if yr == 2021 and not corp.get("has_2021_node"):
                continue
            w.writerow([
                yr,
                corp.get(ko, ""),
                corp.get(ka, ""),
                corp.get(kv, ""),
            ])
    written["dual_model"] = p

    # ── Trajectory (if present) ────────────────────────────────────────────────
    traj = scep.get("trajectory") or {}
    if traj.get("available"):
        p = output_dir / f"{company}_pm_sheet_trajectory.csv"
        pairs = [
            ("event_label", traj.get("event_label")),
            ("inflection_flag", traj.get("inflection_flag")),
            ("sentiment_slope_pre_per_yr", traj.get("sentiment_slope_pre")),
            ("sentiment_slope_post_per_yr", traj.get("sentiment_slope_post")),
            ("resource_slope_pre_TJ_per_yr", traj.get("ri_slope_pre")),
            ("resource_slope_post_TJ_per_yr", traj.get("ri_slope_post")),
            ("event_driven_greenwashing", traj.get("event_driven_greenwashing")),
        ]
        with open(p, "w", newline="", encoding="utf-8") as fh:
            cw = csv.writer(fh)
            cw.writerow(["metric", "value"])
            for k, v in pairs:
                cw.writerow([k, v])
        written["trajectory"] = p

    # ── WACC / valuation action ───────────────────────────────────────────────
    p = output_dir / f"{company}_pm_sheet_wacc.csv"
    with open(p, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["field", "value"])
        w.writerow(["valuation_impact_bps", scep.get("valuation_impact_bps", "")])
        w.writerow(["implied_wacc_modifier", scep.get("implied_wacc_modifier", "")])
        w.writerow(["valuation_action", _safe_str(scep.get("valuation_action"))])
        if val:
            w.writerow(["illustrative_base_wacc_pct", val.get("base_wacc_pct", "")])
            w.writerow(["illustrative_adjusted_wacc_pct", val.get("adjusted_wacc_pct", "")])
            w.writerow(["illustrative_valuation_haircut_pct", val.get("haircut_pct", "")])
    written["wacc"] = p

    return written
