# MIT License — see LICENSE file
"""Tests for exporters/html_generator.py — sensitivity matrix and tear sheet render."""

import json
from pathlib import Path

import pytest


def test_build_wacc_integrity_sensitivity_matrix_shape_and_monotonic():
    from exporters.html_generator import build_wacc_integrity_sensitivity_matrix

    m = build_wacc_integrity_sensitivity_matrix("shell", 0.3, 0.08)
    assert m is not None
    assert len(m["rows"]) == 5
    assert all(len(r) == 5 for r in m["rows"])
    assert len(m["integrity_labels"]) == 5
    assert len(m["wacc_labels"]) == 5
    for row in m["rows"]:
        for cell in row:
            assert "haircut_pct" in cell
            assert "heat_idx" in cell
            assert 0 <= cell["heat_idx"] <= 4
    # Higher integrity at fixed WACC should not increase haircut vs lower (broadly)
    col0 = [m["rows"][i][2]["haircut_pct"] for i in range(5)]
    assert col0[-1] <= col0[0] + 1e-6


def test_generate_tear_sheet_writes_html(tmp_path: Path) -> None:
    from exporters.html_generator import generate_tear_sheet

    report_path = Path(__file__).resolve().parent.parent / "data" / "shell_auditlens_report.json"
    if not report_path.exists():
        pytest.skip("fixture report missing")
    report = json.loads(report_path.read_text(encoding="utf-8"))
    out = tmp_path / "shell_test.html"
    generate_tear_sheet(report, "shell", out)
    text = out.read_text(encoding="utf-8")
    assert "glance-strip" in text and "cockpit-nav" in text
    assert "heatmap-grid" in text
    assert "divergence-block" in text or "divergence-caption" in text
    assert "logic-flow" in text
