# MIT License — see LICENSE file
"""
ScepticAgent — Layer 3 (Symbolic Constraint / Deterministic Gatekeeper)
========================================================================
Computes the Integrity Discount (I_d) and issues a risk classification.
Supports multi-company benchmarking with mathematically correct handling of
both positive and negative ΔResource Intensity. An optional Neuro-Symbolic
Reflection step may call CorporateAgent once when symbolic contradiction
triggers fire (see ``run(..., enable_neuro_symbolic_reflection=True)``).

Formula (cursorrules §4, strictly enforced):
        ΔNarrative Sentiment
  I_d = ─────────────────────────────────────────
        ΔResource Intensity × Disclosure Density

CRITICAL MATHEMATICAL PROPERTY — Negative Denominator Handling
───────────────────────────────────────────────────────────────
When ΔResource < 0 (genuine operational reduction, e.g. Ørsted −87.5%):
  • Denominator = negative × positive = NEGATIVE
  • If ΔSentiment > 0: I_d = positive / negative = NEGATIVE I_d
  • A NEGATIVE I_d is the mathematical proof of authentic alignment:
    narrative optimism is inversely proportional to the (improving) resource
    intensity. The negative sign is NOT an error — it is the signal.

When ΔResource > 0 (operational deterioration, e.g. Shell +964.6%):
  • Denominator = positive × positive = POSITIVE
  • If ΔSentiment > 0: I_d = positive / positive = POSITIVE I_d
  • A POSITIVE I_d signals narrative inflation relative to operational reality.

Risk Classification Map (five-tier):
  I_d < 0  AND  ΔResource < 0  AND  ΔSentiment > 0
      → AUTHENTIC TRANSITION LEADER  (LOW)
        Narrative and capital both aligned with genuine decarbonisation.

  I_d ≥ 0  AND  ΔResource < 0
      → TRANSITION UNDERSTATEMENT  (LOW)
        Management narratives are conservative relative to operational gains.

  I_d > OBFUSCATION_THRESHOLD (0.10)  AND  ΔResource > 0
      → HIGH-RISK STRATEGIC OBFUSCATION  (HIGH)
        Narrative inflation disproportionate to operational deterioration.

  0 ≤ I_d ≤ OBFUSCATION_THRESHOLD  AND  ΔResource > 0
      → MODERATE OBFUSCATION RISK  (MEDIUM)
        (Jurisdictional Arbitrage escalator may promote to HIGH)

  ΔSentiment ≤ 0  AND  ΔResource > 0
      → CONSERVATIVE SIGNALLING  (LOW)

Denominator scaling note:
  With Shell (ΔResource ≈ +9.65, DD = 0.74): denominator ≈ +7.14
    → I_d ∈ [−0.14, +0.14]; OBFUSCATION_THRESHOLD = 0.10
  With Ørsted (ΔResource ≈ −0.875, DD = 0.88): denominator ≈ −0.77
    → I_d ∈ [−1.3, +1.3]; negative I_d confirms authentic leadership
  Thresholds are applied after checking the sign of ΔResource.
  If |ΔResource × DD| < 1e-9, a sign-preserving ε-denominator is applied
  (logged) so the pipeline never divides by zero.

Design principles:
  • Core I_d and cross-checks are deterministic Python — no LLM inside the formula.
  • Optional Neuro-Symbolic Reflection (disabled by default) may call CorporateAgent
    once when symbolic rules detect narrative–operations contradiction; the final
    I_d still uses only public excerpts and cached LLM output (Rule 4.4).
  • Hallucinations cannot bypass the symbolic gate: reflection is triggered only
    by audited CSV metrics.
  • Cross-checks are direction-aware: negative ΔResource triggers positive
    validation checks; positive ΔResource triggers obfuscation checks.
  • Every risk flag is bi-directionally anchored to a specific CSV row.
"""

import logging
import math
import sys
from pathlib import Path
from typing import Dict, List, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent))

logger = logging.getLogger("SCEPTIC_AGENT")

# ── Classification thresholds ─────────────────────────────────────────────────
# Applied only in the ΔResource > 0 (deterioration) branch.
# Calibrated for Shell's constrained I_d range ≈ [−0.14, +0.14].
OBFUSCATION_THRESHOLD  = 0.10
CONSERVATIVE_THRESHOLD = 0.0

# Jurisdictional Arbitrage escalator (ΔResource > 0 branch only)
JURISDICTION_ESCALATION = True

# Minimum |ΔResource × DD| treated as non-zero (avoids mistaking float noise for a signal).
_ID_DENOM_EPSILON = 1e-9

# When ΔResource×DD vanishes, substitute a denominator with magnitude at least
# max(_ID_DENOM_EPSILON, |ΔSentiment| / _I_D_MAGNITUDE_CAP) so |I_d| stays O(1)
# (avoids 0.62 / 1e-9 style blow-ups when CSV fuel is flat across iod endpoints).
_I_D_MAGNITUDE_CAP = 5.0

# ── WACC / Pricing Impact Constants ──────────────────────────────────────────
# Basis-point adjustments applied to the discount rate for DCF asset pricing.
# These translate the I_d risk classification into actionable buy-side signals.
#
# Rationale:
#   HIGH-RISK base (+100 bps): Illustrative ESG stranded-asset risk loading
#     consistent with public TCFD-style climate risk disclosure guidance
#     (task-force recommendations; no proprietary vendor data).
#   Jurisdictional Arbitrage escalation (+50 bps): Reflects the unpriced
#     regulatory tail-risk created by Shell's EU→UK Scope 3 liability shift.
#     A mandatory 45% absolute carbon reduction (Milieudefensie ruling) became
#     a voluntary investor-relations commitment, creating asymmetric litigation
#     and regulatory re-exposure risk that markets have not yet fully priced.
#   AUTHENTIC TRANSITION LEADER discount (-50 bps): Reflects quantified
#     reduction in stranded-asset and regulatory tail-risk for firms with
#     verified, irreversible capital reallocation away from fossil fuels.
WACC_BASE_OBFUSCATION_BPS = 100   # Base ESG risk premium for HIGH-RISK flag
WACC_ARB_ESCALATION_BPS   = 50    # Incremental bps for Jurisdictional Arbitrage
WACC_MODERATE_BPS         = 50    # ESG review premium for MODERATE OBFUSCATION
WACC_GREEN_PREMIUM_BPS    = -50   # Green premium for AUTHENTIC TRANSITION LEADER
WACC_NEUTRAL_BPS          = 0     # No adjustment for CONSERVATIVE/ALIGNED flags
# Hard bounds on emitted WACC signal (bps) — contains corrupt / fuzzed inputs
WACC_IMPACT_BPS_MIN       = -200
WACC_IMPACT_BPS_MAX       = 200


def _finite_float(x, default: float = 0.0) -> float:
    """Coerce to float; NaN/Inf and bad types → default (never raises)."""
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def _degenerate_id_denominator_magnitude(delta_sentiment: float) -> float:
    """Minimum |substitute denominator| when ΔResource×DD is degenerate."""
    ds = abs(_finite_float(delta_sentiment, 0.0))
    if ds <= 0.0:
        return 1.0
    return max(1e-6, ds / _I_D_MAGNITUDE_CAP)


def _effective_id_denominator(
    denominator_raw: float,
    delta_resource: float,
    delta_sentiment: float,
) -> Tuple[float, bool]:
    """
    Map a possibly vanishing denominator to a stable divisor for I_d.

    Returns
    -------
    Tuple[float, bool]
        (effective_denominator, epsilon_guard). When guard is True, a
        sign-preserving substitute is used with magnitude at least
        ``max(_ID_DENOM_EPSILON, |ΔSentiment|/_I_D_MAGNITUDE_CAP)`` (or 1.0 when
        ΔSentiment is zero) so quotients stay finite and order-one.
    """
    if abs(denominator_raw) >= _ID_DENOM_EPSILON:
        return denominator_raw, False

    mag = max(_ID_DENOM_EPSILON, _degenerate_id_denominator_magnitude(delta_sentiment))

    if denominator_raw != 0.0:
        return math.copysign(mag, denominator_raw), True
    if abs(delta_resource) > _ID_DENOM_EPSILON:
        return math.copysign(mag, delta_resource), True
    return mag, True


def effective_id_denominator(
    delta_resource: float,
    disclosure_density: float,
    delta_sentiment: float,
) -> Tuple[float, float, bool]:
    """
    Public helper for sector-scan and tooling: stable I_d denominator triple.

    Returns
    -------
    Tuple[float, float, bool]
        (effective_denominator, raw_product, epsilon_guard).
    """
    dr = _finite_float(delta_resource, 0.0)
    dd = _finite_float(disclosure_density, 0.74)
    ds = _finite_float(delta_sentiment, 0.0)
    raw = dr * dd
    eff, guard = _effective_id_denominator(raw, dr, ds)
    return eff, raw, guard


def run(
    corporate_output: dict,
    auditor_output: dict,
    *,
    use_cached: bool = False,
    enable_neuro_symbolic_reflection: bool = False,
) -> dict:
    """
    Execute the ScepticAgent — deterministic I_d calculation and risk flagging.

    Handles both positive ΔResource (obfuscation detection) and negative
    ΔResource (authentic transition validation) with mathematically correct
    denominator sign handling.

    When ``enable_neuro_symbolic_reflection`` is True and audited ΔResource Intensity
    exceeds +50%% (ratio > 0.5) while initial ΔNarrative Sentiment is above +0.2,
    the CorporateAgent reflection pass may re-score the 2024 narrative under
    professional skepticism; ``integrity_discount`` and risk tier use the
    skepticism-adjusted ΔSentiment.

    Denominator sign logic:
        denominator = ΔResource × Disclosure Density
        If ΔResource < 0 → denominator < 0 → I_d = ΔSentiment / negative
        A positive ΔSentiment with negative denominator yields I_d < 0,
        which is the mathematically correct signal for authentic transition
        leadership (narrative aligns with genuine improvement).

    Parameters
    ----------
    corporate_output : dict
        Output from CorporateAgent. Must contain ``delta_narrative_sentiment``.
    auditor_output : dict
        Output from AuditorAgent. Must contain ``delta_resource_intensity``,
        ``disclosure_density``, ``jurisdictional_arbitrage``,
        ``delta_scope3_pct``, ``transition_capex_val``, ``raw_records``.
    use_cached : bool
        Forwarded to the reflection LLM call (Rule 4.4).
    enable_neuro_symbolic_reflection : bool
        If True, allow one closed-loop reflection when contradiction triggers fire.

    Returns
    -------
    dict
        Keys: ``integrity_discount``, ``risk_flag``, ``risk_level``,
        ``explanation``, ``formula_inputs``, ``cross_checks``,
        ``neuro_symbolic_reflection``.

    Notes
    -----
    If |ΔResource × DD| is degenerate, a substitute denominator is applied
    (sign-preserving, scaled by |ΔSentiment|) so |I_d| stays bounded; see
    ``denominator_epsilon_guard`` and ``_I_D_MAGNITUDE_CAP``.
    """
    company   = auditor_output.get("display_name", "Unknown")
    logger.debug(
        "SCEPTIC AGENT — I_d calculation for %s "
        "(symbolic formula; optional neuro-symbolic reflection)",
        company,
    )

    delta_sentiment_initial = _finite_float(
        corporate_output.get("delta_narrative_sentiment"), 0.0,
    )
    delta_sentiment = delta_sentiment_initial
    delta_resource  = _finite_float(auditor_output.get("delta_resource_intensity"), 0.0)
    disclosure_dens = _finite_float(auditor_output.get("disclosure_density"), 0.74)
    try:
        arb_flag = int(float(auditor_output.get("jurisdictional_arbitrage", 0)))
        arb_flag = 1 if arb_flag else 0
    except (TypeError, ValueError):
        arb_flag = 0

    sent_24_raw = corporate_output.get("sentiment_2024")
    sentiment_2024_initial = (
        _finite_float(sent_24_raw, 0.0) if sent_24_raw is not None else None
    )

    neuro_symbolic_reflection = {
        "triggered": False,
        "initial_sentiment_2024": sentiment_2024_initial,
        "reflective_sentiment_score": None,
        "initial_delta_narrative_sentiment": delta_sentiment_initial,
        "reflective_delta_narrative_sentiment": None,
        "delta_ri_pct_display": f"{delta_resource * 100:+.1f}%",
        "initial_integrity_discount": None,
        "cognitive_dissonance_analysis": "",
        "cache_label": "",
    }

    denominator_raw = delta_resource * disclosure_dens
    denominator, epsilon_guard = _effective_id_denominator(
        denominator_raw, delta_resource, delta_sentiment,
    )
    if epsilon_guard:
        logger.warning(
            "I_d DENOMINATOR SAFEGUARD  [%s] |ΔResource×DD|=%.3e — "
            "using effective denominator %+.3e (|ΔSent|-scaled floor; glass-box).",
            company,
            abs(denominator_raw),
            denominator,
        )

    integrity_discount = round(delta_sentiment / denominator, 6)
    if not math.isfinite(integrity_discount):
        logger.warning(
            "I_d non-finite after division — coercing to 0.0 (check CSV inputs).",
        )
        integrity_discount = 0.0

    neuro_symbolic_reflection["initial_integrity_discount"] = integrity_discount

    # ── Neuro-Symbolic Reflection (symbolic trigger → neural re-read) ─────────
    cn = corporate_output.get("company_name")
    if (
        enable_neuro_symbolic_reflection
        and sentiment_2024_initial is not None
        and delta_resource > 0.5
        and delta_sentiment_initial > 0.2
        and isinstance(cn, str)
    ):
        from agents.corporate_agent import COMPANY_NARRATIVES, run_reflection_pass

        if cn in COMPANY_NARRATIVES:
            excerpts = COMPANY_NARRATIVES[cn]["excerpts_2024"]
            id_before = integrity_discount
            try:
                refl = run_reflection_pass(
                    initial_score=sentiment_2024_initial,
                    delta_ri=delta_resource,
                    excerpts=excerpts,
                    company_name=cn,
                    use_cached=use_cached,
                    emit_llm_logs=False,
                )
                rs = _finite_float(
                    refl.get("reflective_sentiment_score"),
                    sentiment_2024_initial,
                )
                s2015 = _finite_float(corporate_output.get("sentiment_2015"), 0.0)
                delta_sentiment = round(rs - s2015, 6)
                denominator, epsilon_guard = _effective_id_denominator(
                    denominator_raw, delta_resource, delta_sentiment,
                )
                integrity_discount = round(delta_sentiment / denominator, 6)
                if not math.isfinite(integrity_discount):
                    integrity_discount = 0.0
                neuro_symbolic_reflection.update({
                    "triggered": True,
                    "reflective_sentiment_score": rs,
                    "reflective_delta_narrative_sentiment": delta_sentiment,
                    "cognitive_dissonance_analysis": str(
                        refl.get("cognitive_dissonance_analysis", ""),
                    ),
                    "cache_label": str(refl.get("cache_label", "")),
                })
                logger.debug(
                    "NEURO-SYMBOLIC REFLECTION  [%s]  "
                    "2024 narrative %+.4f → reflective %+.4f  |  "
                    "ΔSent %+.4f → %+.4f  |  I_d %+.6f → %+.6f",
                    company,
                    sentiment_2024_initial, rs,
                    delta_sentiment_initial, delta_sentiment,
                    id_before, integrity_discount,
                )
            except Exception as exc:
                logger.warning(
                    "Reflection loop skipped [%s]: %s",
                    company, exc,
                )

    # Determine denominator character for log commentary
    denom_sign = "NEGATIVE (authentic reduction)" if denominator < 0 else "POSITIVE (resource surge)"
    id_sign    = "NEGATIVE → authentic alignment" if integrity_discount < 0 else "POSITIVE → narrative inflation"

    raw_note = f"  [raw product = {denominator_raw:+.6e}]" if epsilon_guard else ""
    logger.debug(
        "I_d FORMULA  [%s]\n"
        "  ΔNarrative Sentiment   = %+.6f  [Public filings 2015 & 2024]\n"
        "  ΔResource Intensity    = %+.6f  [Fuel TJ change 2015→2024]\n"
        "  Disclosure Density     =  %.6f  [ESG Score / 100]\n"
        "  Denominator (effective) = %+.6f  (%s)%s\n"
        "  I_d = %+.6f  (%s)",
        company,
        delta_sentiment,
        delta_resource,
        disclosure_dens,
        denominator, denom_sign, raw_note,
        integrity_discount, id_sign,
    )

    # ── Risk classification ────────────────────────────────────────────────────
    risk_flag, risk_level, classification_reason = _classify(
        integrity_discount, delta_sentiment, delta_resource, arb_flag, company,
    )

    # ── Direction-aware cross-checks ──────────────────────────────────────────
    cross_checks = _run_cross_checks(auditor_output)

    eps_note = (
        f" [ε-guard: raw denom {denominator_raw:+.3e} → effective {denominator:+.3e}]"
        if epsilon_guard else ""
    )
    refl_note = ""
    if neuro_symbolic_reflection["triggered"]:
        refl_note = (
            " | Professional skepticism re-evaluation applied "
            f"(cache: {neuro_symbolic_reflection.get('cache_label', '')})."
        )
    explanation = (
        f"I_d = {integrity_discount:+.4f} | "
        f"ΔSentiment={delta_sentiment:+.4f} / "
        f"(ΔResource={delta_resource:+.4f} × DD={disclosure_dens:.4f}) = "
        f"denominator {denominator:+.4f}.{eps_note} "
        f"{classification_reason}{refl_note}"
    )

    logger.debug(
        "RISK VERDICT  [%s]\n"
        "  Flag  : %s\n"
        "  Level : %s\n"
        "  %s",
        company,
        risk_flag,
        risk_level, explanation,
    )

    for chk in cross_checks:
        icon = "⚠" if chk["triggered"] else "✓"
        logger.debug(
            "  CROSS-CHECK %-38s → %s %s  %s",
            chk["rule"],
            icon, "TRIGGERED" if chk["triggered"] else "PASS",
            chk["citation"],
        )

    # ── Dual-Model Bias Variance Matrix ───────────────────────────────────────
    max_variance   = float(corporate_output.get("max_ai_variance", 0.0))
    high_ambiguity = bool(corporate_output.get("high_ambiguity_flag", False))
    dual_active    = bool(corporate_output.get("dual_model_active", False))

    if dual_active:
        bias_note = (
            "[HIGH AI AMBIGUITY / BIAS WARNING] — conservative score applied"
            if high_ambiguity else "LOW VARIANCE — consensus robust"
        )
        logger.debug(
            "BIAS VARIANCE MATRIX  [%s]\n"
            "  OpenAI  2024: %+.4f | Anthropic 2024: %+.4f | Variance: %.4f\n"
            "  Max Variance Across All Nodes: %.4f  %s",
            company,
            corporate_output.get("score_openai_2024", 0),
            corporate_output.get("score_anthropic_2024", 0),
            corporate_output.get("ai_variance_2024", 0),
            max_variance,
            bias_note,
        )
    else:
        logger.debug(
            "BIAS GUARD  [%s] Single-model mode (OpenAI). "
            "Add ANTHROPIC_API_KEY for full dual-model consensus.",
            company,
        )

    # ── Temporal Trajectory Analysis ──────────────────────────────────────────
    trajectory = _compute_trajectory(corporate_output, auditor_output)

    if trajectory["available"]:
        ri_pre_fmt  = f"{trajectory['ri_slope_pre']:+.0f}"
        ri_post_fmt = f"{trajectory['ri_slope_post']:+.0f}"
        logger.debug(
            "TEMPORAL TRAJECTORY  [%s]\n"
            "  Sentiment  2015→2021 slope: %+.4f/yr | 2021→2024 slope: %+.4f/yr\n"
            "  Resource   2015→2021 slope: %s TJ/yr | 2021→2024 slope: %s TJ/yr\n"
            "  Inflection Flag: %s",
            company,
            trajectory["sentiment_slope_pre"], trajectory["sentiment_slope_post"],
            ri_pre_fmt, ri_post_fmt,
            trajectory["inflection_flag"],
        )

    # ── Financial Alpha Translation ────────────────────────────────────────────
    valuation = _compute_wacc_impact(risk_flag, cross_checks)
    bps    = valuation["valuation_impact_bps"]
    bps_sign = f"+{bps}" if bps > 0 else str(bps)
    logger.debug(
        "WACC PRICING IMPACT  [%s]\n"
        "  WACC Adjustment    : %s bps  (implied modifier: %+.4f)\n"
        "  Valuation Action   : %s",
        company,
        bps_sign,
        valuation["implied_wacc_modifier"],
        valuation["valuation_action"],
    )

    return {
        "integrity_discount":   integrity_discount,
        "risk_flag":            risk_flag,
        "risk_level":           risk_level,
        "explanation":          explanation,
        "formula_inputs": {
            "delta_narrative_sentiment": delta_sentiment,
            "delta_resource_intensity":  delta_resource,
            "disclosure_density":        disclosure_dens,
            "denominator":               denominator,
            "denominator_raw":           denominator_raw,
            "denominator_epsilon_guard": epsilon_guard,
        },
        "denominator_epsilon_guard": epsilon_guard,
        "cross_checks":         cross_checks,
        # ── Financial Alpha Fields ─────────────────────────────────────────────
        "valuation_impact_bps":  valuation["valuation_impact_bps"],
        "implied_wacc_modifier": valuation["implied_wacc_modifier"],
        "valuation_action":      valuation["valuation_action"],
        # ── Temporal Trajectory Fields ─────────────────────────────────────────
        "trajectory":            trajectory,
        # ── Dual-Model Bias Guard Fields ───────────────────────────────────────
        "max_ai_variance":       max_variance,
        "high_ambiguity_flag":   high_ambiguity,
        "dual_model_active":     dual_active,
        "neuro_symbolic_reflection": neuro_symbolic_reflection,
    }


# ── Internal helpers ──────────────────────────────────────────────────────────

def compute_sensitivity(
    consensus_sentiment_2024: float,
    sentiment_2015: float,
    resource_2015: float,
    resource_2024: float,
    disclosure_density: float,
    arb_flag: int,
) -> dict:
    """
    Fiduciary Margin of Safety — Stepwise Perturbation Engine.

    Answers: "How much must Shell reduce upstream gas consumption to exit
    HIGH-RISK classification and neutralise its WACC penalty?"

    Methodology:
      • Vary resource_2024 from current value to near-zero in steps.
      • At each scenario: recompute ΔRI, I_d, risk classification, and WACC.
      • Analytically identify the tipping-point gas level where the risk
        classification changes (ΔRI flips from positive to negative).
      • With arb_flag = 1 (Shell's jurisdictional relocation), the absolute
        minimum achievable WACC is +50 bps (arb creates a structural floor).
        Only reversal of the jurisdictional relocation can eliminate this floor.

    Parameters
    ----------
    consensus_sentiment_2024 : float  Conservative consensus 2024 sentiment.
    sentiment_2015           : float  Baseline 2015 sentiment.
    resource_2015            : float  Baseline fuel consumption (TJ).
    resource_2024            : float  Current fuel consumption (TJ).
    disclosure_density       : float  ESG score / 100.
    arb_flag                 : int    Jurisdictional Arbitrage flag (0 or 1).

    Returns
    -------
    dict
        ``scenarios`` (list) — per-step WACC outcomes,
        ``tipping_point`` (dict) — analytically computed threshold,
        ``margin_of_safety_pct`` (float) — required reduction percentage.
    """
    delta_sentiment = consensus_sentiment_2024 - sentiment_2015

    # Stepwise reduction schedule (percentage of current resource_2024)
    reduction_steps = [0, 10, 25, 50, 75, 85, 90, 91, 95]
    scenarios = []

    for pct_red in reduction_steps:
        new_gas   = resource_2024 * (1.0 - pct_red / 100.0)
        delta_ri  = (new_gas - resource_2015) / resource_2015 if resource_2015 > 0 else 0.0
        denom     = delta_ri * disclosure_density

        if abs(denom) < 1e-9:
            scenarios.append({
                "pct_reduction": pct_red,
                "gas_mtj":       round(new_gas / 1e6, 2),
                "delta_ri_pct":  round(delta_ri * 100, 1),
                "id":            None,
                "wacc_bps":      None,
                "risk_flag":     "UNDEFINED (ΔRI ≈ 0 → denominator = 0)",
                "is_tipping":    True,
            })
            continue

        id_val     = round(delta_sentiment / denom, 4)
        if not math.isfinite(id_val):
            id_val = 0.0
        # Minimal arb cross-check stub for WACC computation
        mock_checks = [{"triggered": arb_flag == 1,
                        "rule": "Jurisdictional Arbitrage (UK relocation 2022)"}]
        risk_flag, _, _ = _classify(id_val, delta_sentiment, delta_ri, arb_flag)
        wacc_info  = _compute_wacc_impact(risk_flag, mock_checks)

        scenarios.append({
            "pct_reduction": pct_red,
            "gas_mtj":       round(new_gas / 1e6, 2),
            "delta_ri_pct":  round(delta_ri * 100, 1),
            "id":            id_val,
            "wacc_bps":      wacc_info["valuation_impact_bps"],
            "risk_flag":     risk_flag,
            "is_tipping":    False,
        })

    # ── Analytical tipping-point computation ──────────────────────────────────
    # ΔRI = 0 when gas_2024 = gas_2015 — this is the structural breakeven.
    # With arb_flag = 1, WACC never reaches 0 or -50 bps operationally.
    tipping_gas_tj  = resource_2015
    margin_of_safety = round((resource_2024 - resource_2015) / resource_2024 * 100, 1)
    best_achievable = -50  # AUTHENTIC TRANSITION LEADER branch does not escalate via arb

    structural_note = (
        "Once upstream gas drops below the 2015 baseline (ΔRI < 0), the "
        "AUTHENTIC TRANSITION LEADER classification applies — this branch does NOT "
        "receive Jurisdictional Arbitrage escalation (design: authentic operational "
        "transition is rewarded regardless of regulatory address). "
        f"The -50 bps Green Premium is therefore achievable with a {margin_of_safety}% "
        "gas reduction. However, investors should note that the UK relocation represents "
        "a separate qualitative governance risk not fully captured by the I_d formula alone."
    ) if arb_flag == 1 else (
        "No Jurisdictional Arbitrage — full -50 bps green premium achievable "
        "once ΔRI < 0 (Authentic Transition Leader classification)."
    )

    return {
        "scenarios":            scenarios,
        "margin_of_safety_pct": margin_of_safety,
        "tipping_gas_mtj":      round(tipping_gas_tj / 1e6, 3),
        "current_gas_mtj":      round(resource_2024 / 1e6, 3),
        "baseline_gas_mtj":     round(resource_2015 / 1e6, 3),
        "best_achievable_bps":  best_achievable,
        "structural_note":      structural_note,
        "delta_sentiment_used": round(delta_sentiment, 4),
        "disclosure_density":   disclosure_density,
        "arb_flag":             arb_flag,
    }


def _compute_trajectory(corporate_output: dict, auditor_output: dict) -> dict:
    """
    Compute pre/post 2021 event slopes for Narrative Sentiment and Resource Intensity.

    Implements the Time-Series Event Study with the 2021 Dutch Court Ruling
    (Milieudefensie et al. v. Royal Dutch Shell) as the critical inflection point.

    Slope calculation:
      Pre-event  (2015→2021, 6 years): gradual/baseline trajectory
      Post-event (2021→2024, 3 years): post-ruling / post-relocation trajectory

    Inflection Flag — "TEXTBOOK EVENT-DRIVEN GREENWASHING" is raised when ALL
    three conditions are simultaneously satisfied:
      1. Post-2021 Sentiment Slope   > Pre-2021 Sentiment Slope   (narrative accelerates)
      2. Post-2021 Resource Slope    > Pre-2021 Resource Slope    (resource surge accelerates)
      3. Jurisdictional Arbitrage flag = 1 (legal context confirms regulatory motive)

    This combination proves that Shell's legal repositioning (UK relocation)
    precisely coincides with a decoupling between narrative inflation and
    operational fossil-fuel input acceleration.

    Parameters
    ----------
    corporate_output : dict  Must contain sentiment_2015, sentiment_2021 (optional), sentiment_2024.
    auditor_output   : dict  Must contain raw_records (for 2021 fuel metric lookup).

    Returns
    -------
    dict
        ``available`` (bool) — False if 2021 node data is absent.
        Full trajectory dict when available includes slopes, accelerations,
        inflection_flag, and event_driven_greenwashing (bool).
    """
    ev = auditor_output.get("event_study") or {}
    y_base = int(ev.get("baseline_year", 2015))
    y_mid_raw = ev.get("mid_year")
    if y_mid_raw is None:
        return {"available": False}
    y_mid = int(y_mid_raw)
    y_curr = int(ev.get("current_year", 2024))
    event_label = str(ev.get("event_label", "Event study (see manifest)"))

    # Semantic slots: baseline / mid / current (legacy keys sentiment_2015, _2021, _2024)
    s_base = corporate_output.get("sentiment_2015")
    s_mid = corporate_output.get("sentiment_2021")
    s_curr = corporate_output.get("sentiment_2024")
    arb_flag = auditor_output.get("jurisdictional_arbitrage", 0)

    if s_mid is None:
        return {"available": False}

    fuel_metric = auditor_output.get("fuel_metric")
    if not fuel_metric:
        company_name = auditor_output.get("company_name", "shell")
        try:
            from agents.auditor_agent import COMPANY_CONFIG

            fuel_metric = COMPANY_CONFIG.get(company_name, {}).get(
                "fuel_metric", "Upstream Natural Gas Fuel Consumption"
            )
        except ImportError:
            fuel_metric = "Upstream Natural Gas Fuel Consumption"

    records = auditor_output.get("raw_records", [])
    ri: dict = {}
    for yr in (y_base, y_mid, y_curr):
        for r in records:
            if r.get("metric", "").strip() == fuel_metric and int(r.get("year", 0)) == yr:
                try:
                    ri[yr] = float(r["value"])
                except (ValueError, KeyError):
                    pass

    if y_mid not in ri:
        return {"available": False}

    ri_2015 = ri.get(y_base, 0.0)
    ri_2021 = ri[y_mid]
    ri_2024 = ri.get(y_curr, 0.0)

    PRE_YEARS = y_mid - y_base
    POST_YEARS = y_curr - y_mid
    if PRE_YEARS <= 0 or POST_YEARS <= 0:
        return {"available": False}

    sentiment_slope_pre  = round((s_mid - s_base) / PRE_YEARS,  6)
    sentiment_slope_post = round((s_curr - s_mid) / POST_YEARS, 6)
    sent_accel = (
        round(((sentiment_slope_post / sentiment_slope_pre) - 1) * 100, 1)
        if abs(sentiment_slope_pre) > 1e-9 else None
    )

    # ── Resource intensity slopes (TJ/year) ───────────────────────────────────
    ri_slope_pre  = round((ri_2021 - ri_2015) / PRE_YEARS,  2)
    ri_slope_post = round((ri_2024 - ri_2021) / POST_YEARS, 2)
    ri_accel = (
        round(((ri_slope_post / ri_slope_pre) - 1) * 100, 1)
        if abs(ri_slope_pre) > 1e-9 else None
    )

    # ── Inflection detection ──────────────────────────────────────────────────
    # All three conditions must hold for "TEXTBOOK EVENT-DRIVEN GREENWASHING":
    #   (1) Narrative acceleration post-2021
    #   (2) Resource intensity acceleration post-2021
    #   (3) Jurisdictional Arbitrage confirmed (arb_flag = 1)
    cond_sentiment_accel  = sentiment_slope_post > sentiment_slope_pre
    cond_resource_accel   = ri_slope_post > ri_slope_pre
    cond_arb              = arb_flag == 1
    event_driven_gw       = cond_sentiment_accel and cond_resource_accel and cond_arb

    if event_driven_gw:
        inflection_flag = "TEXTBOOK EVENT-DRIVEN GREENWASHING"
    elif cond_sentiment_accel and cond_resource_accel:
        inflection_flag = "DUAL ACCELERATION (no jurisdictional trigger)"
    elif not cond_resource_accel and ri_slope_post < ri_slope_pre:
        inflection_flag = "CONSISTENT TRANSITION TRAJECTORY"
    else:
        inflection_flag = "NO INFLECTION DETECTED"

    return {
        "available":               True,
        "event_label":             event_label,
        "years":                   [y_base, y_mid, y_curr],
        # Sentiment trajectory (keys remain legacy names; values = baseline/mid/current)
        "sentiment_2015":          s_base,
        "sentiment_2021":          s_mid,
        "sentiment_2024":          s_curr,
        "sentiment_slope_pre":     sentiment_slope_pre,
        "sentiment_slope_post":    sentiment_slope_post,
        "sentiment_acceleration_pct": sent_accel,
        "cond_sentiment_accel":    cond_sentiment_accel,
        # Resource trajectory
        "resource_2015":           ri_2015,
        "resource_2021":           ri_2021,
        "resource_2024":           ri_2024,
        "ri_slope_pre":            ri_slope_pre,
        "ri_slope_post":           ri_slope_post,
        "ri_acceleration_pct":     ri_accel,
        "cond_resource_accel":     cond_resource_accel,
        # Verdict
        "cond_arb":                cond_arb,
        "event_driven_greenwashing": event_driven_gw,
        "inflection_flag":         inflection_flag,
    }


def _compute_wacc_impact(risk_flag: str, cross_checks: List[Dict]) -> dict:
    """
    Translate I_d risk classification into actionable Cost of Capital adjustments.

    Produces institutional-grade WACC basis-point signals that bridge the gap
    between NLP sentiment analysis and DCF asset pricing. This is the "Financial
    Alpha" layer — every adjustment maps directly to a verifiable, citable
    public-data rationale.

    Adjustment schedule:
      HIGH-RISK STRATEGIC OBFUSCATION (base):    +100 bps
        Jurisdictional Arbitrage escalation:     + 50 bps
        Total (Shell with EU→UK shift):          +150 bps

      MODERATE OBFUSCATION RISK:                  +50 bps

      AUTHENTIC TRANSITION LEADER:                −50 bps
        Verified −87.5% fossil footprint + −56% Scope 3 reduce regulatory
        and stranded-asset tail-risk, justifying a green cost-of-capital discount.

      CONSERVATIVE SIGNALLING / TRANSITION UNDERSTATEMENT / NARRATIVE ALIGNED:
        0 bps (no adjustment warranted)

    Parameters
    ----------
    risk_flag    : str        Risk classification label from _classify().
    cross_checks : List[Dict] Cross-check results for Jurisdictional Arbitrage lookup.

    Returns
    -------
    dict
        Keys: valuation_impact_bps (int), implied_wacc_modifier (float),
        valuation_action (str).
    """
    arb_triggered = any(
        c.get("triggered") and "Jurisdictional" in c.get("rule", "")
        for c in cross_checks
    )

    if risk_flag == "HIGH-RISK STRATEGIC OBFUSCATION":
        bps = WACC_BASE_OBFUSCATION_BPS
        if arb_triggered:
            bps += WACC_ARB_ESCALATION_BPS
            action = (
                f"DOWNGRADE: Apply +{bps} bps ESG Risk Premium to WACC. "
                f"Components: +{WACC_BASE_OBFUSCATION_BPS} bps base obfuscation premium "
                f"| +{WACC_ARB_ESCALATION_BPS} bps for unpriced EU→UK Scope 3 "
                "jurisdictional arbitrage (Milieudefensie ruling risk reclassified "
                "from mandatory CSRD to voluntary SDR). "
                "Recommend risk-adjusted DCF with elevated cost of capital. "
                "[VERIFIED via Companies House 2022 + Shell SR24 p.61]"
            )
        else:
            action = (
                f"DOWNGRADE: Apply +{bps} bps ESG Risk Premium to WACC. "
                "Operational resource surge contradicts transition commitments. "
                "Recommend stress-testing DCF under carbon-price scenario analysis."
            )

    elif risk_flag == "MODERATE OBFUSCATION RISK":
        bps    = WACC_MODERATE_BPS
        action = (
            f"REVIEW: Apply +{bps} bps provisional ESG Risk Adjustment to WACC. "
            "Partial narrative-reality decoupling detected — monitor transition "
            "capex allocation and Scope 3 trajectory for reassessment."
        )

    elif risk_flag == "AUTHENTIC TRANSITION LEADER":
        bps    = WACC_GREEN_PREMIUM_BPS
        action = (
            f"UPGRADE: Apply {bps} bps Green Premium to WACC. "
            "Verified operational transition (−87.5% fossil fuel consumption, "
            "−56% Scope 3 GHG) reduces regulatory and stranded-asset tail-risk. "
            "EU-CSRD mandatory compliance maintained. "
            "ESG-adjusted DCF supports premium cost-of-capital discount. "
            "[VERIFIED via Ørsted ESG Performance Report 2024]"
        )

    else:
        # CONSERVATIVE SIGNALLING, TRANSITION UNDERSTATEMENT, NARRATIVE ALIGNED
        bps    = WACC_NEUTRAL_BPS
        action = (
            "HOLD: No WACC adjustment warranted. "
            "Narrative-reality alignment within acceptable parameters for current period."
        )

    bps = int(max(WACC_IMPACT_BPS_MIN, min(WACC_IMPACT_BPS_MAX, int(bps))))
    return {
        "valuation_impact_bps":  bps,
        "implied_wacc_modifier": round(bps / 10_000, 6),
        "valuation_action":      action,
    }


def _classify(
    id_val:          float,
    delta_sentiment: float,
    delta_resource:  float,
    arb_flag:        int,
    company:         str = "",
) -> Tuple[str, str, str]:
    """
    Classify the I_d value using direction-aware deterministic rules.

    The primary branch point is the SIGN of ΔResource Intensity:

    Branch A — ΔResource < 0 (genuine operational reduction):
        The denominator is negative, so I_d is negative when ΔSentiment > 0.
        This is the correct mathematical outcome for an authentic transition
        leader: positive narrative aligns with positive operational reality.
        No threshold comparison is needed — the sign itself is the verdict.

    Branch B — ΔResource ≥ 0 (operational deterioration or stagnation):
        I_d > OBFUSCATION_THRESHOLD → HIGH-RISK STRATEGIC OBFUSCATION
        I_d ≤ OBFUSCATION_THRESHOLD → MODERATE OBFUSCATION RISK
        ΔSentiment ≤ 0              → CONSERVATIVE SIGNALLING
        Jurisdictional Arbitrage escalation applied if arb_flag = 1.

    Parameters
    ----------
    id_val          : Computed I_d value.
    delta_sentiment : ΔNarrative Sentiment (2024 − 2015).
    delta_resource  : ΔResource Intensity (fuel proportional change).
    arb_flag        : Jurisdictional Arbitrage binary flag.
    company         : Display name for logging context.

    Returns
    -------
    Tuple[str, str, str]
        (risk_flag, risk_level, classification_reason)
    """
    # ── BRANCH A: Negative ΔResource — genuine operational reduction ──────────
    if delta_resource < 0:
        if delta_sentiment >= 0:
            base_flag  = "AUTHENTIC TRANSITION LEADER"
            base_level = "LOW"
            reason = (
                f"Resource intensity DECLINING ({delta_resource * 100:.1f}%) "
                f"while narrative sentiment is positive (+{delta_sentiment:.3f}). "
                "Operational capital allocation aligns with transition commitments. "
                f"I_d = {id_val:+.4f} (negative → authentic alignment confirmed). "
                f"[VERIFIED via {company} public ESG filings]"
            )
        else:
            base_flag  = "TRANSITION UNDERSTATEMENT"
            base_level = "LOW"
            reason = (
                f"Resource intensity DECLINING ({delta_resource * 100:.1f}%) but "
                f"narrative sentiment is flat/negative ({delta_sentiment:+.3f}). "
                "Management communications understate genuine operational improvements."
            )
        # No jurisdictional escalation for authentic leaders
        return base_flag, base_level, reason

    # ── BRANCH B: Positive ΔResource — operational deterioration ─────────────
    if delta_sentiment > 0 and delta_resource > 0:
        if id_val > OBFUSCATION_THRESHOLD:
            base_flag  = "HIGH-RISK STRATEGIC OBFUSCATION"
            base_level = "HIGH"
            reason = (
                f"Narrative sentiment escalated (+{delta_sentiment:.3f}) while "
                f"resource intensity surged +{delta_resource * 100:.1f}%. "
                "Capital allocation reality contradicts transition commitments. "
                "[VERIFIED via public AR + SR filings]"
            )
        else:
            base_flag  = "MODERATE OBFUSCATION RISK"
            base_level = "MEDIUM"
            reason = (
                f"Sentiment positive but I_d ({id_val:+.4f}) below high-risk "
                f"threshold ({OBFUSCATION_THRESHOLD}). "
                "Partial narrative-reality decoupling detected."
            )
    elif delta_sentiment <= 0:
        base_flag  = "CONSERVATIVE SIGNALLING"
        base_level = "LOW"
        reason = (
            f"Narrative sentiment flat or declining ({delta_sentiment:+.3f}). "
            "Management communications do not overclaim relative to operational data."
        )
    else:
        base_flag  = "NARRATIVE ALIGNED"
        base_level = "LOW"
        reason = "Sentiment and resource intensity moving in consistent directions."

    # Jurisdictional Arbitrage escalation (ΔResource > 0 branch only)
    if arb_flag == 1 and JURISDICTION_ESCALATION:
        escalation_note = (
            " ESCALATED: Jurisdictional Arbitrage confirmed — 2022 UK relocation "
            "reclassified mandatory EU-CSRD Scope 3 liabilities to voluntary UK-SDR. "
            "[VERIFIED via Companies House Filing 2022, CH No. 04366849]"
        )
        if base_level == "MEDIUM":
            base_flag  = "HIGH-RISK STRATEGIC OBFUSCATION"
            base_level = "HIGH"
            reason += escalation_note
        elif base_level == "LOW":
            base_flag  = "MODERATE OBFUSCATION RISK"
            base_level = "MEDIUM"
            reason += escalation_note
        else:
            reason += escalation_note

    return base_flag, base_level, reason


def _run_cross_checks(auditor_output: dict) -> List[Dict]:
    """
    Run direction-aware symbolic cross-checks against audit metrics.

    The cross-check set is selected based on the sign of ΔResource Intensity:
      • ΔResource > 0 (deterioration) → four obfuscation indicator checks
      • ΔResource < 0 (improvement)   → four authentic transition checks

    All logic is deterministic — no LLM involvement in this layer.

    Parameters
    ----------
    auditor_output : dict
        Full output dict from AuditorAgent.

    Returns
    -------
    List[Dict]
        List of cross-check result dicts, each with keys:
        ``rule``, ``triggered`` (bool), ``detail``, ``citation``.
    """
    delta_scope3 = auditor_output.get("delta_scope3_pct")
    capex_val    = auditor_output.get("transition_capex_val", 0.0)
    arb_flag     = auditor_output.get("jurisdictional_arbitrage", 0)
    delta_ri     = auditor_output.get("delta_resource_intensity", 0.0)
    display      = auditor_output.get("display_name", "")
    capex_metric = auditor_output.get("capex_metric", "Transition Capex")

    checks: List[Dict] = []

    if delta_ri < 0:
        # ── Authentic Transition Validation Checks ────────────────────────────
        # For genuine transition leaders (ΔResource < 0), checks confirm
        # alignment between narrative and operational reality. "triggered" = True
        # means a POSITIVE validation signal (the opposite of the Shell case).

        checks.append({
            "rule":      "Fossil fuel consumption declining >50%",
            "triggered": delta_ri < -0.5,
            "detail":    (
                f"ΔResource Intensity = {delta_ri * 100:.1f}% — "
                "fuel consumption reduction validates transition commitments."
            ),
            "citation":  f"{display} ESG Performance Report — Fuel Consumption 2015→2024",
        })

        if delta_scope3 is not None:
            checks.append({
                "rule":      "Scope 3 emissions declining with fossil reduction",
                "triggered": delta_scope3 < -10.0,
                "detail":    (
                    f"ΔScope 3 = {delta_scope3:.1f}% — "
                    "Scope 3 reduction corroborates upstream fossil fuel exit."
                ),
                "citation":  f"{display} ESG Performance Report — Scope 3 GHG 2015 & 2024",
            })

        checks.append({
            "rule":      "Transition Capex growing (positive allocation)",
            "triggered": capex_val > 50.0,
            "detail":    (
                f"{capex_metric} = +{capex_val:.1f}% — "
                "capital allocation aligned with transition commitments."
            ),
            "citation":  f"{display} Capital Markets Day / Annual Report — Capex 2024",
        })

        checks.append({
            "rule":      "No Jurisdictional Arbitrage (EU-CSRD compliant)",
            "triggered": arb_flag == 0,
            "detail":    (
                "Company remains bound by mandatory EU-CSRD in home jurisdiction. "
                "No regulatory liability reclassification detected."
            ),
            "citation":  f"{display} Corporate Legal Filing — CSRD Compliance 2024",
        })

    else:
        # ── Greenwashing / Obfuscation Indicator Checks ───────────────────────
        checks.append({
            "rule":      "Net-Zero claim vs Gas Surge >500%",
            "triggered": delta_ri > 5.0,
            "detail":    (
                f"ΔResource Intensity = {delta_ri * 100:.1f}% — "
                "10× surge directly contradicts Net-Zero 2050 framing."
            ),
            "citation":  "Shell AR24 p.78 — Upstream Natural Gas Fuel Consumption 2015→2024",
        })

        if delta_scope3 is not None:
            checks.append({
                "rule":      "Scope 3 stagnant while upstream gas surges",
                "triggered": abs(delta_scope3) < 1.0 and delta_ri > 2.0,
                "detail":    (
                    f"ΔScope 3 = {delta_scope3:.2f}% (flat) while "
                    f"ΔGas = +{delta_ri * 100:.1f}%. "
                    "Scope 3 freeze confirmed by UK-SDR voluntary framework."
                ),
                "citation":  "Shell SR24 p.61 — Total Scope 3 GHG Emissions 2015 & 2024",
            })

        checks.append({
            "rule":      "Transition Capex contraction >50%",
            "triggered": capex_val < -50.0,
            "detail":    (
                f"Transition Capex contracted {capex_val:.1f}% — "
                "capital allocation contradicts transition-leadership narrative."
            ),
            "citation":  "Shell Strategic Update 2024 p.12 — Capital Allocation Framework",
        })

        checks.append({
            "rule":      "Jurisdictional Arbitrage (UK relocation 2022)",
            "triggered": arb_flag == 1,
            "detail":    (
                "Shell relocated to UK in 2022, converting Scope 3 from "
                "legally enforceable EU-CSRD to voluntary UK-SDR compliance."
            ),
            "citation":  "Companies House UK Filing 2022 — CH No. 04366849",
        })

    return checks
