# Stage 2 submission notes (Alpha 1)

**Copyright:** Zongchen Nan — see [LICENSE](LICENSE) and [NOTICE](NOTICE). Team **Alpha 1** is the competition designation on CFA materials; authorship of the codebase and technical write-up is attributed to Zongchen Nan as described in `NOTICE`.

**Before exclusive licensing or commercial sale:** confirm Durham University’s intellectual-property rules for student work if applicable; consider a one-line written acknowledgment from teammates that they do not assert copyright in this repository (optional but useful for clarity).

## Appendix B pack

- Primary technical document: [`technical_explanation.md`](technical_explanation.md) (maps to FAQ Appendix B: Executive Summary, repo links, architecture, data, results, interpretability, AI usage including §6.9 Cursor vs runtime).
- **Executive Summary:** four bullets; word count is intentionally within the FAQ’s ~100–200 word guideline (verify after any edit with a quick count).

## Export to PDF or Word (if the host requires it)

1. Open `technical_explanation.md` in **VS Code / Cursor**, **Typora**, **Pandoc**, or paste into the host’s **Word template**.
2. **Word:** Paste markdown or open via “Open” if supported; then **File → Save As → PDF** or `.docx`.
3. **Pandoc (optional):** `pandoc technical_explanation.md -o AuditLens_Technical_Explanation.pdf`
4. Re-check that **§2 links** match the public repo: [https://github.com/Longfordjames/Auditlens](https://github.com/Longfordjames/Auditlens)

## Push full tree before judges clone

The public GitHub repo must contain **all** source, `data/energy_sector/`, `data/api_cache.json`, `tests/`, and this file—not only `README.md` and `LICENSE`.
