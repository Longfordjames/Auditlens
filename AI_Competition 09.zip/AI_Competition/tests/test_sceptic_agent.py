# MIT License — see LICENSE file
"""
tests/test_sceptic_agent.py
============================
Unit tests for the ScepticAgent (Layer 3) — deterministic I_d formula
correctness, division-by-zero guards, risk classification logic,
symbolic cross-check direction-awareness, and WACC pricing impact.

All tests run offline: no LLM calls, no file I/O, no network.

Coverage areas:
  • I_d arithmetic:       formula correctness, sign algebra, denominator
  • Division-by-zero:     DD = 0, ΔRI = 0, near-zero denominator
  • Risk classification:  all five risk tiers + Jurisdictional Arbitrage escalation
  • Benchmark contrast:   Shell (HIGH-RISK) vs Ørsted (AUTHENTIC LEADER)
  • Cross-checks:         direction-aware sets, trigger counts, output schema
  • WACC pricing impact:  +150 bps Shell, −50 bps Ørsted, implied modifier, action
"""

import math
from unittest.mock import patch

import pytest
from agents.sceptic_agent import (
    OBFUSCATION_THRESHOLD,
    _I_D_MAGNITUDE_CAP,
    _classify,
    _compute_trajectory,
    _run_cross_checks,
    effective_id_denominator,
    run,
)


# ── Shared test fixtures ──────────────────────────────────────────────────────

def _corp(
    delta_sentiment: float,
    sentiment_2015: float = 0.18,
    sentiment_2021: float = None,
    sentiment_2024: float = None,
) -> dict:
    """Minimal CorporateAgent output stub — supports optional tri-node sentiments."""
    d = {
        "delta_narrative_sentiment": delta_sentiment,
        "sentiment_2015":            sentiment_2015,
        "sentiment_2021":            sentiment_2021,
        "sentiment_2024":            sentiment_2024 if sentiment_2024 is not None
                                     else (sentiment_2015 + delta_sentiment),
    }
    return d


_DEFAULT_EVENT_STUDY = {
    "baseline_year": 2015,
    "mid_year": 2021,
    "current_year": 2024,
    "event_label": "Test event (fixture)",
}


def _aud(
    delta_resource:    float,
    disclosure_density: float,
    arb_flag:          int   = 0,
    delta_scope3:      float = 0.0,
    capex_val:         float = 0.0,
    display_name:      str   = "Test Corp",
    raw_records:       list  = None,
    company_name:      str   = "shell",
    event_study:       dict  = None,
    fuel_metric:       str   = "Total energy consumption",
) -> dict:
    """Minimal AuditorAgent output stub — supports raw_records for trajectory tests."""
    ev = dict(_DEFAULT_EVENT_STUDY)
    if event_study:
        ev.update(event_study)
    return {
        "delta_resource_intensity":  delta_resource,
        "disclosure_density":        disclosure_density,
        "company_name":              company_name,
        "jurisdictional_arbitrage":  arb_flag,
        "delta_scope3_pct":          delta_scope3,
        "transition_capex_val":      capex_val,
        "raw_records":               raw_records if raw_records is not None else [],
        "display_name":              display_name,
        "capex_metric":              "Transition Capex",
        "fuel_metric":               fuel_metric,
        "event_study":               ev,
        "scope3_metric":             "Total Scope 3 GHG Emissions",
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 1. I_d Formula Arithmetic
# ═══════════════════════════════════════════════════════════════════════════════

class TestIdFormula:
    """Mathematical correctness of I_d = ΔSentiment / (ΔResource × DD)."""

    def test_formula_basic_arithmetic(self):
        """I_d equals the expected quotient to 4 decimal places."""
        result   = run(_corp(0.54), _aud(9.646, 0.74))
        expected = round(0.54 / (9.646 * 0.74), 6)
        assert abs(result["integrity_discount"] - expected) < 1e-4

    def test_formula_denominator_stored(self):
        """formula_inputs['denominator'] = ΔResource × DD."""
        result = run(_corp(0.5), _aud(2.0, 0.5))
        assert abs(result["formula_inputs"]["denominator"] - (2.0 * 0.5)) < 1e-9

    def test_formula_all_inputs_present(self):
        """formula_inputs contains all four required keys."""
        result   = run(_corp(0.5), _aud(3.0, 0.74))
        required = {
            "delta_narrative_sentiment",
            "delta_resource_intensity",
            "disclosure_density",
            "denominator",
            "denominator_raw",
            "denominator_epsilon_guard",
        }
        assert required.issubset(result["formula_inputs"].keys())

    def test_shell_case_positive_id(self):
        """Shell-like scenario (ΔRI > 0, ΔSentiment > 0) → I_d > 0."""
        result = run(_corp(0.54), _aud(9.646, 0.74))
        assert result["integrity_discount"] > 0

    def test_orsted_case_negative_id(self):
        """Ørsted-like scenario (ΔRI < 0, ΔSentiment > 0) → I_d < 0.

        Key mathematical property: positive ΔSentiment / negative denominator
        yields a negative I_d, which is the mathematical proof of authentic
        alignment rather than an error condition.
        """
        result = run(_corp(0.68), _aud(-0.875, 0.88))
        assert result["integrity_discount"] < 0

    def test_orsted_id_value_matches_formula(self):
        """Ørsted I_d ≈ 0.68 / (-0.875 × 0.88) ≈ -0.883."""
        result   = run(_corp(0.68), _aud(-0.875, 0.88))
        expected = 0.68 / (-0.875 * 0.88)
        assert abs(result["integrity_discount"] - round(expected, 6)) < 1e-4

    def test_sentiment_zero_yields_zero_id(self):
        """ΔSentiment = 0 → I_d = 0 exactly."""
        result = run(_corp(0.0), _aud(5.0, 0.74))
        assert result["integrity_discount"] == 0.0

    def test_output_schema_complete(self):
        """run() always returns the full required output schema."""
        result = run(_corp(0.5), _aud(5.0, 0.74))
        required_keys = {
            "integrity_discount", "risk_flag", "risk_level",
            "explanation", "formula_inputs", "cross_checks",
            "denominator_epsilon_guard",
            "neuro_symbolic_reflection",
        }
        assert required_keys.issubset(result.keys())
        assert "triggered" in result["neuro_symbolic_reflection"]


# ═══════════════════════════════════════════════════════════════════════════════
# 1b. Neuro-Symbolic Reflection Loop (symbolic trigger → mocked neural pass)
# ═══════════════════════════════════════════════════════════════════════════════

class TestNeuroSymbolicReflection:
    """Reflection fires only when symbolic thresholds + registry company align."""

    @patch("agents.corporate_agent.run_reflection_pass")
    def test_reflection_triggers_on_surge_and_positive_delta(self, mock_refl):
        """ΔResource > 0.5, ΔSentiment > 0.2, known company → one reflection call."""
        mock_refl.return_value = {
            "reflective_sentiment_score": 0.25,
            "cognitive_dissonance_analysis": "Skepticism test: hedging masks surge.",
            "cache_label": "CorporateAgent_reflection_shell_2024",
        }
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2024=0.72)
        corp["company_name"] = "shell"
        result = run(
            corp,
            _aud(9.646, 0.74),
            enable_neuro_symbolic_reflection=True,
        )
        assert result["neuro_symbolic_reflection"]["triggered"] is True
        mock_refl.assert_called_once()
        assert result["neuro_symbolic_reflection"]["cognitive_dissonance_analysis"].startswith(
            "Skepticism test"
        )
        assert result["formula_inputs"]["delta_narrative_sentiment"] == round(0.25 - 0.18, 6)

    @patch("agents.corporate_agent.run_reflection_pass")
    def test_reflection_not_triggered_when_delta_sentiment_low(self, mock_refl):
        """Below +0.2 initial ΔSentiment → no reflection (linear path)."""
        corp = _corp(0.15, sentiment_2015=0.18, sentiment_2024=0.33)
        corp["company_name"] = "shell"
        run(corp, _aud(9.646, 0.74), enable_neuro_symbolic_reflection=True)
        mock_refl.assert_not_called()

    @patch("agents.corporate_agent.run_reflection_pass")
    def test_reflection_not_triggered_when_resource_surge_small(self, mock_refl):
        """ΔResource ≤ 0.5 → no reflection."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2024=0.72)
        corp["company_name"] = "shell"
        run(corp, _aud(0.4, 0.74), enable_neuro_symbolic_reflection=True)
        mock_refl.assert_not_called()

    @patch("agents.corporate_agent.run_reflection_pass")
    def test_reflection_disabled_by_default_flag(self, mock_refl):
        """enable_neuro_symbolic_reflection=False → never calls CorporateAgent."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2024=0.72)
        corp["company_name"] = "shell"
        run(corp, _aud(9.646, 0.74), enable_neuro_symbolic_reflection=False)
        mock_refl.assert_not_called()
        assert run(corp, _aud(9.646, 0.74))["neuro_symbolic_reflection"]["triggered"] is False

    @patch("agents.corporate_agent.run_reflection_pass")
    def test_reflection_skipped_without_company_registry(self, mock_refl):
        """Unknown company_name → no call (no excerpts registry)."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2024=0.72)
        corp["company_name"] = "unknown_co"
        run(corp, _aud(9.646, 0.74), enable_neuro_symbolic_reflection=True)
        mock_refl.assert_not_called()


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Division-by-Zero Guards
# ═══════════════════════════════════════════════════════════════════════════════

class TestDivisionByZero:
    """Denominator safety: ε-guard prevents ZeroDivisionError / Inf I_d."""

    def test_zero_disclosure_density_uses_epsilon_guard(self):
        """DD = 0.0 → raw denom 0 → finite I_d; epsilon guard flagged."""
        result = run(_corp(0.5), _aud(5.0, 0.0))
        assert result["denominator_epsilon_guard"] is True
        assert math.isfinite(result["integrity_discount"])

    def test_zero_resource_intensity_uses_epsilon_guard(self):
        """ΔRI = 0.0 → epsilon guard; quotient remains finite."""
        result = run(_corp(0.5), _aud(0.0, 0.74))
        assert result["denominator_epsilon_guard"] is True
        assert math.isfinite(result["integrity_discount"])

    def test_near_zero_denominator_uses_epsilon_guard(self):
        """ΔRI = 1e-10 → |product| < ε → stable finite I_d."""
        result = run(_corp(0.5), _aud(1e-10, 0.74))
        assert result["denominator_epsilon_guard"] is True
        assert math.isfinite(result["integrity_discount"])

    def test_both_zero_uses_epsilon_guard(self):
        """ΔRI = 0, DD = 0 → degenerate case → +ε divisor, finite I_d."""
        result = run(_corp(0.5), _aud(0.0, 0.0))
        assert result["denominator_epsilon_guard"] is True
        assert math.isfinite(result["integrity_discount"])

    def test_flat_delta_resource_id_bounded_not_astronomical(self):
        """Ørsted-like: ΔRI=0, DD>0, ΔSent≈0.62 → |I_d| <= cap (not 1e8 scale)."""
        result = run(_corp(0.62), _aud(0.0, 0.74))
        assert result["denominator_epsilon_guard"] is True
        assert abs(result["integrity_discount"]) <= _I_D_MAGNITUDE_CAP + 1e-6

    def test_effective_id_denominator_matches_sentiment_scaled_floor(self):
        eff, raw, guard = effective_id_denominator(0.0, 0.74, 0.62)
        assert guard is True
        assert abs(raw) < 1e-9
        expected_mag = max(1e-9, 0.62 / _I_D_MAGNITUDE_CAP)
        assert abs(abs(eff) - expected_mag) < 1e-9

    def test_negative_resource_nonzero_does_not_raise(self):
        """Negative but non-zero ΔRI is valid — should not raise."""
        result = run(_corp(0.68), _aud(-0.875, 0.88))
        assert "integrity_discount" in result


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Risk Classification — Five Tiers
# ═══════════════════════════════════════════════════════════════════════════════

class TestRiskClassification:
    """All five risk tiers and the Jurisdictional Arbitrage escalator."""

    # ── HIGH-RISK STRATEGIC OBFUSCATION ──────────────────────────────────────

    def test_high_risk_above_threshold(self):
        """I_d > OBFUSCATION_THRESHOLD → HIGH-RISK STRATEGIC OBFUSCATION.

        Use ΔRI=0.5, DD=0.5 → denom=0.25, I_d=0.5/0.25=2.0 >> threshold 0.10.
        """
        result = run(_corp(0.5), _aud(0.5, 0.5))
        assert result["risk_level"] == "HIGH"
        assert "OBFUSCATION" in result["risk_flag"]

    def test_high_risk_flag_string(self):
        """Flag text is exactly 'HIGH-RISK STRATEGIC OBFUSCATION'."""
        result = run(_corp(0.5), _aud(0.5, 0.5))
        assert result["risk_flag"] == "HIGH-RISK STRATEGIC OBFUSCATION"

    # ── MODERATE OBFUSCATION RISK ─────────────────────────────────────────────

    def test_moderate_risk_shell_case_no_arb(self):
        """Shell I_d ≈ 0.076 < 0.10 threshold, arb=0 → MODERATE OBFUSCATION RISK."""
        result = run(_corp(0.54), _aud(9.646, 0.74, arb_flag=0))
        assert result["risk_level"] == "MEDIUM"
        assert "MODERATE" in result["risk_flag"]

    def test_moderate_risk_just_below_threshold(self):
        """I_d just below threshold (0.099) → MODERATE, not HIGH."""
        # I_d = 0.099: ΔSentiment / denom = 0.099 → ΔSentiment = 0.099 * denom
        # Use denom = 1.0: ΔRI=1.0, DD=1.0, ΔSentiment=0.099
        result = run(_corp(0.099), _aud(1.0, 1.0))
        assert result["risk_level"] == "MEDIUM"

    # ── JURISDICTIONAL ARBITRAGE ESCALATOR ────────────────────────────────────

    def test_jurisdictional_arbitrage_escalates_medium_to_high(self):
        """arb_flag=1 on a MEDIUM classification → promoted to HIGH."""
        result = run(_corp(0.54), _aud(9.646, 0.74, arb_flag=1))
        assert result["risk_level"] == "HIGH"
        assert "OBFUSCATION" in result["risk_flag"]

    def test_jurisdictional_arbitrage_note_in_explanation(self):
        """Escalation embeds Companies House citation in explanation."""
        result = run(_corp(0.54), _aud(9.646, 0.74, arb_flag=1))
        assert "04366849" in result["explanation"] or "Jurisdictional Arbitrage" in result["explanation"]

    # ── AUTHENTIC TRANSITION LEADER (negative ΔRI branch) ────────────────────

    def test_authentic_transition_leader_orsted(self):
        """ΔRI < 0, ΔSentiment > 0 → AUTHENTIC TRANSITION LEADER, risk=LOW."""
        result = run(_corp(0.68), _aud(-0.875, 0.88, arb_flag=0))
        assert result["risk_level"] == "LOW"
        assert result["risk_flag"] == "AUTHENTIC TRANSITION LEADER"

    def test_authentic_leader_no_escalation_with_arb_flag(self):
        """AUTHENTIC TRANSITION LEADER is immune to Jurisdictional Arbitrage escalation.

        The negative ΔRI branch exits before the escalation logic — an authentic
        transition leader cannot be demoted by an arbitrage flag that is structurally
        incompatible with its operational reality.
        """
        result_no_arb = run(_corp(0.68), _aud(-0.875, 0.88, arb_flag=0))
        result_with_arb = run(_corp(0.68), _aud(-0.875, 0.88, arb_flag=1))
        assert result_no_arb["risk_flag"] == result_with_arb["risk_flag"] == "AUTHENTIC TRANSITION LEADER"
        assert result_no_arb["risk_level"] == result_with_arb["risk_level"] == "LOW"

    def test_authentic_leader_i_d_is_negative(self):
        """AUTHENTIC TRANSITION LEADER always has I_d < 0."""
        result = run(_corp(0.68), _aud(-0.875, 0.88))
        assert result["integrity_discount"] < 0

    # ── CONSERVATIVE SIGNALLING ───────────────────────────────────────────────

    def test_conservative_signalling_negative_sentiment(self):
        """ΔSentiment < 0, ΔRI > 0 → CONSERVATIVE SIGNALLING, risk=LOW."""
        result = run(_corp(-0.1), _aud(3.0, 0.5))
        assert result["risk_level"] == "LOW"
        assert "CONSERVATIVE" in result["risk_flag"]

    def test_conservative_signalling_zero_sentiment(self):
        """ΔSentiment = 0.0, ΔRI > 0 → CONSERVATIVE SIGNALLING."""
        result = run(_corp(0.0), _aud(5.0, 0.74))
        assert "CONSERVATIVE" in result["risk_flag"]


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Symbolic Cross-Checks
# ═══════════════════════════════════════════════════════════════════════════════

class TestCrossChecks:
    """Direction-aware symbolic cross-check validation."""

    def test_shell_all_four_checks_triggered(self):
        """Shell full scenario: 4/4 obfuscation checks triggered."""
        result = run(
            _corp(0.54),
            _aud(9.646, 0.74, arb_flag=1, delta_scope3=0.0, capex_val=-55.7),
        )
        triggered = [c for c in result["cross_checks"] if c["triggered"]]
        assert len(triggered) == 4

    def test_orsted_all_four_validations_confirmed(self):
        """Ørsted full scenario: 4/4 positive validation checks confirmed."""
        result = run(
            _corp(0.68),
            _aud(-0.875, 0.88, arb_flag=0, delta_scope3=-56.0, capex_val=95.0),
        )
        confirmed = [c for c in result["cross_checks"] if c["triggered"]]
        assert len(confirmed) == 4

    def test_always_four_cross_checks_returned(self):
        """Exactly 4 cross-checks are always returned regardless of ΔRI sign."""
        for delta_ri in [9.65, -0.875]:
            result = run(_corp(0.5), _aud(delta_ri, 0.74))
            assert len(result["cross_checks"]) == 4

    def test_cross_check_schema(self):
        """Each cross-check entry has required keys: rule, triggered, detail, citation."""
        result = run(_corp(0.5), _aud(5.0, 0.74))
        for chk in result["cross_checks"]:
            assert {"rule", "triggered", "detail", "citation"}.issubset(chk.keys())
            assert isinstance(chk["triggered"], bool)
            assert isinstance(chk["rule"], str)

    def test_gas_surge_check_triggers_above_500pct(self):
        """Net-Zero vs Gas Surge check triggers when ΔRI > 5.0 (500%)."""
        result = run(_corp(0.5), _aud(5.1, 0.74))
        gas_check = next(c for c in result["cross_checks"] if "Gas Surge" in c["rule"])
        assert gas_check["triggered"] is True

    def test_gas_surge_check_not_triggered_below_500pct(self):
        """Net-Zero vs Gas Surge check does not trigger when ΔRI < 5.0."""
        result = run(_corp(0.5), _aud(4.9, 0.74))
        gas_check = next(c for c in result["cross_checks"] if "Gas Surge" in c["rule"])
        assert gas_check["triggered"] is False

    def test_orsted_fossil_fuel_check_triggers(self):
        """Ørsted: fossil fuel declining >50% check confirmed (−87.5% > threshold)."""
        result = run(
            _corp(0.68),
            _aud(-0.875, 0.88, arb_flag=0, delta_scope3=-56.0, capex_val=95.0),
        )
        fossil_check = next(c for c in result["cross_checks"] if "declining" in c["rule"])
        assert fossil_check["triggered"] is True

    def test_orsted_no_arb_check_passes(self):
        """Ørsted: No Jurisdictional Arbitrage check confirmed (arb_flag=0)."""
        result = run(
            _corp(0.68),
            _aud(-0.875, 0.88, arb_flag=0, delta_scope3=-56.0, capex_val=95.0),
        )
        arb_check = next(c for c in result["cross_checks"] if "Jurisdictional" in c["rule"])
        assert arb_check["triggered"] is True  # triggered = positive validation for leader


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Benchmark Bidirectionality (Anti-Overfitting Proof)
# ═══════════════════════════════════════════════════════════════════════════════

class TestBenchmarkBidirectionality:
    """Proves the MAD Protocol is not overfitted to greenwashing detection."""

    def test_shell_and_orsted_opposite_risk_levels(self):
        """Same formula, no parameter retuning: Shell=HIGH, Ørsted=LOW."""
        shell_result  = run(_corp(0.54), _aud(9.646, 0.74, arb_flag=1))
        orsted_result = run(_corp(0.68), _aud(-0.875, 0.88, arb_flag=0))
        assert shell_result["risk_level"]  == "HIGH"
        assert orsted_result["risk_level"] == "LOW"

    def test_shell_and_orsted_opposite_id_signs(self):
        """Shell I_d > 0, Ørsted I_d < 0 — sign algebra drives classification."""
        shell_result  = run(_corp(0.54), _aud(9.646, 0.74))
        orsted_result = run(_corp(0.68), _aud(-0.875, 0.88))
        assert shell_result["integrity_discount"]  > 0
        assert orsted_result["integrity_discount"] < 0

    def test_same_positive_sentiment_classified_differently(self):
        """Identical positive ΔSentiment produces different risk when ΔRI flips sign.

        This is the core anti-overfitting proof: the sign of ΔResource, not the
        magnitude of ΔSentiment, determines the primary risk classification branch.
        """
        same_sentiment = 0.60
        shell_result  = run(_corp(same_sentiment), _aud(9.0, 0.74))
        orsted_result = run(_corp(same_sentiment), _aud(-0.875, 0.88))
        assert shell_result["risk_level"]  in ("HIGH", "MEDIUM")
        assert orsted_result["risk_level"] == "LOW"
        assert orsted_result["risk_flag"]  == "AUTHENTIC TRANSITION LEADER"


# ═══════════════════════════════════════════════════════════════════════════════
# 6. WACC Pricing Impact — illustrative integrity-adjusted bps mapping
# ═══════════════════════════════════════════════════════════════════════════════

class TestWACCPricingImpact:
    """
    Validates the WACC bps mapping layer of the ScepticAgent (illustrative sensitivity).

    Tests that I_d risk classifications are correctly mapped to institutional
    WACC basis-point adjustments for DCF asset pricing:
      Shell PLC (HIGH-RISK + Jurisdictional Arbitrage)   →  +150 bps
      Shell PLC (HIGH-RISK without Jurisdictional Arb.)  →  +100 bps
      MODERATE OBFUSCATION RISK                          →   +50 bps
      Ørsted A/S (AUTHENTIC TRANSITION LEADER)           →   −50 bps
      CONSERVATIVE SIGNALLING                            →     0 bps
    """

    def test_shell_with_arb_is_150_bps(self):
        """Shell full scenario (HIGH-RISK + Jurisdictional Arbitrage) → +150 bps.

        +100 bps base obfuscation premium
        + 50 bps jurisdictional arbitrage escalation
        = 150 bps total WACC penalty.
        """
        result = run(
            _corp(0.54),
            _aud(9.646, 0.74, arb_flag=1, delta_scope3=0.0, capex_val=-55.7),
        )
        assert result["valuation_impact_bps"] == 150

    def test_shell_without_arb_is_100_bps(self):
        """HIGH-RISK without Jurisdictional Arbitrage → +100 bps base penalty only."""
        # Use ΔRI=0.5, DD=0.5 → denom=0.25, I_d=2.0 >> threshold 0.10
        result = run(_corp(0.5), _aud(0.5, 0.5, arb_flag=0))
        assert result["valuation_impact_bps"] == 100

    def test_orsted_authentic_leader_is_minus_50_bps(self):
        """AUTHENTIC TRANSITION LEADER → −50 bps Green Premium to WACC."""
        result = run(
            _corp(0.68),
            _aud(-0.875, 0.88, arb_flag=0, delta_scope3=-56.0, capex_val=95.0),
        )
        assert result["valuation_impact_bps"] == -50

    def test_moderate_obfuscation_is_50_bps(self):
        """MODERATE OBFUSCATION RISK → +50 bps provisional ESG adjustment."""
        # Shell I_d ≈ 0.076 < 0.10 threshold → MODERATE (no arb)
        result = run(_corp(0.54), _aud(9.646, 0.74, arb_flag=0))
        assert result["valuation_impact_bps"] == 50

    def test_conservative_signalling_is_zero_bps(self):
        """CONSERVATIVE SIGNALLING → 0 bps (HOLD, no adjustment)."""
        result = run(_corp(-0.1), _aud(3.0, 0.5))
        assert result["valuation_impact_bps"] == 0

    def test_shell_implied_wacc_modifier_is_0015(self):
        """Shell +150 bps → implied_wacc_modifier = +0.015 exactly."""
        result = run(
            _corp(0.54),
            _aud(9.646, 0.74, arb_flag=1, delta_scope3=0.0, capex_val=-55.7),
        )
        assert abs(result["implied_wacc_modifier"] - 0.015) < 1e-9

    def test_orsted_implied_wacc_modifier_is_minus_0005(self):
        """Ørsted −50 bps → implied_wacc_modifier = −0.005 exactly."""
        result = run(
            _corp(0.68),
            _aud(-0.875, 0.88, arb_flag=0, delta_scope3=-56.0, capex_val=95.0),
        )
        assert abs(result["implied_wacc_modifier"] - (-0.005)) < 1e-9

    def test_modifier_equals_bps_over_10000(self):
        """implied_wacc_modifier = valuation_impact_bps / 10,000 for all cases."""
        for delta_ri, arb, sentiment in [
            (9.646, 1, 0.54),   # Shell +150 bps
            (-0.875, 0, 0.68),  # Ørsted -50 bps
            (3.0, 0, -0.1),     # Conservative 0 bps
        ]:
            result = run(_corp(sentiment), _aud(delta_ri, 0.74, arb_flag=arb))
            bps = result["valuation_impact_bps"]
            assert abs(result["implied_wacc_modifier"] - bps / 10_000) < 1e-9

    def test_valuation_action_contains_bps_value(self):
        """valuation_action string references the exact bps value for auditing."""
        result = run(
            _corp(0.54),
            _aud(9.646, 0.74, arb_flag=1, delta_scope3=0.0, capex_val=-55.7),
        )
        assert "150" in result["valuation_action"]

    def test_orsted_action_contains_green_premium_bps(self):
        """Ørsted valuation_action references −50 bps."""
        result = run(
            _corp(0.68),
            _aud(-0.875, 0.88, arb_flag=0, delta_scope3=-56.0, capex_val=95.0),
        )
        assert "-50" in result["valuation_action"] or "−50" in result["valuation_action"]

    def test_valuation_action_contains_upgrade_keyword(self):
        """Ørsted valuation_action begins with UPGRADE."""
        result = run(
            _corp(0.68),
            _aud(-0.875, 0.88, arb_flag=0, delta_scope3=-56.0, capex_val=95.0),
        )
        assert "UPGRADE" in result["valuation_action"]

    def test_valuation_action_contains_downgrade_keyword(self):
        """Shell valuation_action begins with DOWNGRADE."""
        result = run(
            _corp(0.54),
            _aud(9.646, 0.74, arb_flag=1, delta_scope3=0.0, capex_val=-55.7),
        )
        assert "DOWNGRADE" in result["valuation_action"]

    def test_conservative_action_contains_hold(self):
        """CONSERVATIVE SIGNALLING valuation_action contains HOLD."""
        result = run(_corp(-0.1), _aud(3.0, 0.5))
        assert "HOLD" in result["valuation_action"]

    def test_output_schema_includes_all_valuation_keys(self):
        """ScepticAgent output always includes all three valuation keys."""
        result = run(_corp(0.5), _aud(5.0, 0.74))
        assert "valuation_impact_bps"  in result
        assert "implied_wacc_modifier" in result
        assert "valuation_action"      in result

    def test_valuation_impact_bps_is_integer(self):
        """valuation_impact_bps is always an integer (clean bps value)."""
        for delta_ri, arb, sentiment in [
            (9.646, 1, 0.54),
            (-0.875, 0, 0.68),
            (0.5, 0, 0.5),
        ]:
            result = run(_corp(sentiment), _aud(delta_ri, 0.74, arb_flag=arb))
            assert isinstance(result["valuation_impact_bps"], int)

    def test_benchmark_wacc_spread_is_200_bps(self):
        """Shell +150 bps minus Ørsted −50 bps = 200 bps total pricing spread."""
        shell_result  = run(_corp(0.54), _aud(9.646, 0.74, arb_flag=1,
                                              delta_scope3=0.0, capex_val=-55.7))
        orsted_result = run(_corp(0.68), _aud(-0.875, 0.88, arb_flag=0,
                                              delta_scope3=-56.0, capex_val=95.0))
        spread = shell_result["valuation_impact_bps"] - orsted_result["valuation_impact_bps"]
        assert spread == 200, (
            f"Expected 200 bps spread (150 - (-50)), got {spread}. "
            "This validates the full pricing range of the MAD Protocol."
        )


# ═══════════════════════════════════════════════════════════════════════════════
# 7. Temporal Trajectory & Inflection Analysis
# ═══════════════════════════════════════════════════════════════════════════════

def _shell_records_with_2021() -> list:
    """Minimal Shell audit records including the 2021 inflection-year node."""
    def _row(yr, val):
        return {
            "metric": "Total energy consumption",
            "value":  str(val),
            "unit":   "million MWh",
            "year":   str(yr),
            "source_citation": "Test",
            "source_url":      "https://example.com",
        }
    return [_row(2015, 1_130_000), _row(2021, 4_500_000), _row(2024, 12_030_000)]


def _orsted_records_with_2021() -> list:
    """Minimal Ørsted audit records including the 2021 node."""
    fuel = "Total energy consumption"
    def _row(yr, val):
        return {
            "metric": fuel,
            "value":  str(val),
            "unit":   "TJ",
            "year":   str(yr),
            "source_citation": "Test",
            "source_url":      "https://example.com",
        }
    return [_row(2015, 120_000), _row(2021, 60_000), _row(2024, 15_000)]


class TestTrajectoryAnalysis:
    """Time-Series Event Study: tri-node slope calculations and inflection flag."""

    def test_trajectory_unavailable_without_2021_sentiment(self):
        """When sentiment_2021 is None, trajectory returns available=False."""
        corp = _corp(0.54)   # No sentiment_2021 set (default None)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        result = run(corp, aud)
        assert result["trajectory"]["available"] is False

    def test_trajectory_unavailable_without_2021_records(self):
        """When raw_records has no 2021 row, trajectory returns available=False."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=[])  # no 2021 record
        result = run(corp, aud)
        assert result["trajectory"]["available"] is False

    def test_shell_trajectory_available_with_full_data(self):
        """Full Shell data (3 nodes) → trajectory available=True."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        result = run(corp, aud)
        assert result["trajectory"]["available"] is True

    def test_shell_sentiment_slope_pre_correct(self):
        """Pre-2021 sentiment slope = (0.40 - 0.18) / 6 = +0.0367/yr."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        assert abs(t["sentiment_slope_pre"] - (0.40 - 0.18) / 6) < 1e-5

    def test_shell_sentiment_slope_post_correct(self):
        """Post-2021 sentiment slope = (0.72 - 0.40) / 3 = +0.1067/yr."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        assert abs(t["sentiment_slope_post"] - (0.72 - 0.40) / 3) < 1e-5

    def test_shell_resource_slope_pre_correct(self):
        """Pre-2021 resource slope = (4.5M - 1.13M) / 6 ≈ +561,667 TJ/yr."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        expected = (4_500_000 - 1_130_000) / 6
        assert abs(t["ri_slope_pre"] - expected) < 1.0

    def test_shell_resource_slope_post_correct(self):
        """Post-2021 resource slope = (12.03M - 4.5M) / 3 = +2,510,000 TJ/yr."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        expected = (12_030_000 - 4_500_000) / 3
        assert abs(t["ri_slope_post"] - expected) < 1.0

    def test_shell_post_slope_greater_than_pre_sentiment(self):
        """Shell: post-2021 sentiment slope > pre-2021 slope (narrative accelerates)."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        assert t["sentiment_slope_post"] > t["sentiment_slope_pre"]
        assert t["cond_sentiment_accel"] is True

    def test_shell_post_slope_greater_than_pre_resource(self):
        """Shell: post-2021 resource slope > pre-2021 slope (surge accelerates)."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        assert t["ri_slope_post"] > t["ri_slope_pre"]
        assert t["cond_resource_accel"] is True

    def test_shell_textbook_event_driven_greenwashing_flag(self):
        """Shell with arb_flag=1 + both slopes accelerating → TEXTBOOK EVENT-DRIVEN GREENWASHING."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        assert t["event_driven_greenwashing"] is True
        assert t["inflection_flag"] == "TEXTBOOK EVENT-DRIVEN GREENWASHING"

    def test_no_greenwashing_without_jurisdictional_arbitrage(self):
        """Slopes accelerate but arb_flag=0 → NOT textbook greenwashing."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=0, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        assert t["event_driven_greenwashing"] is False
        assert t["inflection_flag"] != "TEXTBOOK EVENT-DRIVEN GREENWASHING"

    def test_orsted_consistent_transition_trajectory(self):
        """Ørsted: resource reduction accelerates (good), arb=0 → CONSISTENT TRANSITION."""
        corp = _corp(0.68, sentiment_2015=0.20, sentiment_2021=0.70, sentiment_2024=0.88)
        aud  = _aud(-0.875, 0.88, arb_flag=0,
                    raw_records=_orsted_records_with_2021(),
                    company_name="orsted")
        t    = run(corp, aud)["trajectory"]
        if t["available"]:
            assert t["event_driven_greenwashing"] is False
            # Resource slope should be negative (reduction) in both periods
            assert t["ri_slope_pre"]  < 0
            assert t["ri_slope_post"] < 0

    def test_trajectory_output_schema(self):
        """Trajectory dict contains all required keys when available=True."""
        corp = _corp(0.54, sentiment_2015=0.18, sentiment_2021=0.40, sentiment_2024=0.72)
        aud  = _aud(9.646, 0.74, arb_flag=1, raw_records=_shell_records_with_2021())
        t    = run(corp, aud)["trajectory"]
        assert t["available"] is True
        required = {
            "years", "event_label",
            "sentiment_2015", "sentiment_2021", "sentiment_2024",
            "sentiment_slope_pre", "sentiment_slope_post", "cond_sentiment_accel",
            "resource_2015", "resource_2021", "resource_2024",
            "ri_slope_pre", "ri_slope_post", "cond_resource_accel",
            "cond_arb", "event_driven_greenwashing", "inflection_flag",
        }
        assert required.issubset(t.keys())

    def test_trajectory_in_run_output_schema(self):
        """run() always returns a 'trajectory' key."""
        result = run(_corp(0.5), _aud(5.0, 0.74))
        assert "trajectory" in result
        assert "available" in result["trajectory"]


# ═══════════════════════════════════════════════════════════════════════════════
# 8. Dual-Model Bias Guard — Conservative Consensus Selection
# ═══════════════════════════════════════════════════════════════════════════════

class TestBiasGuard:
    """Dual-model consensus score selection and HIGH AMBIGUITY flag logic."""

    def _run_with_bias(
        self, openai_2024: float, anthropic_2024: float,
        openai_2015: float = 0.18, anthropic_2015: float = 0.20,
        arb: int = 0,
    ) -> dict:
        """Build a corp stub that mimics the dual-model consensus output."""
        # Conservative: min() for each year node
        consensus_2024 = min(openai_2024, anthropic_2024)
        consensus_2015 = min(openai_2015, anthropic_2015)
        variance_2024  = abs(openai_2024 - anthropic_2024)
        high_flag      = variance_2024 > 0.15

        corp = _corp(
            delta_sentiment = consensus_2024 - consensus_2015,
            sentiment_2015  = consensus_2015,
            sentiment_2024  = consensus_2024,
        )
        corp["max_ai_variance"]     = variance_2024
        corp["high_ambiguity_flag"] = high_flag
        corp["dual_model_active"]   = True
        corp["score_openai_2024"]   = openai_2024
        corp["score_anthropic_2024"] = anthropic_2024
        corp["ai_variance_2024"]    = variance_2024

        aud = _aud(9.646, 0.74, arb_flag=arb)
        return run(corp, aud)

    def test_conservative_selection_lower_score_used(self):
        """Consensus score = min(OpenAI, Anthropic) for 2024 node."""
        result = self._run_with_bias(openai_2024=0.72, anthropic_2024=0.65)
        # consensus_2024 = 0.65; consensus_2015 = min(0.18, 0.20) = 0.18
        # delta = 0.65 - 0.18 = 0.47
        fi = result["formula_inputs"]
        assert abs(fi["delta_narrative_sentiment"] - (0.65 - 0.18)) < 1e-4

    def test_high_ambiguity_flag_triggered_above_threshold(self):
        """HIGH AMBIGUITY flag set when |OpenAI - Anthropic| > 0.15."""
        result = self._run_with_bias(openai_2024=0.40, anthropic_2024=0.56)
        assert result["high_ambiguity_flag"] is True
        assert result["max_ai_variance"] > 0.15

    def test_low_variance_no_ambiguity_flag(self):
        """LOW VARIANCE: flag = False when |difference| < 0.15."""
        result = self._run_with_bias(openai_2024=0.72, anthropic_2024=0.65)
        assert result["high_ambiguity_flag"] is False
        assert result["max_ai_variance"] < 0.15

    def test_conservative_does_not_increase_id_beyond_single_model(self):
        """Conservative consensus I_d ≤ single-model I_d (fiduciary protection)."""
        # Single model: delta = 0.72 - 0.18 = 0.54
        single = run(_corp(0.54, sentiment_2015=0.18, sentiment_2024=0.72),
                     _aud(9.646, 0.74, arb_flag=0))
        # Conservative: delta = 0.65 - 0.18 = 0.47
        dual   = self._run_with_bias(openai_2024=0.72, anthropic_2024=0.65)
        assert dual["integrity_discount"] <= single["integrity_discount"]

    def test_high_ambiguity_with_arb_still_high_risk(self):
        """HIGH AMBIGUITY + conservative score + arb → still HIGH-RISK (robust verdict)."""
        result = self._run_with_bias(openai_2024=0.40, anthropic_2024=0.56, arb=1)
        # Conservative 2024 = min(0.40, 0.56) = 0.40
        # Conservative 2015 = min(0.18, 0.20) = 0.18
        # delta = 0.22; ΔRI = 9.646; denom = 7.14; I_d = 0.031 → MODERATE + arb → HIGH
        assert result["risk_level"] == "HIGH"

    def test_dual_model_fields_in_output(self):
        """run() with dual-model corp output includes bias guard fields."""
        result = self._run_with_bias(0.72, 0.65)
        assert "max_ai_variance"     in result
        assert "high_ambiguity_flag" in result
        assert "dual_model_active"   in result


# ═══════════════════════════════════════════════════════════════════════════════
# 9. Sensitivity Engine — Fiduciary Margin of Safety
# ═══════════════════════════════════════════════════════════════════════════════

class TestSensitivityEngine:
    """compute_sensitivity() tipping-point and scenario correctness."""

    def _run_sensitivity(
        self,
        sentiment_2024: float = 0.65,
        sentiment_2015: float = 0.18,
        resource_2015:  float = 1_130_000,
        resource_2024:  float = 12_030_000,
        dd:             float = 0.74,
        arb_flag:       int   = 1,
    ) -> dict:
        from agents.sceptic_agent import compute_sensitivity
        return compute_sensitivity(
            consensus_sentiment_2024 = sentiment_2024,
            sentiment_2015           = sentiment_2015,
            resource_2015            = resource_2015,
            resource_2024            = resource_2024,
            disclosure_density       = dd,
            arb_flag                 = arb_flag,
        )

    def test_margin_of_safety_shell_90_pct(self):
        """Shell requires ~90.6% gas reduction to hit tipping point."""
        result = self._run_sensitivity()
        # MoS = (12.03M - 1.13M) / 12.03M ≈ 90.6%
        assert abs(result["margin_of_safety_pct"] - 90.6) < 0.5

    def test_tipping_gas_equals_baseline(self):
        """Tipping point gas = baseline 2015 gas (ΔRI = 0 when gas_2024 = gas_2015)."""
        result = self._run_sensitivity()
        assert abs(result["tipping_gas_mtj"] - 1.13) < 0.01

    def test_current_gas_correct(self):
        """Current gas stored correctly."""
        result = self._run_sensitivity()
        assert abs(result["current_gas_mtj"] - 12.03) < 0.01

    def test_no_div_zero_in_scenarios(self):
        """Scenarios never crash with ZeroDivisionError — graceful DIV/0 handling."""
        result = self._run_sensitivity()
        for sc in result["scenarios"]:
            if sc.get("is_tipping"):
                assert sc["id"] is None   # graceful None, not exception
            else:
                assert sc["id"] is not None or sc.get("is_tipping")

    def test_zero_pct_scenario_is_current_state(self):
        """0% reduction scenario matches current WACC (+150 bps with arb)."""
        result  = self._run_sensitivity()
        current = next(sc for sc in result["scenarios"] if sc["pct_reduction"] == 0)
        assert current["wacc_bps"] == 150

    def test_91pct_reduction_achieves_minus_50bps(self):
        """−91% reduction (ΔRI < 0) → AUTHENTIC TRANSITION LEADER → -50 bps.

        AUTHENTIC TRANSITION LEADER does NOT get Jurisdictional Arbitrage escalation
        (early-return branch in _classify). The green premium is achievable once
        gas drops below the 2015 baseline, regardless of the arb flag.
        """
        result = self._run_sensitivity()
        post_tp = [sc for sc in result["scenarios"]
                   if sc.get("pct_reduction", 0) >= 91 and not sc.get("is_tipping")]
        if post_tp:
            assert post_tp[0]["wacc_bps"] == -50  # AUTHENTIC LEADER branch: no arb penalty

    def test_no_arb_allows_minus_50bps_post_tipping(self):
        """−91% reduction with arb_flag=0 → −50 bps (full green premium)."""
        result = self._run_sensitivity(arb_flag=0)
        post_tp = [sc for sc in result["scenarios"]
                   if sc.get("pct_reduction", 0) >= 91 and not sc.get("is_tipping")]
        if post_tp:
            assert post_tp[0]["wacc_bps"] == -50

    def test_best_achievable_bps_with_arb_is_minus_50(self):
        """With arb_flag=1, best achievable is -50 bps.

        AUTHENTIC TRANSITION LEADER classification uses the early-return branch
        in _classify, which does not apply the Jurisdictional Arbitrage escalation.
        Once ΔRI < 0 (gas below 2015 baseline), full green premium applies.
        """
        result = self._run_sensitivity(arb_flag=1)
        assert result["best_achievable_bps"] == -50

    def test_best_achievable_bps_without_arb(self):
        """Without arb_flag, best achievable = −50 bps (green premium)."""
        result = self._run_sensitivity(arb_flag=0)
        assert result["best_achievable_bps"] == -50

    def test_all_positive_ri_scenarios_are_150_bps(self):
        """All scenarios with ΔRI > 0 and arb_flag=1 yield +150 bps."""
        result = self._run_sensitivity()
        for sc in result["scenarios"]:
            if sc.get("delta_ri_pct") and sc["delta_ri_pct"] > 0:
                assert sc["wacc_bps"] == 150

    def test_structural_note_mentions_arb(self):
        """Structural note explicitly mentions Jurisdictional Arbitrage floor."""
        result = self._run_sensitivity(arb_flag=1)
        assert "Arbitrage" in result["structural_note"] or "arb" in result["structural_note"].lower()

    def test_scenarios_output_schema(self):
        """Each scenario dict contains required keys."""
        result = self._run_sensitivity()
        required = {"pct_reduction", "gas_mtj", "delta_ri_pct"}
        for sc in result["scenarios"]:
            assert required.issubset(sc.keys())
