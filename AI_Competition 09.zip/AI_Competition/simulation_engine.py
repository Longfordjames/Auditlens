# MIT License — see LICENSE file
"""
AuditLens Counterfactual "What-If" Simulation Engine
======================================================
Enables Portfolio Managers to test hypothetical operational scenarios and
observe how the Integrity Discount ($I_d$) and WACC penalty respond to
fundamental changes — without altering any production data or LLM calls.

Design principles:
  • 100% deterministic — re-uses the ScepticAgent formula directly.
  • 100% offline — no API calls, no CSV writes (read-only extraction).
  • Additive only — does NOT modify existing report data or CSV files.
  • CFA Rule 4.4 compliant — reproducible at $0 cost.

Core scenario (the "Stayed in Holland" counterfactual):
  Shell PLC received a Dutch court ruling (Milieudefensie, 2021) mandating
  a 45% absolute reduction in Scope 3 emissions.  After UK reincorporation,
  this obligation became voluntary.  The simulator asks:
    "If Shell had complied with the original 45% upstream reduction mandate,
     how would its I_d and WACC penalty change?"

  Inputs used (from existing CSV / report — no new data):
    • Baseline fuel (2015): from auditor_output['raw_records'] or direct arg.
    • Current fuel (2024):  from auditor_output.
    • Simulated fuel:       current × (1 − reduction_pct/100).
    • All other inputs (ΔSentiment, Disclosure Density, arb_flag) unchanged.
"""

from __future__ import annotations

import logging
import math
from typing import Dict, Optional, Tuple

logger = logging.getLogger("SIMULATION_ENGINE")

# ── Default Shell scenario constants ─────────────────────────────────────────
_SHELL_FUEL_2015  = 1_130_000.0   # TJ — Shell Sustainability Report 2015, p.42
_SHELL_FUEL_2024  = 12_030_000.0  # TJ — Shell Annual Report 2024, p.78
_DUTCH_MANDATE_PCT = 45.0          # % absolute operational reduction (Milieudefensie ruling)

# Reasonable epsilon to prevent division-by-zero in delta RI
_RI_EPSILON = 1e-9


def compute_simulated_ri(
    fuel_2015:     float,
    fuel_2024_sim: float,
) -> float:
    """
    Recompute ΔResource Intensity under a simulated 2024 fuel value.

    Parameters
    ----------
    fuel_2015     : float  Baseline fuel consumption (TJ).
    fuel_2024_sim : float  Simulated current fuel consumption (TJ).

    Returns
    -------
    float  Simulated ΔRI = (fuel_sim − fuel_base) / fuel_base.
           Returns 0.0 if base is effectively zero (guarded).
    """
    if abs(fuel_2015) < _RI_EPSILON:
        logger.warning("SIMULATION  fuel_2015 ≈ 0 — returning ΔRI=0 (ε-guard).")
        return 0.0
    return (fuel_2024_sim - fuel_2015) / fuel_2015


def compute_simulated_id(
    delta_sentiment:  float,
    delta_ri_sim:     float,
    disclosure_dens:  float,
) -> Tuple[float, float, bool]:
    """
    Compute I_d under simulated ΔResource Intensity.

    Delegates to :func:`agents.sceptic_agent.effective_id_denominator` so the
    simulator matches ScepticAgent degenerate-denominator policy.
    """
    from agents.sceptic_agent import effective_id_denominator

    denom_eff, _raw, guard = effective_id_denominator(
        delta_ri_sim, disclosure_dens, delta_sentiment,
    )
    id_sim = round(delta_sentiment / denom_eff, 6)
    return id_sim, denom_eff, guard


def _classify_sim(
    id_sim:     float,
    delta_ri:   float,
    delta_sent: float,
    arb_flag:   int,
) -> Tuple[str, str, int]:
    """
    Classify risk and compute WACC bps for the simulated scenario.

    Mirrors ScepticAgent._classify + _compute_wacc_impact logic
    without importing those private functions, to keep the simulator
    fully self-contained and testable in isolation.

    Returns
    -------
    Tuple[str, str, int]
        (risk_flag, risk_level, wacc_bps)
    """
    from agents.sceptic_agent import _classify, _compute_wacc_impact

    # Build a minimal cross-checks list for the WACC lookup
    mock_checks = [{"triggered": bool(arb_flag), "rule": "Jurisdictional Arbitrage"}]
    risk_flag, risk_level, _ = _classify(id_sim, delta_sent, delta_ri, arb_flag)
    wacc_info  = _compute_wacc_impact(risk_flag, mock_checks)
    return risk_flag, risk_level, wacc_info["valuation_impact_bps"]


def run_counterfactual_simulation(
    company_name:       str,
    target_metric:      str,
    reduction_pct:      float,
    current_report_data: dict,
    fuel_2015_override: Optional[float] = None,
) -> dict:
    """
    Simulate the effect of a hypothetical operational reduction on I_d and WACC.

    Parameters
    ----------
    company_name         : str    Company identifier (e.g. "shell").
    target_metric        : str    Human-readable name of the metric being changed.
    reduction_pct        : float  Percentage reduction to apply to current fuel
                                  (e.g. 45.0 → simulate a 45% cut from 2024 value).
    current_report_data  : dict   Full report dict from ``_build_report()`` or
                                  a dict with keys 'layers' and 'verdict'.
    fuel_2015_override   : float  Optional: override the 2015 baseline if not
                                  available in raw_records (uses CSV constant).

    Returns
    -------
    dict
        Keys: ``scenario_label``, ``company_name``, ``target_metric``,
        ``reduction_pct``, ``fuel_2015``, ``fuel_2024_original``,
        ``fuel_2024_simulated``, ``delta_ri_original``, ``delta_ri_simulated``,
        ``delta_sentiment``, ``disclosure_density``, ``arb_flag``,
        ``id_original``, ``id_simulated``, ``id_delta``,
        ``wacc_bps_original``, ``wacc_bps_simulated``, ``wacc_bps_delta``,
        ``risk_flag_original``, ``risk_flag_simulated``,
        ``risk_level_original``, ``risk_level_simulated``,
        ``epsilon_guard``, ``interpretation``.
    """
    # ── Unpack inputs ──────────────────────────────────────────────────────────
    layers  = current_report_data.get("layers", {})
    verdict = current_report_data.get("verdict", {})
    corp    = layers.get("corporate_agent", {})
    aud     = layers.get("auditor_agent", {})
    sceptic = layers.get("sceptic_agent", {})

    fi   = sceptic.get("formula_inputs", {})
    delta_sentiment = fi.get("delta_narrative_sentiment",
                             corp.get("delta_narrative_sentiment", 0.0))
    disclosure_dens = fi.get("disclosure_density",
                             aud.get("disclosure_density", 0.74))
    arb_flag        = aud.get("jurisdictional_arbitrage", 0)
    delta_ri_orig   = fi.get("delta_resource_intensity",
                             aud.get("delta_resource_intensity", 0.0))
    id_orig         = verdict.get("integrity_discount",
                                  sceptic.get("integrity_discount", 0.0))
    wacc_orig       = verdict.get("valuation_impact_bps",
                                  sceptic.get("valuation_impact_bps", 0))
    risk_flag_orig  = verdict.get("risk_flag",
                                  sceptic.get("risk_flag", ""))
    risk_lvl_orig   = (verdict.get("risk_level")
                       or sceptic.get("risk_level", ""))

    # ── Recover actual fuel values ─────────────────────────────────────────────
    # Try raw_records first, then fall back to formula derivation
    raw = current_report_data.get("raw_records") or aud.get("raw_records") or []

    fuel_2015 = fuel_2015_override
    fuel_2024_orig: Optional[float] = None

    for r in raw:
        metric_lc = r.get("metric", "").strip().lower()
        if "upstream" in metric_lc or "fuel" in metric_lc or "hydrocarbon" in metric_lc:
            yr  = int(r.get("year", 0))
            val = float(r.get("value", 0))
            if yr == 2015 and fuel_2015 is None:
                fuel_2015 = val
            elif yr == 2024:
                fuel_2024_orig = val

    # Fallbacks using company defaults (Shell)
    if fuel_2015 is None:
        fuel_2015 = _SHELL_FUEL_2015
        logger.warning("SIMULATION  fuel_2015 not found in raw_records — using default %.0f TJ", fuel_2015)

    if fuel_2024_orig is None:
        # Reconstruct from ΔRI definition: fuel_2024 = fuel_2015 × (1 + ΔRI)
        if isinstance(delta_ri_orig, float) and abs(delta_ri_orig) > 1e-9:
            fuel_2024_orig = fuel_2015 * (1.0 + delta_ri_orig)
        else:
            fuel_2024_orig = _SHELL_FUEL_2024
        logger.warning("SIMULATION  fuel_2024 not found in raw_records — reconstructed to %.0f TJ", fuel_2024_orig)

    # ── Simulated fuel value ───────────────────────────────────────────────────
    fuel_2024_sim = fuel_2024_orig * (1.0 - reduction_pct / 100.0)
    fuel_2024_sim = max(fuel_2024_sim, 0.0)   # cannot be negative

    # ── Recompute ΔRI and I_d ─────────────────────────────────────────────────
    delta_ri_sim              = compute_simulated_ri(fuel_2015, fuel_2024_sim)
    id_sim, _, eps_guard      = compute_simulated_id(delta_sentiment, delta_ri_sim, disclosure_dens)

    # ── Reclassify risk and WACC ──────────────────────────────────────────────
    try:
        risk_flag_sim, risk_lvl_sim, wacc_sim = _classify_sim(
            id_sim, delta_ri_sim, delta_sentiment, arb_flag,
        )
    except Exception as exc:
        logger.warning("SIMULATION  risk classification failed: %s", exc)
        risk_flag_sim = "CLASSIFICATION FAILED"
        risk_lvl_sim  = "UNKNOWN"
        wacc_sim      = 0

    # ── Delta metrics ─────────────────────────────────────────────────────────
    id_delta   = round(id_sim - id_orig, 6)
    wacc_delta = wacc_sim - wacc_orig

    # ── Human-readable interpretation ─────────────────────────────────────────
    # After "would", use base verbs (not past participles): "would worsen", "would improve".
    direction_verb = "improve" if id_delta < 0 or wacc_delta < 0 else "worsen"
    interp = (
        f"If {company_name.title()} had achieved a {reduction_pct:.0f}% reduction in "
        f"'{target_metric}' (from {fuel_2024_orig/1e6:.2f}M TJ to "
        f"{fuel_2024_sim/1e6:.2f}M TJ), its I_d would {direction_verb} from "
        f"{id_orig:+.4f} to {id_sim:+.4f} (Δ = {id_delta:+.4f}), and its "
        f"WACC penalty would change by {wacc_delta:+d} bps "
        f"(from {'+' if wacc_orig>0 else ''}{wacc_orig} bps to "
        f"{'+' if wacc_sim>0 else ''}{wacc_sim} bps). "
        f"Risk classification: {risk_flag_orig} → {risk_flag_sim}."
    )

    logger.info("SIMULATION  [%s]  %s", company_name.upper(), interp)

    return {
        "scenario_label":       f"{company_name} — {reduction_pct:.0f}% {target_metric} reduction",
        "company_name":         company_name,
        "target_metric":        target_metric,
        "reduction_pct":        reduction_pct,
        "fuel_2015":            fuel_2015,
        "fuel_2024_original":   fuel_2024_orig,
        "fuel_2024_simulated":  fuel_2024_sim,
        "delta_ri_original":    round(delta_ri_orig, 6),
        "delta_ri_simulated":   round(delta_ri_sim, 6),
        "delta_ri_pct_original": round(delta_ri_orig * 100, 2),
        "delta_ri_pct_simulated": round(delta_ri_sim * 100, 2),
        "delta_sentiment":      delta_sentiment,
        "disclosure_density":   disclosure_dens,
        "arb_flag":             arb_flag,
        "id_original":          round(id_orig, 6),
        "id_simulated":         round(id_sim, 6),
        "id_delta":             id_delta,
        "wacc_bps_original":    wacc_orig,
        "wacc_bps_simulated":   wacc_sim,
        "wacc_bps_delta":       wacc_delta,
        "risk_flag_original":   risk_flag_orig,
        "risk_flag_simulated":  risk_flag_sim,
        "risk_level_original":  risk_lvl_orig,
        "risk_level_simulated": risk_lvl_sim,
        "epsilon_guard":        eps_guard,
        "interpretation":       interp,
    }


def run_dutch_mandate_scenario(report_data: dict, company_name: str = "shell") -> dict:
    """
    Pre-built "Stayed in Holland" scenario: 45% upstream fuel reduction.

    Mirrors the Milieudefensie court mandate Shell avoided via UK relocation.
    """
    return run_counterfactual_simulation(
        company_name        = company_name,
        target_metric       = "Upstream Natural Gas Fuel Consumption",
        reduction_pct       = _DUTCH_MANDATE_PCT,
        current_report_data = report_data,
    )
