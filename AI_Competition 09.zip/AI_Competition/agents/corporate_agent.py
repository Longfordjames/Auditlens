# MIT License — see LICENSE file
"""
CorporateAgent — Layer 1 (Neural / Glass-Box Linguistic Attribution)
=====================================================================
Extracts a deterministic, verbatim-anchored Linguistic Attribution Record from
publicly available corporate communications.

XAI Design (Responsible AI / CFA Stage 3 — Transparency):
  • Extracts exact verbatim substrings from source text for each evidence category.
  • Anti-hallucination directives embedded in the prompt enforce zero paraphrasing.
  • temperature=0.0 (deterministic inference) — ethically mandated for fiduciary use.
  • Backward-compatible parser handles both Glass-Box (XAI v2) and legacy (v1) schemas.

Output JSON Schema (XAI v2 — Glass-Box):
  {
    "sentiment_score":              float [-1.0, 1.0],
    "narrative_hedging_phrases":    list[str]  -- VERBATIM substrings from source text,
    "transition_aligned_phrases":   list[str]  -- VERBATIM substrings from source text,
    "reasoning_trace":              str        -- synthesis sentence
  }

Legacy Schema (v1 — backward-compatible fallback):
  {
    "narrative_sentiment_score":    float,
    "reasoning":                    str
  }
  If a v1-format response is found in the cache, a XAI advisory is emitted and
  phrase lists are returned as empty (no crash, graceful degradation).

Supported companies (CFA Rule 4.6 — 100% public sources):
  Shell PLC — Shell Annual Report 2024, Shell Sustainability Report 2024
  Ørsted A/S — Ørsted Annual Report 2024, Ørsted ESG Performance Report 2024
  TotalEnergies SE — Universal Registration Document (English), AMF-filed PDFs on totalenergies.com
"""

import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.audit_profile import get_event_study
from llm_wrapper import llm_call, ANTHROPIC_MODEL

_BLUE   = "\033[34m"
_YELLOW = "\033[33m"
_GREEN  = "\033[32m"
_RED    = "\033[31m"
_RESET  = "\033[0m"
_BOLD   = "\033[1m"

logger = logging.getLogger("CORPORATE_AGENT")

# XAI schema fields required in the new Glass-Box response format.
# Used by llm_wrapper to detect legacy cache entries.
XAI_REQUIRED_FIELDS = [
    "sentiment_score",
    "narrative_hedging_phrases",
    "transition_aligned_phrases",
    "reasoning_trace",
]


# ── Shell PLC — Public source text excerpts ───────────────────────────────────

_SHELL_2024_EXCERPTS = """
[SOURCE: Shell Annual Report 2024, CEO Statement, p.3]
"We are accelerating our transition to a lower-carbon energy system. Our
net-zero emissions ambition by 2050 remains central to our strategy. In 2024,
we continued to invest in low-carbon energy solutions, including renewable power,
hydrogen, and nature-based solutions, while ensuring we supply the energy the
world needs today. Our disciplined capital allocation framework ensures we deliver
competitive returns to shareholders while funding the energy transition."

[SOURCE: Shell Sustainability Report 2024, CEO Foreword, p.2]
"Shell's ESG disclosure score of 74 reflects our commitment to transparency and
stakeholder engagement. We have published detailed Scope 1, 2, and 3 emissions
data alongside our transition pathway, demonstrating our ambition to be a
net-zero energy business by 2050, in step with society."

[SOURCE: Shell Strategic Update 2024, Capital Allocation Section, p.12]
"Our Powering Progress strategy balances short-term energy security with
long-term decarbonisation. We remain committed to our disciplined capital
framework, allocating resources to the highest-value opportunities across
both conventional and low-carbon energy."
"""

_SHELL_2015_EXCERPTS = """
[SOURCE: Shell Annual Report 2015, CEO Statement, p.4]
"Shell remains committed to responsible energy production while maintaining
operational efficiency across our upstream portfolio. We continue to invest in
conventional energy resources to meet global demand, while exploring options for
a lower-carbon future. Our priority is delivering value for shareholders through
disciplined capital management in a challenging commodity environment."
"""

# ── Shell PLC — 2021 Inflection Year (Dutch Court Ruling) ────────────────────
# Milieudefensie et al. v. Royal Dutch Shell, May 2021 ruling mandated a 45%
# absolute carbon reduction. Shell's response narrative represents the critical
# inflection point where compliance language began decoupling from operations.

_SHELL_2021_EXCERPTS = """
[SOURCE: Shell Energy Transition Strategy 2021, CEO Statement, p.2]
"Following the Dutch District Court ruling in May 2021, Shell is committed to
intensifying our energy transition. We will reduce the net carbon intensity of
our energy products by 30% by 2035 and 65% by 2050. Our restructuring initiative
will sharpen our focus on our customers and the transition to net-zero. We are
making the necessary changes to become a net-zero energy business by 2050,
in step with society."

[SOURCE: Shell Annual Report 2021, Strategic Report, p.12]
"Shell's updated Scope 3 emissions reduction pathway is aligned with our Powering
Progress strategy. We have published updated Net Carbon Intensity targets in
response to the court judgment and shareholder expectations, reaffirming our
commitment to play our part in the energy transition while delivering long-term
shareholder value."
"""


# ── Ørsted A/S — Public source text excerpts ─────────────────────────────────

_ORSTED_2024_EXCERPTS = """
[SOURCE: Ørsted Annual Report 2024, CEO Statement, p.4]
"We have fundamentally transformed from a fossil fuel company into a global
leader in green energy. Our renewable capacity has grown to represent the
overwhelming majority of our generation, with offshore wind as our core business.
We remain fully committed to our science-based targets: carbon neutrality across
our own operations by 2025 and across our entire value chain by 2040. Our
transition is not a narrative — it is a measurable, verifiable capital reality."

[SOURCE: Ørsted ESG Performance Report 2024, CEO Foreword, p.2]
"We have reduced our coal and natural gas generation fuel consumption by over
87% since 2015, reflecting our structural and irreversible exit from fossil fuel
generation. Our Scope 3 emissions have declined by over 56% across the same
period as our energy mix transitions to offshore wind and other renewables. We
maintain the highest ESG disclosure standards, driven by our EU-CSRD obligations
and our genuine commitment to transparency."

[SOURCE: Ørsted Capital Markets Day 2024, Strategic Priorities, p.8]
"Our capital allocation is decisively green: renewable investment now represents
substantially all of our annual capital expenditure. We have divested our legacy
oil and gas business and are fully committed to delivering the clean energy
transition at scale."
"""

_ORSTED_2015_EXCERPTS = """
[SOURCE: DONG Energy Annual Report 2015 (now Ørsted), CEO Statement, p.3]
"DONG Energy is committed to delivering reliable, affordable energy from our
diversified portfolio of coal, natural gas and wind power generation. We are
actively growing our offshore wind business and exploring opportunities to
gradually reduce our coal exposure, while maintaining our conventional generation
assets to ensure security of supply. Our financial performance reflects
disciplined management of our diversified energy mix in a challenging market."
"""

# ── Ørsted A/S — 2021 Inflection Year (Majority transition complete) ─────────
# By 2021, Ørsted had largely completed its coal exit. The 2021 communications
# reflect a company mid-transition, with offshore wind as the dominant business.

_ORSTED_2021_EXCERPTS = """
[SOURCE: Ørsted Annual Report 2021, CEO Statement, p.3]
"We have now divested substantially all of our oil and gas activities and have
exited most of our coal generation capacity, achieving our 2023 coal phase-out
target two years early. Offshore wind now accounts for the overwhelming majority
of our installed generation capacity. We have set a science-based target to
achieve carbon neutrality in our own operations by 2025. Our renewable energy
build-out is on track to reach 50 GW of installed capacity by 2030."

[SOURCE: Ørsted ESG Performance Report 2021, p.3]
"Our Scope 3 GHG emissions have declined materially as our generation mix
transitions decisively to renewable energy. We are fully aligned with the EU
taxonomy for sustainable finance and are committed to our Paris-compatible
1.5°C pathway, with annual disclosure under EU-CSRD standards."
"""


# ── Company narrative registry ────────────────────────────────────────────────

# ── BP plc — Public source text excerpts ─────────────────────────────────────

_BP_2024_EXCERPTS = """
[SOURCE: BP Annual Report 2024, CEO Statement, p.3]
"BP continues to advance our strategy to become a lower carbon energy company,
while ensuring we deliver the oil and gas the world needs today. Our investment
framework balances returns to shareholders with our transition commitments. We
remain fully committed to our net zero ambition, while maintaining the energy
security that our customers and societies depend on."

[SOURCE: BP Sustainability Report 2024, p.2 — CEO Foreword]
"Our focus is on delivering value while transforming BP for the energy transition.
We are growing our renewable and low-carbon business, including offshore wind and
green hydrogen, while responsibly managing our oil and gas production. We believe
a disciplined transition requires both ambition and pragmatism."
"""

_BP_2021_EXCERPTS = """
[SOURCE: BP Strategy Update 2021, CEO Statement, p.4]
"BP has set a net zero ambition for 2050 and we are transforming our business to
help deliver a net zero world. We have committed to reducing our oil and gas
production by 40% by 2030 and increasing our low carbon investment tenfold. We
are becoming an integrated energy company, moving from an international oil company
to an integrated energy company."
"""

_BP_2015_EXCERPTS = """
[SOURCE: BP Annual Report 2015, CEO Statement, p.3]
"BP remains committed to responsible energy development across our upstream portfolio.
We continue to invest in conventional oil and gas production to meet global energy
demand, while exploring renewable energy opportunities. Our priority is delivering
shareholder value through disciplined capital management in a challenging commodity
environment."
"""

# ── TotalEnergies SE — Public source text excerpts ────────────────────────────
# Verbatim from issuer PDFs (Universal Registration Document / Registration Document).
# Optional local mirror: Data_Input/reports/ (see Data_Input/README.md).

_TOTAL_2024_EXCERPTS = """
[SOURCE: TotalEnergies Universal Registration Document 2024 (incl. Annual Financial Report 2024, EN, filed Mar 2025), §1.1.1, document pp.6–7; PDF p.6]
"TotalEnergies is a global integrated energy company that produces and markets energies: oil and biofuels, natural gas, biogas and low-carbon hydrogen, renewables and electricity. Our more than 100,000 employees are committed to provide as many people as possible with energy that is more reliable, more affordable and more sustainable. Active in about 120 countries, TotalEnergies places sustainability at the heart of its strategy, its projects and its operations."

[SOURCE: TotalEnergies Universal Registration Document 2024 (EN), §1.1.2 Our history, document pp.10–11; PDF p.10]
"In an effort to meet the challenges of a largely net zero future, the Company is pursuing a new strategy to become an integrated energy company by developing its activities in electricity, mainly renewables, which will play a key role in the energy system of tomorrow's world. By changing its name to TotalEnergies in 2021, the Company has ensured that its identity reflects the strong ambition driving the Company, and is committed to a balanced transition strategy for the benefit of the energy transition. The pioneering spirit that has powered it since day one continues to guide it in achieving this transition."
"""

_TOTAL_2021_EXCERPTS = """
[SOURCE: TotalEnergies Universal Registration Document 2022 (incl. Annual Financial Report 2022, EN, filed Mar 2023), §1.1.2 Our history, document p.10; PDF p.10]
"The Company was founded on March 28, 1924. Historic player in energy it discovered major fields worldwide and developed an ever-growing number of advanced products and services, created in its refineries and marketed through its retail network. The Company has gradually diversified its activities and broadened its presence around the world. We have positioned ourselves in the gas, refining, petrochemical and petroleum product distribution segments. We have begun a transition towards renewable energies: solar, sustainable biofuels and electricity, mostly from renewable sources."

[SOURCE: TotalEnergies Universal Registration Document 2022 (EN), §1.2.1 Our strategy — integrated multi-energy Company, document pp.14–15; PDF p.14]
"That, in essence, is TotalEnergies' strategy: to continue providing the energy the world needs now, notably natural gas to replace coal, while responsibly and sustainably accelerating the transition to low carbon energy solutions. This is how, in practice we support to the goals of the Paris Agreement, which calls for reducing greenhouse gas emissions in the context of sustainable development and the fight against poverty, and which aims to keep the increase in average global temperatures well below 2°C compared to pre-industrial levels."
"""

_TOTAL_2015_EXCERPTS = """
[SOURCE: TOTAL S.A. Registration Document 2015 (English, filed Mar 2016), §1.2 Strategy, document pp.6–7; PDF pp.10–11]
"The Group's goal is to be a global energy company. TOTAL is a leading international oil and gas company, and is active in new energy sources, such as solar energy and biomass. To achieve this goal, TOTAL leverages its integrated business model, which enables it to capture synergies between the different business segments of the Group."

[SOURCE: TOTAL S.A. Registration Document 2015 (EN), §1.2 Strategy, document p.6; PDF p.10]
"This strategy incorporates the challenges of climate change, using the International Energy Agency 2°C scenario (450 ppm) as a point of reference. TOTAL's challenge is to contribute to satisfying the demand for energy of the world's growing population, while providing concrete solutions to limit the effects of climate change. To do so, the Group focuses its actions around several key points, including the development of gas and renewable energies."
"""


COMPANY_NARRATIVES: Dict[str, Dict[str, Any]] = {
    "shell": {
        "excerpts_2024": _SHELL_2024_EXCERPTS,
        "excerpts_2021": _SHELL_2021_EXCERPTS,
        "excerpts_2015": _SHELL_2015_EXCERPTS,
        "display_name":  "Shell PLC",
        "source_2024":   "Shell Annual Report 2024 p.3; Shell Sustainability Report 2024 p.2",
        "source_2021":   "Shell Energy Transition Strategy 2021 p.2; Shell Annual Report 2021 p.12",
        "source_2015":   "Shell Annual Report 2015 p.4",
        "source_url":    "https://reports.shell.com/annual-report/2024/",
        "source_url_2021": "https://reports.shell.com/sustainability-report/2021/",
    },
    "orsted": {
        "excerpts_2024": _ORSTED_2024_EXCERPTS,
        "excerpts_2021": _ORSTED_2021_EXCERPTS,
        "excerpts_2015": _ORSTED_2015_EXCERPTS,
        "display_name":  "Ørsted A/S",
        "source_2024":   "Ørsted Annual Report 2024 p.4; Ørsted ESG Performance Report 2024 p.2",
        "source_2021":   "Ørsted Annual Report 2021 p.3; Ørsted ESG Performance Report 2021 p.3",
        "source_2015":   "DONG Energy Annual Report 2015 p.3 (now Ørsted)",
        "source_url":    "https://orsted.com/en/investors/ir-material/annual-reports",
        "source_url_2021": "https://orsted.com/en/sustainability/esg-performance",
    },
    "bp": {
        "excerpts_2024": _BP_2024_EXCERPTS,
        "excerpts_2021": _BP_2021_EXCERPTS,
        "excerpts_2015": _BP_2015_EXCERPTS,
        "display_name":  "BP plc",
        "source_2024":   "BP Annual Report 2024 p.3; BP Sustainability Report 2024 p.2",
        "source_2021":   "BP Strategy Update 2021 p.4",
        "source_2015":   "BP Annual Report 2015 p.3",
        "source_url":    "https://www.bp.com/en/global/corporate/investors/results-and-reporting.html",
        "source_url_2021": "https://www.bp.com/en/global/corporate/sustainability/sustainability-reporting.html",
    },
    "totalenergies": {
        "excerpts_2024": _TOTAL_2024_EXCERPTS,
        "excerpts_2021": _TOTAL_2021_EXCERPTS,
        "excerpts_2015": _TOTAL_2015_EXCERPTS,
        "display_name":  "TotalEnergies SE",
        "source_2024":   "TotalEnergies Universal Registration Document 2024 (EN) §1.1.1 p.6; §1.1.2 p.10",
        "source_2021":   "TotalEnergies Universal Registration Document 2022 (EN) §1.1.2 p.10; §1.2.1 p.14",
        "source_2015":   "TOTAL S.A. Registration Document 2015 (EN) §1.2 Strategy pp.6–7",
        "source_url":    "https://totalenergies.com/system/files/documents/totalenergies_universal-registration-document-2024_2025_en.pdf",
        "source_url_2021": "https://totalenergies.com/sites/g/files/nytnzq121/files/documents/2023-03/TotalEnergies_URD_2022_EN.pdf",
    },
}


def _register_manifest_narratives(narratives_dir: Optional[Path] = None) -> None:
    """
    For each company in Data_Input/manifest.yaml, if ``narratives/{slug}_excerpts.yaml``
    defines all ``excerpts_*`` keys required by ``get_event_study(slug)``, register a
    minimal ``COMPANY_NARRATIVES`` entry (manifest-only issuers without hardcoded blocks).
    """
    from config.audit_profile import get_company_entry, get_event_study, load_manifest

    root = Path(__file__).resolve().parents[1]
    ndir = narratives_dir if narratives_dir is not None else root / "Data_Input" / "narratives"
    if not ndir.is_dir():
        return
    try:
        import yaml  # type: ignore
    except ImportError:
        return

    manifest = load_manifest()
    companies = manifest.get("companies") or {}
    try:
        from data_loader import SUPPORTED_COMPANIES
    except ImportError:
        SUPPORTED_COMPANIES = {}  # type: ignore[assignment]

    for slug in companies:
        if slug in COMPANY_NARRATIVES:
            continue
        ypath = ndir / f"{slug}_excerpts.yaml"
        if not ypath.is_file():
            continue
        try:
            with open(ypath, encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
        except (OSError, yaml.YAMLError) as exc:
            logger.warning(
                "MANIFEST NARRATIVES  Cannot read %s: %s", ypath.name, exc
            )
            continue
        if not isinstance(data, dict):
            continue

        ev = get_event_study(slug)
        y_base = int(ev["baseline_year"])
        y_curr = int(ev["current_year"])
        y_mid_raw = ev.get("mid_year")
        keys_needed: List[str] = [f"excerpts_{y_base}", f"excerpts_{y_curr}"]
        if y_mid_raw is not None:
            keys_needed.insert(1, f"excerpts_{int(y_mid_raw)}")

        if not all(data.get(k) for k in keys_needed):
            logger.warning(
                "MANIFEST NARRATIVES  %s: %s missing required keys %s — not registered.",
                slug,
                ypath.name,
                keys_needed,
            )
            continue

        ent = get_company_entry(slug)
        disp = (ent.get("display_name") or "").strip()
        if not disp:
            disp = SUPPORTED_COMPANIES.get(slug, slug.replace("_", " ").title())

        stub: Dict[str, Any] = {"display_name": disp}
        url = (data.get("source_url") or ent.get("default_source_url") or "").strip()
        if url:
            stub["source_url"] = url
        for k in keys_needed:
            stub[k] = str(data[k]).strip() + "\n"
        for opt in (
            "source_2024",
            "source_2021",
            "source_2015",
            "source_url_2021",
        ):
            if data.get(opt):
                stub[opt] = str(data[opt]).strip()
        _src_years = {y_base, y_curr}
        if y_mid_raw is not None:
            _src_years.add(int(y_mid_raw))
        for y in _src_years:
            sk = f"source_{y}"
            if data.get(sk):
                stub[sk] = str(data[sk]).strip()

        COMPANY_NARRATIVES[slug] = stub
        logger.info(
            "MANIFEST NARRATIVES  Registered %r from %s", slug, ypath.name
        )


def _merge_data_input_narrative_overrides(narratives_dir: Optional[Path] = None) -> None:
    """
    When ``Data_Input/narratives/{company}_excerpts.yaml`` exists, override
    built-in excerpts and optional source_* fields (PM / judge workflow).

    Requires PyYAML when override files are present. Missing PyYAML is ignored
    if no YAML files exist.

    Parameters
    ----------
    narratives_dir
        If set (e.g. in tests), only scan this directory instead of the default
        ``<repo>/Data_Input/narratives``.
    """
    root = Path(__file__).resolve().parents[1]
    ndir = narratives_dir if narratives_dir is not None else root / "Data_Input" / "narratives"
    if not ndir.is_dir():
        return
    yaml_files = sorted(ndir.glob("*_excerpts.yaml"))
    if not yaml_files:
        return
    try:
        import yaml  # type: ignore
    except ImportError:
        logger.warning(
            "DATA_INPUT NARRATIVES  PyYAML not installed — skipping %d YAML override(s).",
            len(yaml_files),
        )
        return
    for yaml_path in yaml_files:
        company = yaml_path.stem.replace("_excerpts", "").strip().lower()
        if company not in COMPANY_NARRATIVES:
            logger.warning(
                "DATA_INPUT NARRATIVES  Unknown company %r in %s — skipped "
                "(add company to manifest + required excerpts_* or built-in registry).",
                company,
                yaml_path.name,
            )
            continue
        try:
            with open(yaml_path, encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
        except (OSError, yaml.YAMLError) as exc:
            logger.warning("DATA_INPUT NARRATIVES  Cannot read %s: %s", yaml_path.name, exc)
            continue
        if not isinstance(data, dict):
            continue
        nar = COMPANY_NARRATIVES[company]
        for k, v in data.items():
            if isinstance(k, str) and k.startswith("excerpts_") and v:
                nar[k] = str(v).strip() + "\n"
        for k in (
            "source_2024",
            "source_2021",
            "source_2015",
            "source_url",
            "source_url_2021",
            "display_name",
        ):
            if data.get(k):
                nar[k] = str(data[k]).strip()
        logger.info(
            "DATA_INPUT NARRATIVES  Applied override for %s from %s",
            company,
            yaml_path.name,
        )


_register_manifest_narratives()
_merge_data_input_narrative_overrides()


# ── Glass-Box prompt template (XAI v2) ───────────────────────────────────────
# Anti-hallucination directives are mandatory for fiduciary compliance.
# temperature=0.0 is enforced at the API call level (llm_wrapper default).

_SENTIMENT_PROMPT_TEMPLATE = """\
You are a forensic ESG analyst conducting a Glass-Box Linguistic Audit for fiduciary accountability.
Analyse the following excerpts from {company_name}'s public corporate communications.

DOCUMENT EXCERPTS:
{excerpts}

TASK:
Return a JSON object with EXACTLY these four fields. This output will be used as legally-relevant
evidence in an institutional investment audit. Verbatim fidelity is a non-negotiable requirement.

{{
  "sentiment_score": <float from -1.0 to +1.0>,
  "narrative_hedging_phrases": [<list of verbatim substrings — see directives below>],
  "transition_aligned_phrases": [<list of verbatim substrings — see directives below>],
  "reasoning_trace": "<one sentence synthesising how the phrases above yield the sentiment score>"
}}

⚠️  ANTI-HALLUCINATION DIRECTIVES — MANDATORY COMPLIANCE:
1. Every string in "narrative_hedging_phrases" and "transition_aligned_phrases" MUST be a
   verbatim, exact substring copied character-for-character from the DOCUMENT EXCERPTS above.
2. DO NOT paraphrase, summarise, infer, or construct phrases. Copy exact text only.
3. DO NOT include any phrase that cannot be found word-for-word in the source text.
4. If no phrases of a category exist in the text, return an empty list [].

"narrative_hedging_phrases": Exact substrings demonstrating "linguistic softening" — language that
  hedges, qualifies, or dilutes transition commitments (e.g., "while maintaining conventional assets",
  "ensuring we supply the energy the world needs today", "challenging commodity environment").

"transition_aligned_phrases": Exact substrings demonstrating authentic decarbonisation commitment
  (e.g., "science-based targets", "carbon neutrality across our own operations by 2025",
  "fundamentally transformed from a fossil fuel company").

"sentiment_score":
  +1.0 = Extremely bullish transition language, firm science-based targets, no hedging
   0.0 = Neutral / balanced language
  -1.0 = Explicitly fossil-fuel-prioritising language

"reasoning_trace": One sentence explaining how the extracted phrases collectively yield the score.

Respond ONLY with valid JSON. No preamble, no markdown fences.
"""


# ── Neuro-Symbolic Reflection Pass (Sceptic-triggered re-read) ───────────────

_REFLECTION_PROMPT_TEMPLATE = """\
You are a CFA charterholder applying professional skepticism to public-company narrative text.

Systemic contradiction detected. Operational data shows a Resource Intensity shift of {delta_ri_pct}%, but your initial narrative score was {initial_score}. Re-evaluate the text with heightened professional skepticism. Look for 'deceptive framing' or 'greenwashing intent' designed to mask this data. Return a JSON with `reflective_sentiment_score` (float) and `cognitive_dissonance_analysis` (string).

Company: {display_name}

Source excerpts (public filings only):
{excerpts}

Output requirements:
- `reflective_sentiment_score`: float in [-1.0, 1.0] — your skepticism-adjusted read of the 2024 narrative alone (not a delta vs 2015).
- `cognitive_dissonance_analysis`: concise string explaining how framing may mask the operational surge.

Respond ONLY with valid JSON. No preamble, no markdown fences. Use keys exactly: reflective_sentiment_score, cognitive_dissonance_analysis.
"""


def build_reflection_prompt(
    initial_score: float,
    delta_resource: float,
    excerpts: str,
    display_name: str,
) -> str:
    """Assemble the reflection prompt (deterministic; used for cache keying)."""
    delta_ri_pct = f"{float(delta_resource) * 100:.1f}"
    return _REFLECTION_PROMPT_TEMPLATE.format(
        delta_ri_pct=delta_ri_pct,
        initial_score=float(initial_score),
        display_name=display_name,
        excerpts=excerpts.strip(),
    )


def _parse_reflection_response(raw: str) -> Dict[str, Any]:
    """Parse JSON from reflection LLM output; clamp score to [-1, 1]."""
    text = raw.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    try:
        data = json.loads(text)
        score = float(data.get("reflective_sentiment_score", 0.0))
        score = max(-1.0, min(1.0, score))
        analysis = str(data.get("cognitive_dissonance_analysis", "")).strip()
        return {
            "reflective_sentiment_score": round(score, 6),
            "cognitive_dissonance_analysis": analysis,
        }
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        logger.warning(
            "REFLECTION PARSE  Failed (%s). Using neutral fallback.",
            exc,
        )
        return {
            "reflective_sentiment_score": 0.0,
            "cognitive_dissonance_analysis": f"Parse error: {exc}",
        }


def run_reflection_pass(
    initial_score: float,
    delta_ri: float,
    excerpts: str,
    company_name: str,
    use_cached: bool = False,
    emit_llm_logs: bool = True,
) -> Dict[str, Any]:
    """
    Second-pass LLM read: re-score 2024 narrative under symbolic contradiction signal.

    Invoked by ScepticAgent when operational ΔResource Intensity contradicts a
    positive narrative shift. Cached under a distinct label per company
    (CFA Rule 4.4).

    Parameters
    ----------
    initial_score : float
        Prior consensus narrative score for 2024 (typically sentiment_2024).
    delta_ri : float
        Auditor ΔResource Intensity ratio (e.g. +9.65 for ~+965%% surge).
    excerpts : str
        Verbatim 2024 public-filing excerpts (same corpus as CorporateAgent).
    company_name : str
        Registry key (e.g. ``shell``).
    use_cached : bool
        If True, only read from ``data/api_cache.json`` (zero API cost).

    Returns
    -------
    dict
        ``reflective_sentiment_score``, ``cognitive_dissonance_analysis``,
        plus ``cache_label`` for provenance.
    """
    if company_name not in COMPANY_NARRATIVES:
        raise ValueError(f"Reflection unsupported for unknown company '{company_name}'.")

    display = COMPANY_NARRATIVES[company_name]["display_name"]
    prompt  = build_reflection_prompt(initial_score, delta_ri, excerpts, display)
    label   = f"CorporateAgent_reflection_{company_name}_2024"

    raw = llm_call(
        prompt=prompt,
        model="gpt-4o-mini",
        provider="openai",
        use_cached=use_cached,
        temperature=0.0,
        label=label,
        expected_fields=None,
        emit_llm_logs=emit_llm_logs,
    )
    out = _parse_reflection_response(raw)
    out["cache_label"] = label
    return out


# ── Main run function ─────────────────────────────────────────────────────────

def run(
    use_cached: bool = False,
    company_name: str = "shell",
    emit_llm_logs: bool = True,
    llm_events: Optional[List[dict]] = None,
) -> dict:
    """
    Execute the CorporateAgent Glass-Box Linguistic Audit — tri-node timeline from manifest.

    Years come from ``Data_Input/manifest.yaml`` → ``config.audit_profile.get_event_study``:
    baseline_year, optional mid_year, current_year. Excerpts must exist as
    ``excerpts_{year}`` in COMPANY_NARRATIVES (or Data_Input narrative YAML overrides).

    Output keys ``sentiment_2015`` / ``sentiment_2021`` / ``sentiment_2024`` remain
    **semantic** slots for baseline / mid / current scores (not necessarily calendar 2015/2021/2024).

    The tri-node extraction enables slope calculation for the Time-Series Event
    Study, allowing the ScepticAgent to detect the 2021 narrative inflection
    point that precisely coincides with Shell's jurisdictional relocation.

    All LLM calls use temperature=0.0 (deterministic) with anti-hallucination
    directives. Each year has a distinct SHA-256 cache key, ensuring independent
    reproducibility for each temporal node.

    Parameters
    ----------
    use_cached   : bool  Use cached responses (CFA Rule 4.4).
    company_name : str   Company identifier ("shell" or "orsted").
    emit_llm_logs: bool  Per-call CACHE HIT / API CALL log lines (ignored if ``llm_events`` set).
    llm_events   : Optional list filled with one row per LLM touch (sheet-style UI / CSV).

    Returns
    -------
    dict
        Keys: company_name, display_name,
        sentiment_2015, sentiment_2021 (or None), sentiment_2024,
        delta_narrative_sentiment (2024 − 2015),
        reasoning_2024/2021/2015,
        hedging_phrases_2024/2021, transition_phrases_2024/2021,
        has_2021_node (bool), schema_version, source, source_url.
    """
    if company_name not in COMPANY_NARRATIVES:
        from config.audit_profile import get_company_entry

        hint = ""
        if get_company_entry(company_name):
            hint = (
                f" Company is listed in Data_Input/manifest.yaml — add "
                f"Data_Input/narratives/{company_name}_excerpts.yaml with excerpts_* "
                f"for all event_study years (see get_event_study), then re-run."
            )
        raise ValueError(
            f"Unknown company '{company_name}'. "
            f"Registered: {list(COMPANY_NARRATIVES.keys())}.{hint}"
        )

    narrative = COMPANY_NARRATIVES[company_name]
    display   = narrative["display_name"]
    ev        = get_event_study(company_name)
    y_base    = int(ev["baseline_year"])
    y_curr    = int(ev["current_year"])
    y_mid_raw = ev.get("mid_year")
    y_mid: Optional[int] = int(y_mid_raw) if y_mid_raw is not None else None
    _emit_llm = emit_llm_logs if llm_events is None else False

    # ── Helper: dual-model fetch with conservative consensus ──────────────────
    def _dual_fetch(prompt: str, yr: int, label_base: str) -> dict:
        """
        Fetch from OpenAI + Anthropic (if available) and return consensus result.

        Conservative selection: use ``min(score_openai, score_anthropic)`` as
        the consensus sentiment score to protect the fiduciary downside.
        If Anthropic is unavailable (missing package or key), gracefully falls
        back to OpenAI-only mode with variance = 0.
        """
        # OpenAI node
        result_openai = _parse_response(
            llm_call(
                prompt=prompt, model="gpt-4o-mini", provider="openai",
                use_cached=use_cached,
                label=f"CorporateAgent_openai_{company_name}_{yr}",
                expected_fields=XAI_REQUIRED_FIELDS,
                emit_llm_logs=_emit_llm,
                llm_events=llm_events,
            ),
            year=yr, company=display,
        )
        score_openai = result_openai["narrative_sentiment_score"]

        # Anthropic node — graceful fallback
        score_anthropic = None
        ai_variance     = 0.0
        try:
            result_anthropic = _parse_response(
                llm_call(
                    prompt=prompt, model=ANTHROPIC_MODEL, provider="anthropic",
                    use_cached=use_cached,
                    label=f"CorporateAgent_anthropic_{company_name}_{yr}",
                    expected_fields=XAI_REQUIRED_FIELDS,
                    emit_llm_logs=_emit_llm,
                    llm_events=llm_events,
                ),
                year=yr, company=display,
            )
            score_anthropic = result_anthropic["narrative_sentiment_score"]
            ai_variance     = round(abs(score_openai - score_anthropic), 6)
        except (RuntimeError, EnvironmentError, ImportError) as _err:
            logger.warning(
                "ANTHROPIC FALLBACK  [%s year=%d] %s — OpenAI-only mode.",
                display, yr, _err,
            )

        # Conservative consensus: lower score = less narrative optimism claimed
        consensus_score = min(score_openai, score_anthropic) \
            if score_anthropic is not None else score_openai
        dual_active = score_anthropic is not None

        # Build consensus result (use OpenAI phrases for Glass-Box audit trail)
        consensus_result = dict(result_openai)
        consensus_result["narrative_sentiment_score"] = consensus_score
        consensus_result["score_openai"]    = score_openai
        consensus_result["score_anthropic"] = score_anthropic
        consensus_result["ai_variance"]     = ai_variance
        consensus_result["dual_active"]     = dual_active
        return consensus_result

    def _require_excerpts(y: int) -> str:
        key = f"excerpts_{y}"
        if key not in narrative:
            raise ValueError(
                f"CorporateAgent: missing {key!r} for company {company_name!r} "
                f"(event_study timeline uses baseline={y_base}, mid={y_mid}, current={y_curr})."
            )
        return str(narrative[key])

    # Fetch order: current → mid (if any) → baseline (matches cache-friendly priority)
    fetch_years: List[int] = [y_curr]
    if y_mid is not None:
        fetch_years.append(y_mid)
    fetch_years.append(y_base)

    results_by_year: Dict[int, Dict[str, Any]] = {}
    for y in fetch_years:
        prompt_y = _SENTIMENT_PROMPT_TEMPLATE.format(
            company_name=display,
            excerpts=_require_excerpts(y),
        )
        results_by_year[y] = _dual_fetch(prompt_y, yr=y, label_base=str(y))

    result_curr = results_by_year[y_curr]
    result_base = results_by_year[y_base]
    result_mid = results_by_year[y_mid] if y_mid is not None else None

    score_2024 = result_curr["narrative_sentiment_score"]
    score_2021 = result_mid["narrative_sentiment_score"] if result_mid else None
    score_2015 = result_base["narrative_sentiment_score"]
    delta      = round(score_2024 - score_2015, 6)

    # Max variance across all year-nodes (surface highest ambiguity for flagging)
    all_variances = [
        result_curr.get("ai_variance", 0.0),
        result_base.get("ai_variance", 0.0),
    ]
    if result_mid:
        all_variances.append(result_mid.get("ai_variance", 0.0))
    max_ai_variance = round(max(all_variances), 6)
    high_ambiguity  = max_ai_variance > 0.15

    # ── Dual-Model NLP Consensus Matrix (terminal glass-box view) ───────────
    from rich import box
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text

    nlp_tbl = Table(
        title="🧠 Dual-Model NLP Consensus Matrix",
        title_style="bold blue",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold blue",
        padding=(0, 1),
    )
    nlp_tbl.add_column("Node (Year)", style="cyan", justify="center")
    nlp_tbl.add_column("OpenAI Score", justify="right")
    nlp_tbl.add_column("Anthropic Score", justify="right")
    nlp_tbl.add_column("Variance", justify="right")
    nlp_tbl.add_column("Consensus", justify="right", style="bold white")
    nlp_tbl.add_column("Hedging #", justify="center")

    def _nlp_row(label_yr: int, res: Dict[str, Any]) -> None:
        oa = res.get("score_openai")
        an = res.get("score_anthropic")
        var = res.get("ai_variance", 0.0) or 0.0
        cons = res.get("narrative_sentiment_score")
        hct = len(res.get("hedging_phrases") or [])
        oa_t = f"{oa:+.4f}" if oa is not None else "—"
        an_t = f"{an:+.4f}" if an is not None else "—"
        var_t = f"{var:.4f}" if an is not None else "0.0000"
        cons_t = f"{cons:+.4f}" if cons is not None else "—"
        nlp_tbl.add_row(str(label_yr), oa_t, an_t, var_t, cons_t, str(hct))

    chrono = [y_base] + ([y_mid] if y_mid is not None else []) + [y_curr]
    for yy in chrono:
        _nlp_row(yy, results_by_year[yy])

    _c = Console()
    _c.print(nlp_tbl)
    _c.print(
        Text(
            f"ΔNarrative Sentiment ({y_base}→{y_curr}) = {delta:+.4f}  |  "
            f"max variance = {max_ai_variance:.4f}  |  "
            f"{'⚠ HIGH AMBIGUITY' if high_ambiguity else '✓ low variance'}  |  "
            f"schema={result_curr.get('schema_version', 'unknown')}",
            style="dim",
        )
    )
    _foot_parts = [
        f"{y_base}: {result_base.get('reasoning', '')[:100]}",
        f"{y_curr}: {result_curr.get('reasoning', '')[:100]}",
    ]
    if result_mid and y_mid is not None:
        _foot_parts.insert(1, f"{y_mid}: {result_mid.get('reasoning', '')[:100]}")
    _c.print(Text("reasoning_trace → " + " │ ".join(_foot_parts), style="dim"))

    def _src(y: int) -> str:
        return str(narrative.get(f"source_{y}") or "").strip()

    src_parts = [_src(y_curr)]
    if y_mid is not None and _src(y_mid):
        src_parts.append(_src(y_mid))
    if _src(y_base):
        src_parts.append(_src(y_base))
    source_joined = "; ".join(p for p in src_parts if p)

    return {
        "company_name":              company_name,
        "display_name":              display,
        "sentiment_2015":            score_2015,
        "sentiment_2021":            score_2021,
        "sentiment_2024":            score_2024,
        "has_2021_node":             score_2021 is not None,
        "delta_narrative_sentiment": delta,
        "reasoning_2024":            result_curr["reasoning"],
        "reasoning_2021":            result_mid["reasoning"] if result_mid else None,
        "reasoning_2015":            result_base["reasoning"],
        "hedging_phrases_2024":      result_curr["hedging_phrases"],
        "transition_phrases_2024":   result_curr["transition_phrases"],
        "hedging_phrases_2021":      result_mid["hedging_phrases"] if result_mid else [],
        "transition_phrases_2021":   result_mid["transition_phrases"] if result_mid else [],
        "hedging_phrases_2015":      result_base["hedging_phrases"],
        "transition_phrases_2015":   result_base["transition_phrases"],
        "schema_version":            result_curr.get("schema_version", "unknown"),
        # ── Dual-Model Bias Guard fields (suffixes = baseline / mid / current semantics) ─
        "score_openai_2024":         result_curr.get("score_openai"),
        "score_anthropic_2024":      result_curr.get("score_anthropic"),
        "ai_variance_2024":          result_curr.get("ai_variance", 0.0),
        "score_openai_2015":         result_base.get("score_openai"),
        "score_anthropic_2015":      result_base.get("score_anthropic"),
        "ai_variance_2015":          result_base.get("ai_variance", 0.0),
        "score_openai_2021":         result_mid.get("score_openai") if result_mid else None,
        "score_anthropic_2021":      result_mid.get("score_anthropic") if result_mid else None,
        "ai_variance_2021":          result_mid.get("ai_variance", 0.0) if result_mid else 0.0,
        "max_ai_variance":           max_ai_variance,
        "high_ambiguity_flag":       high_ambiguity,
        "dual_model_active":         result_curr.get("dual_active", False),
        "event_study":               ev,
        "source":                    source_joined,
        "source_url":                narrative.get("source_url", ""),
        "source_url_2021":         narrative.get("source_url_2021", ""),
    }


# ── Helper ────────────────────────────────────────────────────────────────────

def _parse_response(raw: str, year: int, company: str = "") -> dict:
    """
    Parse an LLM JSON response — handles both XAI v2 and legacy v1 schemas.

    XAI v2 (Glass-Box) schema keys: sentiment_score, narrative_hedging_phrases,
        transition_aligned_phrases, reasoning_trace.
    Legacy v1 schema keys: narrative_sentiment_score, reasoning.

    If the legacy format is detected (cache not yet regenerated), emits a
    warning and returns empty phrase lists — graceful degradation, no crash.
    Phrase lists will be empty until the cache is regenerated with a live API call.

    Parameters
    ----------
    raw     : Raw LLM response string (may contain markdown fences).
    year    : Document year (2015 or 2024), used in log messages.
    company : Display name for log context.

    Returns
    -------
    dict
        Keys: narrative_sentiment_score (float, clamped to [-1,+1]),
        reasoning (str), hedging_phrases (list[str]),
        transition_phrases (list[str]), schema_version (str).
    """
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]

    try:
        parsed = json.loads(raw)

        # ── XAI v2 Glass-Box schema ───────────────────────────────────────────
        if "sentiment_score" in parsed:
            score = float(parsed["sentiment_score"])
            score = max(-1.0, min(1.0, score))

            hedging    = _validate_phrase_list(parsed.get("narrative_hedging_phrases", []))
            transition = _validate_phrase_list(parsed.get("transition_aligned_phrases", []))

            return {
                "narrative_sentiment_score": score,
                "reasoning":                 parsed.get("reasoning_trace", "No trace provided."),
                "hedging_phrases":           hedging,
                "transition_phrases":        transition,
                "schema_version":            "xai_v2",
            }

        # ── Legacy v1 schema — backward-compatible fallback ───────────────────
        if "narrative_sentiment_score" in parsed:
            score = float(parsed["narrative_sentiment_score"])
            score = max(-1.0, min(1.0, score))
            logger.warning(
                "LEGACY CACHE SCHEMA  [%s year=%d] "
                "Phrase attribution unavailable — cache was built with the old schema.\n"
                "  To enable Glass-Box XAI: delete data/api_cache.json and run once "
                "in live mode (python run_auditlens.py) to regenerate the cache.",
                company, year,
            )
            return {
                "narrative_sentiment_score": score,
                "reasoning":                 parsed.get("reasoning", "Legacy schema."),
                "hedging_phrases":           [],
                "transition_phrases":        [],
                "schema_version":            "legacy_v1",
            }

        raise KeyError(
            "Response JSON lacks both 'sentiment_score' (v2) and "
            "'narrative_sentiment_score' (v1). Cannot parse."
        )

    except (json.JSONDecodeError, KeyError, ValueError) as exc:
        logger.warning(
            "Failed to parse %s year=%d LLM response (%s). Using neutral fallback. Raw: %.120s",
            company, year, exc, raw,
        )
        return {
            "narrative_sentiment_score": 0.0,
            "reasoning":                 f"Parse error: {exc}",
            "hedging_phrases":           [],
            "transition_phrases":        [],
            "schema_version":            "error",
        }


def _validate_phrase_list(phrases: Any) -> List[str]:
    """
    Validate and sanitise a phrase list from the LLM response.

    Ensures all elements are non-empty strings; silently drops invalid entries.
    This is a defensive layer against rare schema non-compliance even at temp=0.0.

    Parameters
    ----------
    phrases : Any  The raw value from the parsed JSON (expected: list of strings).

    Returns
    -------
    List[str]
        Clean list of non-empty strings.
    """
    if not isinstance(phrases, list):
        return []
    return [p for p in phrases if isinstance(p, str) and p.strip()]
