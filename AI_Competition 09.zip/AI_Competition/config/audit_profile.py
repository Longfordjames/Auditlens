# MIT License — see LICENSE file
"""
Data_Input manifest → runtime audit timeline and scalar years.

Single source of truth: Data_Input/manifest.yaml (defaults + per-company overrides).
Used by sync, AuditorAgent, CorporateAgent, and ScepticAgent trajectory logic.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from data_loader import SUPPORTED_COMPANIES

_REPO_ROOT = Path(__file__).resolve().parents[1]
_MANIFEST_PATH = _REPO_ROOT / "Data_Input" / "manifest.yaml"

DEFAULT_EVENT_STUDY: Dict[str, Any] = {
    "baseline_year": 2015,
    "mid_year": 2021,
    "current_year": 2024,
    "event_label": "Dutch Court Ruling (May 2021) / UK Relocation (2022)",
}

DEFAULT_SCALAR_YEARS: Dict[str, int] = {
    "esg": 2024,
    "transition_capex": 2024,
    "jurisdictional_arbitrage": 2024,
}

DEFAULT_IOD_ENDPOINTS: Tuple[int, int] = (2015, 2024)


def manifest_path() -> Path:
    return _MANIFEST_PATH


def load_manifest() -> Dict[str, Any]:
    if not _MANIFEST_PATH.exists():
        return {}
    try:
        import yaml  # type: ignore

        with open(_MANIFEST_PATH, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def get_company_entry(company_name: str) -> Dict[str, Any]:
    m = load_manifest()
    companies = m.get("companies") or {}
    ent = companies.get((company_name or "").strip().lower())
    return ent if isinstance(ent, dict) else {}


def get_defaults() -> Dict[str, Any]:
    m = load_manifest()
    d = m.get("defaults")
    return d if isinstance(d, dict) else {}


def get_event_study(company_name: str) -> Dict[str, Any]:
    out: Dict[str, Any] = dict(DEFAULT_EVENT_STUDY)
    defs = get_defaults().get("event_study") or {}
    if isinstance(defs, dict):
        _apply_event_study_dict(out, defs)
    ent = get_company_entry(company_name).get("event_study") or {}
    if isinstance(ent, dict):
        _apply_event_study_dict(out, ent)
    return out


def _apply_event_study_dict(target: Dict[str, Any], src: Dict[str, Any]) -> None:
    for k, v in src.items():
        if k == "event_label":
            if v is not None:
                target[k] = str(v)
        elif k == "mid_year" and v is None:
            target[k] = None
        elif v is not None:
            target[k] = int(v)


def get_scalar_years(company_name: str) -> Dict[str, int]:
    out = dict(DEFAULT_SCALAR_YEARS)
    defs = get_defaults().get("scalar_years") or {}
    if isinstance(defs, dict):
        for k in DEFAULT_SCALAR_YEARS:
            if k in defs and defs[k] is not None:
                out[k] = int(defs[k])
    ent = get_company_entry(company_name).get("scalar_years") or {}
    if isinstance(ent, dict):
        for k in DEFAULT_SCALAR_YEARS:
            if k in ent and ent[k] is not None:
                out[k] = int(ent[k])
    return out


def get_iod_resource_scope3_years(company_name: str) -> Tuple[int, int]:
    """Baseline and current audit labels for ΔResource Intensity and ΔScope 3."""
    base, curr = DEFAULT_IOD_ENDPOINTS
    defs = get_defaults().get("iod_endpoints") or {}
    if isinstance(defs, dict):
        pair = defs.get("resource_and_scope3")
        if isinstance(pair, (list, tuple)) and len(pair) >= 2:
            base, curr = int(pair[0]), int(pair[1])
    ent = get_company_entry(company_name).get("iod_endpoints") or {}
    if isinstance(ent, dict):
        pair = ent.get("resource_and_scope3")
        if isinstance(pair, (list, tuple)) and len(pair) >= 2:
            base, curr = int(pair[0]), int(pair[1])
    return base, curr


def dynamic_iod_from_csv_enabled(company_name: str) -> bool:
    """When True, AuditorAgent uses min/max years from the loaded CSV for iod endpoints."""
    ent = get_company_entry(company_name)
    if "dynamic_iod_years" in ent:
        return bool(ent["dynamic_iod_years"])
    return bool(get_defaults().get("dynamic_iod_years"))


def try_dynamic_fuel_years(
    company_name: str,
    records: List[Dict[str, Any]],
) -> Optional[Tuple[int, int]]:
    """
    If ``dynamic_iod_years`` is enabled and the CSV has at least two distinct
    years (excluding narrative_sentiment), return (min_year, max_year).
    """
    if not dynamic_iod_from_csv_enabled(company_name):
        return None
    from data_loader import discover_audit_years_from_records

    years = discover_audit_years_from_records(records)
    if len(years) < 2:
        return None
    return (years[0], years[-1])


def get_audit_years_list(company_name: str) -> List[int]:
    defs = get_defaults()
    years = defs.get("audit_years")
    if isinstance(years, list) and years:
        base_years = [int(y) for y in years]
    else:
        base_years = [2015, 2021, 2024]
    ent = get_company_entry(company_name).get("audit_years")
    if isinstance(ent, list) and ent:
        return [int(y) for y in ent]
    return base_years


def _detect_arb_year(
    records: List[Dict[str, Any]],
    arb_metric: str,
    default_year: int,
) -> int:
    for r in records:
        if (r.get("metric") or "").strip() != arb_metric:
            continue
        try:
            if float(r["value"]) == 1:
                return int(r["year"])
        except (ValueError, KeyError, TypeError):
            continue
    return default_year


def config_from_manifest(
    company_name: str,
    records: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """
    Build an AuditorAgent-style config dict from manifest ``output_metrics``.

    Returns None if the company is not listed or ``output_metrics`` is incomplete.
    ``display_name`` uses the manifest string, else :data:`SUPPORTED_COMPANIES`, else title-case slug.
    """
    ent = get_company_entry(company_name)
    om = ent.get("output_metrics")
    if not isinstance(om, dict) or not om:
        return None
    mapping = {
        "Upstream_Fuel_Consumption": "fuel_metric",
        "Scope_3_Emissions": "scope3_metric",
        "ESG_Disclosure_Score": "esg_metric",
        "Transition_Capex": "capex_metric",
        "Jurisdictional_Arbitrage": "arb_metric",
    }
    base: Dict[str, Any] = {}
    for internal, attr in mapping.items():
        label = om.get(internal)
        if not label:
            return None
        base[attr] = str(label).strip()

    slug = (company_name or "").strip().lower()
    disp = ent.get("display_name")
    if disp:
        base["display_name"] = str(disp).strip()
    else:
        base["display_name"] = SUPPORTED_COMPANIES.get(
            slug, slug.replace("_", " ").title()
        )

    sy = get_scalar_years(company_name)
    arb_default = int(sy["jurisdictional_arbitrage"])
    base["arb_year"] = _detect_arb_year(records, base["arb_metric"], arb_default)

    b, c = get_iod_resource_scope3_years(company_name)
    base["fuel_years"] = (b, c)
    return base


def merge_auditor_config(company_name: str, base_cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of a COMPANY_CONFIG row merged with manifest policy."""
    cfg = dict(base_cfg)
    b, c = get_iod_resource_scope3_years(company_name)
    cfg["fuel_years"] = (b, c)
    sy = get_scalar_years(company_name)
    cfg["esg_year"] = sy["esg"]
    cfg["capex_year"] = sy["transition_capex"]
    cfg["arb_year"] = sy["jurisdictional_arbitrage"]
    cfg["event_study"] = get_event_study(company_name)
    return cfg


def merge_auditor_config_auto(
    company_name: str,
    base_cfg: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Auto-detected companies: merge manifest when company is listed; else defaults."""
    cfg = dict(base_cfg or {})
    ent = get_company_entry(company_name)
    if not ent:
        b, c = get_iod_resource_scope3_years(company_name)
        cfg.setdefault("fuel_years", (b, c))
        sy = get_scalar_years(company_name)
        cfg.setdefault("esg_year", sy["esg"])
        cfg.setdefault("capex_year", sy["transition_capex"])
        if not cfg.get("_auto_detected"):
            cfg.setdefault("arb_year", sy["jurisdictional_arbitrage"])
        cfg.setdefault("event_study", get_event_study(company_name))
        return cfg
    return merge_auditor_config(company_name, cfg)
