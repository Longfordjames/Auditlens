# MIT License — see LICENSE file
"""
tests/test_pm_assistant.py
============================
Unit tests for the PM Assistant module.

Coverage:
  • Chat loop exit: clean on "exit" / "quit" / KeyboardInterrupt.
  • Cached demo playback: 3 turns rendered without RuntimeError or network call.
  • Context minification: strips raw_records, preserves analytical fields.
  • Audit trail: file is written on session end.
  • System prompt: contains strict-RAG constraints.

All tests are 100% offline — no API calls, no LLM, no network.
"""

import json
import sys
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

from agents.pm_assistant import (
    _DEMO_TURNS,
    _build_system_prompt,
    _write_audit_trail,
    minify_context,
    run_chat_loop,
)


# ── Shared fixtures ───────────────────────────────────────────────────────────

def _scan_row(company="shell", bps=-50):
    return {
        "company_name":     company,
        "display_name":     company.upper(),
        "id_val":           -3.7344,
        "risk_flag":        "AUTHENTIC TRANSITION LEADER",
        "risk_level":       "LOW",
        "wacc_bps":         bps,
        "integrity_score":  0.30,
        "delta_ri_pct":     -15.5,
        "delta_sentiment":  0.47,
        "disclosure_density": 0.81,
        "arb_flag":         0,
        "sentiment_source": "LLM Dual-Model",
        # heavy field that should be stripped:
        "raw_records":      [{"metric": "gas", "value": 12_000_000, "year": 2024}],
    }


_PORTFOLIO = {
    "aum_usd": 100_000_000.0,
    "n_assets": 2,
    "weight_sum_check": 100.0,
    "positions": [
        {
            "company_name":        "shell",
            "display_name":        "Shell PLC",
            "baseline_weight_pct": 50.0,
            "optimized_weight_pct": 51.83,
            "delta_weight_pct":    1.83,
            "delta_capital_usd":   1_830_000.0,
            "wacc_bps":            -50,
            "tilt_multiplier":     1.10,
            "risk_flag":           "AUTHENTIC TRANSITION LEADER",
        }
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Context minification
# ═══════════════════════════════════════════════════════════════════════════════

class TestMinifyContext:
    """Raw records must be stripped; analytical fields preserved."""

    def test_raw_records_stripped(self):
        """raw_records must not appear in minified context."""
        ctx = minify_context([_scan_row()])
        for row in ctx["scan_results"]:
            assert "raw_records" not in row

    def test_analytical_fields_preserved(self):
        """id_val, wacc_bps, risk_flag must survive minification."""
        ctx = minify_context([_scan_row()])
        row = ctx["scan_results"][0]
        assert "id_val"    in row
        assert "wacc_bps"  in row
        assert "risk_flag" in row

    def test_portfolio_included_when_passed(self):
        """Portfolio section present when portfolio_data is supplied."""
        ctx = minify_context([_scan_row()], portfolio_data=_PORTFOLIO)
        assert "portfolio" in ctx
        assert ctx["portfolio"]["n_assets"] == 2

    def test_portfolio_positions_minified(self):
        """Portfolio positions contain only expected keys."""
        ctx = minify_context([_scan_row()], portfolio_data=_PORTFOLIO)
        pos = ctx["portfolio"]["positions"][0]
        assert "delta_capital_usd" in pos
        assert "optimized_weight_pct" in pos

    def test_no_portfolio_when_none(self):
        """No portfolio key when portfolio_data is None."""
        ctx = minify_context([_scan_row()])
        assert "portfolio" not in ctx

    def test_multiple_scan_rows_all_minified(self):
        """All rows minified, none contain raw_records."""
        rows = [_scan_row("shell", -50), _scan_row("orsted", -50)]
        ctx = minify_context(rows)
        assert len(ctx["scan_results"]) == 2
        for r in ctx["scan_results"]:
            assert "raw_records" not in r


# ═══════════════════════════════════════════════════════════════════════════════
# 2. System prompt construction
# ═══════════════════════════════════════════════════════════════════════════════

class TestSystemPrompt:
    """System prompt must embed strict-RAG constraints and JSON context."""

    def test_strict_constraints_present(self):
        """Prompt contains the mandatory strict-constraint directives."""
        ctx = minify_context([_scan_row()])
        prompt = _build_system_prompt(ctx)
        assert "ONLY the provided AuditLens JSON context" in prompt
        assert "source_citation" in prompt
        assert "hedging_phrases" in prompt

    def test_context_json_embedded(self):
        """The minified JSON context appears verbatim in the prompt."""
        ctx = minify_context([_scan_row()])
        prompt = _build_system_prompt(ctx)
        assert "scan_results" in prompt

    def test_prompt_is_string(self):
        """Return type is str."""
        ctx = minify_context([_scan_row()])
        assert isinstance(_build_system_prompt(ctx), str)


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Demo playback (CFA Rule 4.4 — zero API calls)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDemoPlayback:
    """Cached playback must render 3 turns without any network call."""

    def test_demo_has_three_turns(self):
        """_DEMO_TURNS must contain exactly 3 (question, answer) pairs."""
        assert len(_DEMO_TURNS) == 3

    def test_demo_turn_structure(self):
        """Each demo turn is a (str, str) pair."""
        for q, a in _DEMO_TURNS:
            assert isinstance(q, str) and len(q) > 0
            assert isinstance(a, str) and len(a) > 0

    def test_cached_playback_no_network_call(self, tmp_path):
        """run_chat_loop(use_cached=True) must not call llm_call or OpenAI."""
        ctx = minify_context([_scan_row()])
        audit_file = tmp_path / "trail.txt"
        with patch("agents.pm_assistant._playback_demo") as mock_pb:
            mock_pb.side_effect = lambda trail: trail.append("DEMO")
            run_chat_loop(ctx, use_cached=True, audit_path=audit_file)
            mock_pb.assert_called_once()

    def test_cached_playback_writes_audit_trail(self, tmp_path):
        """Audit trail file is created after demo playback."""
        ctx = minify_context([_scan_row()])
        audit_file = tmp_path / "trail.txt"

        with patch("agents.pm_assistant._playback_demo") as mock_pb:
            mock_pb.side_effect = lambda trail: trail.extend(["Q", "A"])
            run_chat_loop(ctx, use_cached=True, audit_path=audit_file)

        assert audit_file.exists()
        content = audit_file.read_text()
        assert len(content) > 0

    def test_demo_mentions_shell_wacc(self):
        """Demo answer for Q1 references Shell's green premium / tilt (-50 bps tier)."""
        _, answer = _DEMO_TURNS[0]
        assert "-50" in answer
        assert "Shell" in answer or "shell" in answer.lower()

    def test_demo_mentions_orsted_green_premium(self):
        """Demo answer for Q2 references Ørsted's green premium."""
        _, answer = _DEMO_TURNS[1]
        assert "Ørsted" in answer or "orsted" in answer.lower() or "-50" in answer


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Chat loop — exit / quit
# ═══════════════════════════════════════════════════════════════════════════════

class TestChatLoopExit:
    """Chat loop must exit cleanly on 'exit' / 'quit' / KeyboardInterrupt."""

    def _run_with_inputs(self, inputs: list, tmp_path: Path):
        """Helper: run live-mode chat loop with mocked Prompt.ask responses."""
        ctx = minify_context([_scan_row()])
        audit_file = tmp_path / "trail.txt"
        input_iter = iter(inputs)

        with patch("agents.pm_assistant.Prompt.ask", side_effect=lambda *a, **kw: next(input_iter)):
            with patch("agents.pm_assistant.llm_call", return_value="Mock answer."):
                run_chat_loop(ctx, use_cached=False, audit_path=audit_file)

        return audit_file

    def test_exit_command_terminates_cleanly(self, tmp_path):
        """'exit' input terminates without exception."""
        audit = self._run_with_inputs(["exit"], tmp_path)
        assert audit.exists()

    def test_quit_command_terminates_cleanly(self, tmp_path):
        """'quit' input terminates without exception."""
        audit = self._run_with_inputs(["quit"], tmp_path)
        assert audit.exists()

    def test_keyboard_interrupt_terminates_cleanly(self, tmp_path):
        """KeyboardInterrupt is caught; no traceback exposed."""
        ctx = minify_context([_scan_row()])
        audit_file = tmp_path / "trail.txt"

        with patch("agents.pm_assistant.Prompt.ask", side_effect=KeyboardInterrupt):
            with patch("agents.pm_assistant.llm_call"):
                run_chat_loop(ctx, use_cached=False, audit_path=audit_file)

        assert audit_file.exists()

    def test_one_question_then_exit(self, tmp_path):
        """Single question answered before 'exit'; audit trail contains Q."""
        audit = self._run_with_inputs(["What is Shell's I_d?", "exit"], tmp_path)
        content = audit.read_text()
        assert "Shell" in content or len(content) > 10


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Audit trail write
# ═══════════════════════════════════════════════════════════════════════════════

class TestAuditTrail:
    """Audit trail must be created and non-empty after session."""

    def test_audit_trail_created(self, tmp_path):
        """File is written to the specified path."""
        trail = ["Turn 1: Q", "Turn 1: A"]
        path = tmp_path / "audit.txt"
        _write_audit_trail(trail, path)
        assert path.exists()

    def test_audit_trail_content(self, tmp_path):
        """Written content matches the audit trail list."""
        trail = ["PM: hello", "ASSISTANT: hi"]
        path = tmp_path / "audit.txt"
        _write_audit_trail(trail, path)
        content = path.read_text()
        assert "PM: hello" in content
        assert "ASSISTANT: hi" in content

    def test_audit_trail_appends(self, tmp_path):
        """Multiple writes append, not overwrite."""
        path = tmp_path / "audit.txt"
        _write_audit_trail(["Session 1"], path)
        _write_audit_trail(["Session 2"], path)
        content = path.read_text()
        assert "Session 1" in content
        assert "Session 2" in content
