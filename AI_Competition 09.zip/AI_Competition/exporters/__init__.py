# MIT License — see LICENSE file
"""
AuditLens Exporters Package
============================
Produces institutional-grade, self-contained output artefacts:
  html_generator  — Institutional HTML Tear Sheet (Jinja2 + embedded CSS)
"""
