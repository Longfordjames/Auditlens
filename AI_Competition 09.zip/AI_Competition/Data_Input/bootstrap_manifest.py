#!/usr/bin/env python3
# MIT License — see LICENSE file
"""
Bootstrap manifest company stubs from Excel workbooks under Data_Input/.

Detects fiscal year columns from the header row, emits YAML (stdout or append).

Usage:
  python3 Data_Input/bootstrap_manifest.py --dry-run
  python3 Data_Input/bootstrap_manifest.py --file Data_Input/MyCo.xlsx --company-slug myco --map 2015:2020,2021:2021,2024:2024
  python3 Data_Input/bootstrap_manifest.py --append-to Data_Input/manifest.yaml --file ...
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO_ROOT = Path(__file__).resolve().parents[1]
DATA_INPUT = REPO_ROOT / "Data_Input"
MAPPING_PATH = REPO_ROOT / "config" / "mapping.json"

# Exclude template / portfolio workbooks from glob
EXCLUDE_NAME_SUBSTRINGS = ("template", "portfolio", "copy of shell", "cfa alpha")

INTERNAL_ORDER = [
    "Upstream_Fuel_Consumption",
    "Scope_3_Emissions",
    "ESG_Disclosure_Score",
    "Transition_Capex",
    "Jurisdictional_Arbitrage",
]

# Sensible default row labels aligned with mapping.json aliases (Shell-style)
DEFAULT_OUTPUT_METRICS: Dict[str, str] = {
    "Upstream_Fuel_Consumption": "Total energy consumption",
    "Scope_3_Emissions": "Total Scope 3 GHG Emissions",
    "ESG_Disclosure_Score": "General ESG Disclosure Score",
    "Transition_Capex": "Transition Capex Contraction",
    "Jurisdictional_Arbitrage": "Jurisdictional Arbitrage Flag",
}


def _load_excel_io():
    import importlib.util

    p = Path(__file__).resolve().parent / "excel_io.py"
    spec = importlib.util.spec_from_file_location("data_input_excel_io", p)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def default_output_metrics_from_mapping() -> Dict[str, str]:
    """Prefer first alias per internal key from mapping.json when present."""
    try:
        with open(MAPPING_PATH, encoding="utf-8") as fh:
            data = json.load(fh)
    except OSError:
        return dict(DEFAULT_OUTPUT_METRICS)
    metrics = data.get("metrics") or {}
    out: Dict[str, str] = {}
    for internal in INTERNAL_ORDER:
        spec = metrics.get(internal) or {}
        aliases = list(spec.get("aliases") or [])
        if aliases:
            out[internal] = aliases[0]
        else:
            out[internal] = internal.replace("_", " ")
    return out


def parse_year_map(s: str) -> Dict[int, int]:
    """
    Parse '2015:2020,2021:2021,2024:2024' -> audit_year -> fiscal_year_column.
    """
    out: Dict[int, int] = {}
    for part in s.split(","):
        part = part.strip()
        if not part:
            continue
        m = re.match(r"^\s*(\d{4})\s*:\s*(\d{4})\s*$", part)
        if not m:
            raise ValueError(f"Invalid map segment {part!r}; use audit:fiscal like 2015:2020")
        out[int(m.group(1))] = int(m.group(2))
    if not out:
        raise ValueError("Empty --map")
    return out


def slug_from_stem(stem: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", stem.lower()).strip("_")
    return s or "company"


def discover_xlsx_files(data_input: Path) -> List[Path]:
    files: List[Path] = []
    for p in sorted(data_input.glob("*.xlsx")):
        low = p.name.lower()
        if any(x in low for x in EXCLUDE_NAME_SUBSTRINGS):
            continue
        files.append(p)
    return files


def build_company_stub(
    workbook_rel: str,
    sheet: str,
    year_columns: Dict[int, int],
    company_slug: str,
    display_name: Optional[str],
    output_metrics: Dict[str, str],
) -> Tuple[str, Dict[str, Any]]:
    """Return (slug, company entry dict)."""
    wb_name = Path(workbook_rel).name
    entry: Dict[str, Any] = {
        "workbook": workbook_rel,
        "sheet": sheet,
        "year_columns": {str(k): v for k, v in sorted(year_columns.items())},
        "output_metrics": dict(output_metrics),
        "excel_citation": {
            "workbook_display": wb_name,
            "sheet_display": sheet,
        },
        "default_source_url": "",
        "scope3_excel_multiplier": 1000000,
        "pdf_sources": {},
        "pdf_fallback": [],
        "narratives": {},
    }
    if display_name:
        entry["display_name"] = display_name
    return company_slug, entry


def run_one_workbook(
    xlsx_path: Path,
    company_slug: Optional[str],
    sheet_override: Optional[str],
    year_map: Optional[Dict[int, int]],
    max_scan: int,
    output_metrics: Dict[str, str],
    display_name: Optional[str],
) -> Tuple[str, Dict[str, Any]]:
    excel = _load_excel_io()
    rel = str(xlsx_path.resolve().relative_to(REPO_ROOT))
    slug = company_slug or slug_from_stem(xlsx_path.stem)
    sheets = excel.list_sheet_names(xlsx_path)
    sheet = sheet_override or (sheets[0] if sheets else "")
    if not sheet:
        raise ValueError(f"No sheets in {xlsx_path}")
    rows = excel.read_excel_grid(xlsx_path, sheet)
    _hrow, year_to_col = excel.find_header_row(rows, max_scan)
    if year_map is None:
        # Default: identity map for years that look like audit years (2015,2021,2024 pattern)
        common = [y for y in (2015, 2021, 2024) if y in year_to_col]
        if len(common) >= 2:
            year_columns = {y: y for y in common}
        elif header_years:
            year_columns = {y: y for y in header_years[-3:]} if len(header_years) >= 3 else {header_years[-1]: header_years[-1]}
        else:
            raise ValueError("No fiscal year integers found in header scan; pass --map")
    else:
        year_columns = dict(year_map)
    return build_company_stub(rel, sheet, year_columns, slug, display_name, output_metrics)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Bootstrap manifest.yaml company entries from Data_Input/*.xlsx"
    )
    parser.add_argument(
        "--file",
        type=Path,
        help="Specific workbook (default: all non-template *.xlsx in Data_Input/)",
    )
    parser.add_argument(
        "--company-slug",
        help="Manifest key (default: derived from filename)",
    )
    parser.add_argument("--sheet", help="Sheet name (default: first sheet)")
    parser.add_argument(
        "--map",
        dest="year_map",
        help="Audit year to FY column label, e.g. 2015:2020,2021:2021,2024:2024",
    )
    parser.add_argument(
        "--max-header-scan",
        type=int,
        default=8,
        help="Rows to scan for year header (default: 8)",
    )
    parser.add_argument(
        "--use-mapping-labels",
        action="store_true",
        help="Set output_metrics from first alias in config/mapping.json",
    )
    parser.add_argument("--display-name", help="Optional human-readable issuer name")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print YAML to stdout only (default if no --append-to)",
    )
    parser.add_argument(
        "--append-to",
        type=Path,
        help="Merge generated companies into this manifest file (YAML comments not preserved)",
    )
    args = parser.parse_args()

    try:
        import yaml  # type: ignore
    except ImportError as exc:
        print("PyYAML required: pip install pyyaml", file=sys.stderr)
        raise SystemExit(1) from exc

    out_metrics = (
        default_output_metrics_from_mapping()
        if args.use_mapping_labels
        else dict(DEFAULT_OUTPUT_METRICS)
    )
    year_map: Optional[Dict[int, int]] = None
    if args.year_map:
        try:
            year_map = parse_year_map(args.year_map)
        except ValueError as e:
            print(str(e), file=sys.stderr)
            return 1

    files: List[Path]
    if args.file:
        p = args.file.resolve()
        if not p.exists():
            print(f"Missing file: {p}", file=sys.stderr)
            return 1
        files = [p]
    else:
        files = discover_xlsx_files(DATA_INPUT)
        if not files:
            print("No .xlsx files found under Data_Input/ (after excludes).", file=sys.stderr)
            return 1

    built: Dict[str, Dict[str, Any]] = {}
    for fp in files:
        try:
            slug, entry = run_one_workbook(
                fp,
                args.company_slug if len(files) == 1 else None,
                args.sheet,
                year_map,
                args.max_header_scan,
                out_metrics,
                args.display_name if len(files) == 1 else None,
            )
            if args.company_slug and len(files) > 1:
                print(
                    f"Skipping multi-file glob with --company-slug; use --file per company.",
                    file=sys.stderr,
                )
                return 1
            if slug in built:
                print(f"Duplicate slug {slug!r} from {fp.name}; use --file and --company-slug.", file=sys.stderr)
                return 1
            built[slug] = entry
        except Exception as exc:
            print(f"[error] {fp.name}: {exc}", file=sys.stderr)
            return 1

    dump_obj: Dict[str, Any] = {"companies": built}

    if args.dry_run:
        print(yaml.dump(dump_obj, default_flow_style=False, allow_unicode=True, sort_keys=False))
        print(
            "Review year_columns, output_metrics, pdf_sources, narratives; "
            "paste under manifest companies: or use --append-to (YAML comments are not preserved).",
            file=sys.stderr,
        )
        return 0

    if args.append_to:
        path = args.append_to.resolve()
        if not path.exists():
            print(f"Manifest not found: {path}", file=sys.stderr)
            return 1
        with open(path, encoding="utf-8") as fh:
            manifest = yaml.safe_load(fh) or {}
        companies = manifest.setdefault("companies", {})
        for slug, entry in built.items():
            if slug in companies:
                print(f"Refusing to overwrite existing company {slug!r}", file=sys.stderr)
                return 1
            companies[slug] = entry
        with open(path, "w", encoding="utf-8") as fh:
            yaml.dump(manifest, fh, default_flow_style=False, allow_unicode=True, sort_keys=False)
        print(f"Appended {list(built)} to {path}", file=sys.stderr)
        return 0

    print(yaml.dump(dump_obj, default_flow_style=False, allow_unicode=True, sort_keys=False))
    print(
        "Use --dry-run to only preview, or --append-to Data_Input/manifest.yaml to merge.",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
