# MIT License — see LICENSE file
"""
tests/test_simulation_engine.py
================================
Unit tests for the Counterfactual Simulation Engine.

Coverage:
  • I_d recomputation correctness for Shell and Ørsted scenarios.
  • ΔRI formula (positive / negative / zero baseline).
  • Epsilon guard: near-zero denominator does not raise.
  • WACC classification changes under simulated reduction.
  • Fuel value override and fallback logic.
  • Dutch mandate scenario (45% reduction).

All tests are 100% offline — no API calls, no CSV reads.
"""

import math
import pytest

from simulation_engine import (
    _DUTCH_MANDATE_PCT,
    _SHELL_FUEL_2015,
    _SHELL_FUEL_2024,
    compute_simulated_id,
    compute_simulated_ri,
    run_counterfactual_simulation,
    run_dutch_mandate_scenario,
)


# ── Shared fixtures ───────────────────────────────────────────────────────────

def _shell_report(fuel_2015=_SHELL_FUEL_2015, fuel_2024=_SHELL_FUEL_2024,
                  delta_sentiment=0.47, dd=0.74, arb=1):
    """Minimal Shell-like report dict for simulation tests."""
    delta_ri = (fuel_2024 - fuel_2015) / fuel_2015
    id_val   = delta_sentiment / (delta_ri * dd)
    return {
        "system":  {"company": "shell", "display_name": "Shell PLC"},
        "layers":  {
            "corporate_agent": {
                "delta_narrative_sentiment": delta_sentiment,
                "source_url": "https://reports.shell.com/annual-report/2024/",
            },
            "auditor_agent": {
                "delta_resource_intensity": delta_ri,
                "disclosure_density":       dd,
                "jurisdictional_arbitrage": arb,
                "raw_records": [
                    {"metric": "Upstream Natural Gas Fuel Consumption",
                     "value": str(fuel_2015), "year": "2015",
                     "source_citation": "Shell SR 2015, p.42",
                     "source_url": "https://reports.shell.com/sustainability-report/2015/"},
                    {"metric": "Upstream Natural Gas Fuel Consumption",
                     "value": str(fuel_2024), "year": "2024",
                     "source_citation": "Shell AR 2024, p.78",
                     "source_url": "https://reports.shell.com/annual-report/2024/"},
                ],
            },
            "sceptic_agent": {
                "integrity_discount":    id_val,
                "risk_flag":             "HIGH-RISK STRATEGIC OBFUSCATION",
                "risk_level":            "HIGH",
                "valuation_impact_bps":  150,
                "formula_inputs": {
                    "delta_narrative_sentiment": delta_sentiment,
                    "delta_resource_intensity":  delta_ri,
                    "disclosure_density":        dd,
                    "denominator":               delta_ri * dd,
                },
            },
        },
        "verdict": {
            "integrity_discount":   id_val,
            "risk_flag":            "HIGH-RISK STRATEGIC OBFUSCATION",
            "risk_level":           "HIGH",
            "valuation_impact_bps": 150,
        },
        "raw_records": [
            {"metric": "Upstream Natural Gas Fuel Consumption",
             "value": str(fuel_2015), "year": "2015",
             "source_citation": "Shell SR 2015, p.42",
             "source_url": "https://reports.shell.com/sustainability-report/2015/"},
            {"metric": "Upstream Natural Gas Fuel Consumption",
             "value": str(fuel_2024), "year": "2024",
             "source_citation": "Shell AR 2024, p.78",
             "source_url": "https://reports.shell.com/annual-report/2024/"},
        ],
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 1. ΔRI formula correctness
# ═══════════════════════════════════════════════════════════════════════════════

class TestComputeSimulatedRI:
    """compute_simulated_ri must implement (sim - base) / base exactly."""

    def test_basic_arithmetic(self):
        """Standard positive case."""
        ri = compute_simulated_ri(100.0, 150.0)
        assert abs(ri - 0.50) < 1e-9

    def test_reduction_gives_negative_ri(self):
        """Simulated fuel < baseline → negative RI."""
        ri = compute_simulated_ri(100.0, 40.0)
        assert abs(ri - (-0.60)) < 1e-9

    def test_equal_gives_zero(self):
        """No change → ΔRI = 0."""
        ri = compute_simulated_ri(100.0, 100.0)
        assert ri == 0.0

    def test_zero_baseline_returns_zero(self):
        """Guarded against zero denominator."""
        ri = compute_simulated_ri(0.0, 100.0)
        assert ri == 0.0

    def test_45_pct_reduction_from_shell(self):
        """Shell 45% reduction from 12.03M TJ."""
        sim_fuel = _SHELL_FUEL_2024 * (1 - 45 / 100)
        ri = compute_simulated_ri(_SHELL_FUEL_2015, sim_fuel)
        expected = (sim_fuel - _SHELL_FUEL_2015) / _SHELL_FUEL_2015
        assert abs(ri - expected) < 1e-6


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Simulated I_d correctness
# ═══════════════════════════════════════════════════════════════════════════════

class TestComputeSimulatedId:
    """Simulated I_d = ΔSentiment / (ΔRI × DD), with ε guard."""

    def test_basic_formula(self):
        """Standard case: I_d = ΔSent / (ΔRI × DD)."""
        id_sim, denom, guard = compute_simulated_id(0.47, 2.0, 0.74)
        expected = 0.47 / (2.0 * 0.74)
        assert abs(id_sim - round(expected, 6)) < 1e-5
        assert guard is False

    def test_negative_ri_gives_negative_id(self):
        """Negative ΔRI → negative denominator → negative I_d (authentic alignment)."""
        id_sim, _, guard = compute_simulated_id(0.5, -0.5, 0.8)
        assert id_sim < 0
        assert guard is False

    def test_near_zero_denominator_no_crash(self):
        """ΔRI ≈ 0 → epsilon guard; result is finite."""
        id_sim, denom, guard = compute_simulated_id(0.5, 1e-12, 0.74)
        assert guard is True
        assert math.isfinite(id_sim)

    def test_zero_sentiment_gives_zero_id(self):
        """ΔSentiment = 0 → I_d = 0 regardless of denominator."""
        id_sim, _, _ = compute_simulated_id(0.0, 5.0, 0.74)
        assert id_sim == 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Full simulation run
# ═══════════════════════════════════════════════════════════════════════════════

class TestRunCounterfactualSimulation:
    """End-to-end simulation output schema and logic."""

    REQUIRED_KEYS = {
        "scenario_label", "company_name", "target_metric", "reduction_pct",
        "fuel_2015", "fuel_2024_original", "fuel_2024_simulated",
        "delta_ri_original", "delta_ri_simulated",
        "delta_ri_pct_original", "delta_ri_pct_simulated",
        "delta_sentiment", "disclosure_density", "arb_flag",
        "id_original", "id_simulated", "id_delta",
        "wacc_bps_original", "wacc_bps_simulated", "wacc_bps_delta",
        "risk_flag_original", "risk_flag_simulated",
        "risk_level_original", "risk_level_simulated",
        "epsilon_guard", "interpretation",
    }

    def test_output_schema_complete(self):
        """All required keys present in output."""
        result = run_counterfactual_simulation(
            "shell", "Upstream Gas", 45.0, _shell_report(),
        )
        missing = self.REQUIRED_KEYS - set(result.keys())
        assert not missing, f"Missing keys: {missing}"

    def test_simulated_fuel_lower_than_original(self):
        """Simulated fuel = original × (1 − reduction)."""
        result = run_counterfactual_simulation("shell", "Gas", 45.0, _shell_report())
        expected_sim = result["fuel_2024_original"] * 0.55
        assert abs(result["fuel_2024_simulated"] - expected_sim) < 1.0

    def test_reduction_improves_delta_ri(self):
        """A reduction in fuel must lower ΔRI vs the original."""
        result = run_counterfactual_simulation("shell", "Gas", 45.0, _shell_report())
        assert result["delta_ri_simulated"] < result["delta_ri_original"]

    def test_wacc_bps_delta_is_integer(self):
        """WACC bps values are integers."""
        result = run_counterfactual_simulation("shell", "Gas", 45.0, _shell_report())
        assert isinstance(result["wacc_bps_delta"], int)

    def test_interpretation_is_nonempty_string(self):
        """Interpretation text is a non-empty string."""
        result = run_counterfactual_simulation("shell", "Gas", 45.0, _shell_report())
        assert isinstance(result["interpretation"], str)
        assert len(result["interpretation"]) > 20

    def test_id_delta_matches_diff(self):
        """id_delta = id_simulated − id_original (within rounding)."""
        result = run_counterfactual_simulation("shell", "Gas", 45.0, _shell_report())
        assert abs(result["id_delta"] - (result["id_simulated"] - result["id_original"])) < 1e-5

    def test_zero_reduction_equals_original(self):
        """0% reduction → simulated ≈ original (ε rounding allowed)."""
        result = run_counterfactual_simulation("shell", "Gas", 0.0, _shell_report())
        assert abs(result["fuel_2024_simulated"] - result["fuel_2024_original"]) < 1.0

    def test_100_pct_reduction_gives_zero_fuel(self):
        """100% reduction → simulated fuel = 0."""
        result = run_counterfactual_simulation("shell", "Gas", 100.0, _shell_report())
        assert result["fuel_2024_simulated"] == 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Dutch mandate scenario
# ═══════════════════════════════════════════════════════════════════════════════

class TestDutchMandateScenario:
    """The 'Stayed in Holland' pre-built 45% scenario."""

    def test_reduction_pct_is_45(self):
        """Preset scenario uses exactly 45% reduction."""
        result = run_dutch_mandate_scenario(_shell_report())
        assert result["reduction_pct"] == _DUTCH_MANDATE_PCT

    def test_company_name_is_shell(self):
        """Default company is shell."""
        result = run_dutch_mandate_scenario(_shell_report())
        assert result["company_name"] == "shell"

    def test_simulated_ri_lower(self):
        """45% reduction must lower ΔRI substantially."""
        result = run_dutch_mandate_scenario(_shell_report())
        assert result["delta_ri_simulated"] < result["delta_ri_original"]

    def test_all_values_finite(self):
        """No Inf or NaN anywhere in output."""
        result = run_dutch_mandate_scenario(_shell_report())
        for key, val in result.items():
            if isinstance(val, float):
                assert math.isfinite(val), f"{key} = {val}"
