# INVESTMENT COMMITTEE MEMORANDUM

**Date:** 09 April 2026, 11:43 UTC  
**Prepared by:** AuditLens MAD Protocol v1.0 · Team Alpha 1 · Durham University  
**Copyright:** © 2026 Zongchen Nan  
**Subject:** ESG Integrity-Adjusted Portfolio Reallocation — Energy Sector  
**AUM:** $100M USD (Illustrative)  
**Companies Scanned:** 4  

> **CFA Rule 4.6 Compliance Statement:** All data underpinning this memo
> is sourced exclusively from publicly available corporate filings, sustainability
> reports, and government databases. No proprietary data vendors, paid terminals,
> or employer data were used. Every metric is accompanied by `source_citation`
> and `source_url` per CFA Rule 4.6.

> **Institutional workflow demo only.** Illustrative sensitivity mapping and 
> portfolio-weight arithmetic; **not** validated investment advice, **not** a 
> backtested strategy, **not** an offer to transact.

---

## 1. Executive Summary — Decision Support Summary

The AuditLens MAD Protocol has completed a sector-wide ESG integrity scan across 4 energy companies. The Bias-Variance Matrix (OpenAI `gpt-4o-mini` vs. Anthropic `claude-3-5-sonnet-20241022`, `temperature=0.0`) produced deterministic consensus sentiment scores with all inter-model variances logged for fiduciary review.

**Integrity Summary:** 3/4 Authentic Transition Leaders · 1/4 High-Risk Obfuscators.

### Sector Integrity Ranking

| Rank | Company | Integrity score | I_d | Risk flag | WACC (bps) |
|------|---------|-----------------|-----|-----------|------------|
| 1 | BP plc (LSE: BP.L) | 1.0000 | -536.8304 | AUTHENTIC TRANSITION LEADER | -50 |
| 2 | Shell PLC (LSE: SHEL) | 1.0000 | -3.7344 | AUTHENTIC TRANSITION LEADER | -50 |
| 3 | Ørsted A/S (CPH: ORSTED) | 1.0000 | -3.0562 | AUTHENTIC TRANSITION LEADER | -50 |
| 4 | TotalEnergies SE (PARIS: TTE) | 0.3000 | +27.2000 | HIGH-RISK STRATEGIC OBFUSCATION | +100 |

### Illustrative Reallocation Table (Demo)

| Action | Company | Δ Weight | Δ Capital | Rationale |
|--------|---------|---------|-----------|-----------|
| **DIVEST** | TotalEnergies SE (PARIS: TTE) | -5.49% | $-5.49M | HIGH-RISK STRATEGIC OBFUSCATION |
| **ALLOCATE** | BP plc (LSE: BP.L) | +1.83% | $+1.83M | AUTHENTIC TRANSITION LEADER |
| **ALLOCATE** | Shell PLC (LSE: SHEL) | +1.83% | $+1.83M | AUTHENTIC TRANSITION LEADER |
| **ALLOCATE** | Ørsted A/S (CPH: ORSTED) | +1.83% | $+1.83M | AUTHENTIC TRANSITION LEADER |

---

### Visual diligence — HTML tear sheet (Fiduciary Command Center)

For each scanned issuer, open **`data/{company}_auditlens_dashboard.html`** after running the standard pipeline. The tear sheet includes a **5×5 WACC × Integrity sensitivity matrix** (valuation haircut % per cell) built with the same `calculate_adjusted_value` engine as the illustrative DCF block, a **narrative vs. operations divergence** view (documented normalization), and a **simplified sceptic logic path** tied to that run’s JSON. All visuals are static HTML/CSS (no external JS; CFA Rule 4.4 offline).

## 2. Macro ESG Thesis — Sector Observations

The energy sector presents a **bifurcated transition landscape**. A minority of issuers show genuine capital reallocation away from fossil inputs (negative ΔResource Intensity), while the majority maintain or grow upstream fossil consumption whilst accelerating Net-Zero narrative intensity — a pattern the MAD Protocol quantifies as the 'Signalling Paradox'.

**Key sector-level findings:**

- **BP plc (LSE: BP.L)**: ΔResource Intensity ↓ -0.1%  |  I_d = -536.8304  |  AUTHENTIC TRANSITION LEADER  |  WACC: -50 bps
- **Shell PLC (LSE: SHEL)**: ΔResource Intensity ↓ -15.5%  |  I_d = -3.7344  |  AUTHENTIC TRANSITION LEADER  |  WACC: -50 bps
- **Ørsted A/S (CPH: ORSTED)**: ΔResource Intensity ↓ -27.4%  |  I_d = -3.0562  |  AUTHENTIC TRANSITION LEADER  |  WACC: -50 bps
- **TotalEnergies SE (PARIS: TTE)**: ΔResource Intensity ↑ +2.0%  |  I_d = +27.2000  |  HIGH-RISK STRATEGIC OBFUSCATION  |  WACC: +100 bps

---

## 3. Illustrative Integrity-Adjusted Risk Rationale — WACC (bps)

### BP plc (LSE: BP.L)

| Parameter | Value |
|-----------|-------|
| Integrity Discount (I_d) | -536.8304 |
| Risk Classification | AUTHENTIC TRANSITION LEADER |
| Risk Level | LOW |
| ΔResource Intensity | -0.1% |
| Disclosure Density | 0.7000 |
| Jurisdictional Arbitrage | ✓ None |
| **WACC Adjustment** | **-50 bps** |

**Rationale:** Negative ΔResource Intensity confirms irreversible capital reallocation away from fossil fuels. Scope 3 trajectory declining. No Jurisdictional Arbitrage. Green cost-of-capital premium applies (−50 bps).

### Shell PLC (LSE: SHEL)

| Parameter | Value |
|-----------|-------|
| Integrity Discount (I_d) | -3.7344 |
| Risk Classification | AUTHENTIC TRANSITION LEADER |
| Risk Level | LOW |
| ΔResource Intensity | -15.5% |
| Disclosure Density | 0.8100 |
| Jurisdictional Arbitrage | ✓ None |
| **WACC Adjustment** | **-50 bps** |

**Rationale:** Negative ΔResource Intensity confirms irreversible capital reallocation away from fossil fuels. Scope 3 trajectory declining. No Jurisdictional Arbitrage. Green cost-of-capital premium applies (−50 bps).

### Ørsted A/S (CPH: ORSTED)

| Parameter | Value |
|-----------|-------|
| Integrity Discount (I_d) | -3.0562 |
| Risk Classification | AUTHENTIC TRANSITION LEADER |
| Risk Level | LOW |
| ΔResource Intensity | -27.4% |
| Disclosure Density | 0.7400 |
| Jurisdictional Arbitrage | ✓ None |
| **WACC Adjustment** | **-50 bps** |

**Rationale:** Negative ΔResource Intensity confirms irreversible capital reallocation away from fossil fuels. Scope 3 trajectory declining. No Jurisdictional Arbitrage. Green cost-of-capital premium applies (−50 bps).

### TotalEnergies SE (PARIS: TTE)

| Parameter | Value |
|-----------|-------|
| Integrity Discount (I_d) | +27.2000 |
| Risk Classification | HIGH-RISK STRATEGIC OBFUSCATION |
| Risk Level | HIGH |
| ΔResource Intensity | +2.0% |
| Disclosure Density | 0.7500 |
| Jurisdictional Arbitrage | ✓ None |
| **WACC Adjustment** | **+100 bps** |

**Rationale:** Narrative Sentiment inflation disproportionate to operational reality (ΔRI > 0, I_d > threshold). ESG stranded-asset premium applied: +100 bps.

---

## 4. Illustrative Portfolio Weights (Demo)

Baseline: Equal-Weight (EW) across 4 assets.  
AUM: $100M USD.  
Tilt formula: `tilt_multiplier = max(0.1, 1.0 − wacc_bps/500)`.  
Long-only constraint enforced. Weights normalised to 100%.  

| Company | EW Baseline | Tilt × | Optimized Weight | Δ Weight | Δ Capital |
|---------|------------|--------|-----------------|---------|-----------|
| BP plc (LSE: BP.L) | 25.00% | 1.10× | 26.83% | ↑ +1.83% | $+1.83M |
| Shell PLC (LSE: SHEL) | 25.00% | 1.10× | 26.83% | ↑ +1.83% | $+1.83M |
| Ørsted A/S (CPH: ORSTED) | 25.00% | 1.10× | 26.83% | ↑ +1.83% | $+1.83M |
| TotalEnergies SE (PARIS: TTE) | 25.00% | 0.80× | 19.51% | ↓ -5.49% | $-5.49M |

> **Weight sum check:** 100.0000% (long-only constraint satisfied).

---

## 5. Compliance & Reproducibility

| Rule | Status | Detail |
|------|--------|--------|
| CFA Rule 1.5 (MIT License) | ✓ COMPLIANT | LICENSE file in repository root |
| CFA Rule 4.4 (Caching) | ✓ COMPLIANT | `--use-cached` reproduces at $0 cost |
| CFA Rule 4.6 (Public Data) | ✓ COMPLIANT | All CSVs cite public filings |
| Dual-Model Bias Guard | ✓ ACTIVE | OpenAI + Anthropic @ temperature=0.0 |
| Portfolio Optimizer | ✓ DETERMINISTIC | 100% offline, no API calls |

**Reproduce this memo:**
```bash
python run_auditlens.py --sector-scan --use-cached
```

---

*Generated 09 April 2026, 11:43 UTC by AuditLens MAD Protocol.*  
*Generated by AuditLens MAD Protocol (Cached Mode) — Zero Proprietary Data Used.*