# MIT License — see LICENSE file
"""
AuditLens Valuation Engine
===========================
Bridges the MAD Protocol's Integrity Discount (I_d) with traditional
Discounted Cash Flow (DCF) asset pricing.

Mechanism:
  1. The I_d risk classification is mapped to a normalised Integrity Score
     in [0, 1] (1.0 = perfect alignment; 0.0 = complete obfuscation).
  2. When Integrity Score < 0.80 (fiduciary threshold), a risk premium of
     100–200 basis points is applied to the company's WACC, scaling linearly
     with how far the score falls below the threshold.
  3. The adjusted WACC feeds directly into a standard DCF model, producing
     a concrete valuation haircut that Portfolio Managers can act on.

Formula (per mentor directive):
  Adjusted_Value = Σ [ FCF_t / (1 + WACC + Risk_Premium(Id))^t ]
                 + [ TV × TV_factor / (1 + WACC + Risk_Premium(Id))^n ]

Design principles:
  • 100% deterministic — no LLM inference, no external calls.
  • Illustrative FCF/WACC data clearly labelled; replace with live data for
    production deployment.
  • Operates entirely offline; satisfies CFA Rule 4.6 (no proprietary data).
  • All functions are pure (stateless); safe to call from any context.

Integrity Score mapping:
  risk_level="LOW"  (AUTHENTIC TRANSITION LEADER)  → 1.00  (no penalty)
  risk_level="LOW"  (CONSERVATIVE SIGNALLING)       → 0.85  (no penalty)
  risk_level="MEDIUM" (MODERATE OBFUSCATION)        → 0.55  (100–138 bps)
  risk_level="HIGH" (HIGH-RISK OBFUSCATION)         → 0.20  (175 bps)
"""

from __future__ import annotations

import logging
import math
from typing import Dict, List, Optional

logger = logging.getLogger("VALUATION_ENGINE")

# ── Thresholds & constants ─────────────────────────────────────────────────────

INTEGRITY_THRESHOLD = 0.80   # Scores below this trigger WACC adjustment
MIN_PREMIUM_BPS     = 100    # 1.00% — applied just at the threshold
MAX_PREMIUM_BPS     = 200    # 2.00% — applied at worst-case integrity (0.0)

# Terminal-Value haircut by severity — supplementary penalty for long-term
# jurisdictional-arbitrage and stranded-asset risk.
_TV_HAIRCUT = {
    "none":   1.00,   # integrity >= 0.8  → no TV haircut
    "mild":   0.95,   # 0.4 <= score < 0.8 → 5% TV haircut
    "severe": 0.90,   # score < 0.4        → 10% TV haircut
}

# ── Illustrative FCF / WACC seed data ─────────────────────────────────────────
# These are ORDER-OF-MAGNITUDE placeholder values for methodology demonstration.
# Actual investor-grade projections require access to live analyst consensus
# (which this system does not fetch, in compliance with CFA Rule 4.6).
# Shell figures approximate the scale of a major integrated oil major (GBP £B).
# Ørsted figures approximate a large European offshore-wind operator (DKK B).

ILLUSTRATIVE_FCF_DATA: Dict[str, dict] = {
    "shell": {
        "company":        "Shell PLC (LSE: SHEL)",
        "currency":       "GBP (£B)",
        "base_wacc":      0.080,          # 8.0 % — publicly referenced base
        "fcf_array":      [28.0, 27.2, 26.4, 25.6, 24.8],   # Years 1–5
        "terminal_value": 185.0,          # Gordon-growth TV at end of year 5
        "n_years":        5,
        "note": (
            "ILLUSTRATIVE ONLY — order-of-magnitude for methodology demonstration. "
            "Source: publicly available analyst-consensus range for large integrated "
            "oil majors (LSE:SHEL). Replace with live DCF inputs for deployment."
        ),
    },
    "orsted": {
        "company":        "Ørsted A/S (CPH: ORSTED)",
        "currency":       "DKK (DKK B)",
        "base_wacc":      0.070,          # 7.0 % — lower base reflecting green profile
        "fcf_array":      [18.5, 20.0, 21.5, 23.0, 24.5],   # Years 1–5
        "terminal_value": 160.0,
        "n_years":        5,
        "note": (
            "ILLUSTRATIVE ONLY — order-of-magnitude for methodology demonstration. "
            "Source: publicly available analyst-consensus range for offshore-wind "
            "operators (CPH:ORSTED). Replace with live DCF inputs for deployment."
        ),
    },
}


# ── Core functions ────────────────────────────────────────────────────────────

def normalize_id_to_integrity_score(
    risk_level: str,
    risk_flag:  str,
) -> float:
    """
    Map AuditLens risk classification to a normalised Integrity Score in [0, 1].

    The raw I_d value from the MAD Protocol formula is a dimensionless ratio
    (Shell ≈ +0.066; Ørsted ≈ −0.883) whose scale is not directly compatible
    with the [0, 1] Integrity Score expected by the valuation engine. This
    function performs the mapping via the risk classification.

    Integrity Score semantics:
      1.00  Full integrity — narrative perfectly aligned with capital allocation.
      0.80  Threshold — below this, fiduciary WACC adjustment is warranted.
      0.55  Moderate obfuscation — partial narrative-reality decoupling detected.
      0.20  Severe obfuscation — systematic narrative inflation confirmed.

    Parameters
    ----------
    risk_level : str  "HIGH", "MEDIUM", or "LOW" from ScepticAgent.
    risk_flag  : str  Full risk flag string (for finer classification).

    Returns
    -------
    float  Integrity Score in [0.0, 1.0].
    """
    if "AUTHENTIC TRANSITION LEADER" in risk_flag:
        out = 1.00   # Above threshold → no penalty, qualifies for green premium
    elif risk_level == "LOW":
        out = 0.85   # CONSERVATIVE or ALIGNED — just above threshold
    elif risk_level == "MEDIUM":
        out = 0.55   # MODERATE OBFUSCATION — comfortably below threshold
    elif "ESCALATED" in risk_flag or "Jurisdictional" in risk_flag:
        out = 0.20   # Systemic obfuscation + legal arbitrage
    else:
        out = 0.30   # High-risk without explicit arbitrage component
    return max(0.0, min(1.0, out))


def calculate_wacc_premium(integrity_score: float) -> int:
    """
    Calculate the WACC risk premium (in basis points) from an Integrity Score.

    Rule (per mentor directive):
      • integrity_score >= INTEGRITY_THRESHOLD (0.80): no adjustment (0 bps).
      • integrity_score in (0.0, 0.80): linear scale 100 → 200 bps.
      • integrity_score <= 0.0: capped at MAX_PREMIUM_BPS (200 bps).

    Linear formula (score in [0.0, 0.80)):
      premium = MIN_PREMIUM_BPS
              + (THRESHOLD − score) / THRESHOLD × (MAX − MIN)
                                                              ↑ 100 bps range
    This ensures:
      At score = 0.80 (threshold edge): premium = 100 + 0    = 100 bps (1.00%)
      At score = 0.40 (midpoint):       premium = 100 + 50   = 150 bps (1.50%)
      At score = 0.00 (maximum):        premium = 100 + 100  = 200 bps (2.00%)
      At score < 0.0:                   premium = 200 bps    (cap)

    Parameters
    ----------
    integrity_score : float  Normalised score from normalize_id_to_integrity_score().

    Returns
    -------
    int  WACC premium in basis points [0, 200].
    """
    if not math.isfinite(integrity_score):
        logger.warning("VALUATION_ENGINE: non-finite integrity_score — applying max WACC premium.")
        return MAX_PREMIUM_BPS

    integrity_score = max(0.0, min(1.0, integrity_score))

    if integrity_score >= INTEGRITY_THRESHOLD:
        return 0

    clamped  = max(0.0, integrity_score)
    fraction = (INTEGRITY_THRESHOLD - clamped) / INTEGRITY_THRESHOLD
    premium  = MIN_PREMIUM_BPS + fraction * (MAX_PREMIUM_BPS - MIN_PREMIUM_BPS)
    return min(MAX_PREMIUM_BPS, round(premium))


def calculate_adjusted_value(
    fcf_array:      List[float],
    base_wacc:      float,
    integrity_score: float,
    terminal_value: float,
    n_years:        Optional[int] = None,
) -> dict:
    """
    Calculate the I_d-adjusted DCF valuation using the mentor's formula.

    Formula:
        Adjusted_Value = Σ_{t=1}^{n} [ FCF_t / (1 + WACC + RP(Id))^t ]
                       + [ TV × TV_factor / (1 + WACC + RP(Id))^n ]

    where RP(Id) = Risk_Premium derived from the Integrity Score.

    A supplementary Terminal Value haircut (TV_factor) is also applied to
    capture long-term jurisdictional and stranded-asset risks that the
    period DCFs do not fully reflect:
      integrity_score >= 0.80 → TV_factor = 1.00 (no haircut)
      0.40 <= score < 0.80   → TV_factor = 0.95 (5 % haircut)
      score < 0.40           → TV_factor = 0.90 (10% haircut)

    Parameters
    ----------
    fcf_array       : Free Cash Flow projections [FCF_1, FCF_2, ...] (any currency unit).
    base_wacc       : Base WACC as a decimal (e.g. 0.08 for 8.0%).
    integrity_score : Normalised integrity score from normalize_id_to_integrity_score().
    terminal_value  : Terminal value at end of projection period (same currency unit).
    n_years         : Projection period. Defaults to len(fcf_array).

    Returns
    -------
    dict with keys:
      base_wacc_pct, premium_bps, premium_pct, adjusted_wacc_pct,
      tv_discount_factor,
      base_pv_fcf, adj_pv_fcf,
      base_pv_tv,  adj_pv_tv,
      base_valuation, adjusted_valuation,
      valuation_haircut, haircut_pct.
    """
    n             = n_years or len(fcf_array)
    if not math.isfinite(base_wacc) or base_wacc <= 0.0:
        logger.warning("VALUATION_ENGINE: invalid base_wacc — using illustrative 8%%.")
        base_wacc = 0.08
    premium_bps   = calculate_wacc_premium(integrity_score)
    premium_rate  = premium_bps / 10_000
    adjusted_wacc = max(1e-6, base_wacc + premium_rate)

    # TV haircut tier
    if integrity_score >= INTEGRITY_THRESHOLD:
        tv_factor = _TV_HAIRCUT["none"]
    elif integrity_score >= 0.40:
        tv_factor = _TV_HAIRCUT["mild"]
    else:
        tv_factor = _TV_HAIRCUT["severe"]

    # ── PV of FCFs ────────────────────────────────────────────────────────────
    base_pv_fcf = sum(fcf / (1 + base_wacc) ** (t + 1)
                      for t, fcf in enumerate(fcf_array[:n]))
    adj_pv_fcf  = sum(fcf / (1 + adjusted_wacc) ** (t + 1)
                      for t, fcf in enumerate(fcf_array[:n]))

    # ── PV of Terminal Value ──────────────────────────────────────────────────
    base_pv_tv  = terminal_value / (1 + base_wacc) ** n
    adj_pv_tv   = (terminal_value * tv_factor) / (1 + adjusted_wacc) ** n

    # ── Summary ───────────────────────────────────────────────────────────────
    base_val = base_pv_fcf + base_pv_tv
    adj_val  = adj_pv_fcf  + adj_pv_tv
    haircut  = base_val - adj_val
    haircut_pct = (haircut / base_val * 100) if base_val > 0 else 0.0

    return {
        "base_wacc_pct":      round(base_wacc * 100, 2),
        "premium_bps":        premium_bps,
        "premium_pct":        round(premium_rate * 100, 2),
        "adjusted_wacc_pct":  round(adjusted_wacc * 100, 2),
        "tv_discount_factor": tv_factor,
        "base_pv_fcf":        round(base_pv_fcf, 2),
        "adj_pv_fcf":         round(adj_pv_fcf, 2),
        "base_pv_tv":         round(base_pv_tv, 2),
        "adj_pv_tv":          round(adj_pv_tv, 2),
        "base_valuation":     round(base_val, 2),
        "adjusted_valuation": round(adj_val, 2),
        "valuation_haircut":  round(haircut, 2),
        "haircut_pct":        round(haircut_pct, 2),
    }


def run_valuation_scenario(
    company_name:   str,
    risk_level:     str,
    risk_flag:      str,
    custom_fcf:     Optional[dict] = None,
) -> dict:
    """
    Convenience wrapper: run the full valuation scenario for a company.

    Combines normalisation → WACC premium → DCF adjustment into one call,
    using the illustrative FCF seed data (or custom override) and enriching
    the output with display-ready formatted strings.

    Parameters
    ----------
    company_name : str   Company identifier ("shell" or "orsted").
    risk_level   : str   "HIGH" / "MEDIUM" / "LOW" from ScepticAgent.
    risk_flag    : str   Full risk flag string from ScepticAgent.
    custom_fcf   : dict  Override illustrative data (optional).

    Returns
    -------
    dict  Full valuation dict plus integrity_score, company metadata, note.
    """
    seed       = custom_fcf or ILLUSTRATIVE_FCF_DATA.get(company_name.lower(), ILLUSTRATIVE_FCF_DATA["shell"])
    int_score  = normalize_id_to_integrity_score(risk_level, risk_flag)
    dcf        = calculate_adjusted_value(
        fcf_array      = seed["fcf_array"],
        base_wacc      = seed["base_wacc"],
        integrity_score= int_score,
        terminal_value = seed["terminal_value"],
        n_years        = seed["n_years"],
    )

    premium_bps = dcf["premium_bps"]
    log_level   = logging.WARNING if premium_bps > 0 else logging.INFO
    logger.log(
        log_level,
        "VALUATION ENGINE  [%s]\n"
        "  Integrity Score   : %.2f  (threshold %.2f)\n"
        "  WACC Premium      : %+d bps  (%+.2f%%)\n"
        "  Base Valuation    : %.1f %s\n"
        "  Adjusted Val.     : %.1f %s  (haircut: %.1f, %.1f%%)",
        seed["company"],
        int_score, INTEGRITY_THRESHOLD,
        premium_bps, dcf["premium_pct"],
        dcf["base_valuation"],    seed["currency"],
        dcf["adjusted_valuation"], seed["currency"],
        dcf["valuation_haircut"], dcf["haircut_pct"],
    )

    return {
        **dcf,
        "integrity_score":  int_score,
        "company":          seed["company"],
        "currency":         seed["currency"],
        "note":             seed["note"],
        "is_penalised":     premium_bps > 0,
        "breach_label": (
            f"I_d < {INTEGRITY_THRESHOLD} threshold — "
            f"Integrity Score {int_score:.2f} warrants {premium_bps} bps WACC adjustment"
            if premium_bps > 0
            else f"Integrity Score {int_score:.2f} ≥ {INTEGRITY_THRESHOLD} — no WACC adjustment"
        ),
    }
